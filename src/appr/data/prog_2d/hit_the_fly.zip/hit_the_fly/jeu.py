import pgzrun
from pgzhelper import *

TITLE = 'Hit the fly'

WIDTH = 800
HEIGHT = 600

pgzrun.go()