import math
import pygame
import sys
from pgzero.actor import Actor as PgzActor, POS_TOPLEFT, ANCHOR_CENTER, transform_anchor
from pgzero import game, loaders
import pgzero.screen as _pgzero_screen
import time

# Re-exports used by student projects so editors (Pylance) can resolve names
# like `screen`, `keyboard` and `Rect` coming from Pygame Zero.
try:
  from pgzero.builtins import Rect, keyboard, music, sounds
except Exception:  # pragma: no cover
  Rect = pygame.Rect
  keyboard = None
  music = None
  sounds = None


class _ScreenProxy:
  def _resolve(self):
    # When running a Pygame Zero script via `pgzrun.go()`, the current
    # module receives a `screen` object of type `pgzero.screen.Screen`.
    main_mod = sys.modules.get("__main__")
    if main_mod is not None:
      candidate = getattr(main_mod, "screen", None)
      # `from pgzhelper import *` defines `screen` in __main__ as this
      # proxy. Avoid introspection that would call __getattr__ and recurse.
      if candidate is not None and not isinstance(candidate, _ScreenProxy):
        if isinstance(candidate, _pgzero_screen.Screen):
          return candidate

    # pgzero.game.screen is a pygame.Surface in pgzero 1.2.1.
    surface = getattr(game, "screen", None)
    if surface is None:
      return None

    if isinstance(surface, _pgzero_screen.Screen):
      return surface

    try:
      return _pgzero_screen.Screen(surface)
    except Exception:
      return surface

  def __getattr__(self, name):
    resolved = self._resolve()
    if resolved is None:
      raise AttributeError("Pygame Zero screen is not initialized yet")
    return getattr(resolved, name)


screen = _ScreenProxy()

def remove_actors(actors):
    actors[:] = [actor for actor in actors if not getattr(actor, 'to_remove', False)]

class Actor(PgzActor):
  def __init__(self, image, pos=POS_TOPLEFT, anchor=ANCHOR_CENTER, width=None, height=None, **kwargs):
    self._flip_x = False
    self._flip_y = False
    self._scale = 1
    self._mask = None
    self._animate_counter = 0
    self.fps = 5
    self.direction = 0
    self.to_remove = False
    super().__init__(image, pos, anchor, **kwargs)
    if width is not None:
        self.set_width(width)
    elif height is not None:
        self.set_height(height)

  def distance_to(self, actor):
    dx = actor.x - self.x
    dy = actor.y - self.y
    return math.sqrt(dx**2 + dy**2)

  def direction_to(self, actor):
    dx = actor.x - self.x
    dy = self.y - actor.y

    angle = math.degrees(math.atan2(dy, dx))
    if angle > 0:
      return angle

    return 360 + angle

  def move_in_direction(self, speed):
    angle = math.radians(self.direction)
    dx = speed * math.cos(angle)
    dy = speed * math.sin(angle)
    self.x += dx
    self.y -= dy

  @property
  def images(self):
    return self._images

  @images.setter
  def images(self, images):
    self._images = images
    if len(self._images) != 0:
      self.image = self._images[0]

  def next_image(self):
    if self.image in self._images:
      current = self._images.index(self.image)
      if current == len(self._images) - 1:
        self.image = self._images[0]
      else:
        self.image = self._images[current + 1]
    else:
      self.image = self._images[0]

  def animate(self, fps=None):
    if fps is None:
      now = int(time.monotonic() * self.fps)
    else:
      now = int(time.monotonic() * fps)
    if now != self._animate_counter:
      self._animate_counter = now
      self.next_image()

  @property
  def angle(self):
    return self._angle

  @angle.setter
  def angle(self, angle):
    self._angle = angle
    self._transform_surf()

  @property
  def scale(self):
    return self._scale

  @scale.setter
  def scale(self, scale):
    self._scale = scale
    self._transform_surf()

  def set_width(self, width):
    self.width, self.height = self._surf.get_size()
    scale = width / self.width
    self._scale = scale
    self._transform_surf()

  def set_height(self, height):
    self.width, self.height = self._surf.get_size()
    scale = height / self.height
    self._scale = scale
    self._transform_surf()

  @property
  def flip_x(self):
    return self._flip_x

  @flip_x.setter
  def flip_x(self, flip_x):
    self._flip_x = flip_x
    self._transform_surf()

  @property
  def flip_y(self):
    return self._flip_y

  @flip_y.setter
  def flip_y(self, flip_y):
    self._flip_y = flip_y
    self._transform_surf()

  @property
  def image(self):
    return self._image_name

  @image.setter
  def image(self, image):
    self._image_name = image
    self._orig_surf = self._surf = loaders.images.load(image)
    self._update_pos()
    self._transform_surf()

  def _transform_surf(self):
    self._surf = self._orig_surf
    p = self.pos

    if self._scale != 1:
      size = self._orig_surf.get_size()
      self._surf = pygame.transform.scale(self._surf, (int(size[0] * self.scale), int(size[1] * self.scale)))
    if self._flip_x:
      self._surf = pygame.transform.flip(self._surf, True, False)
    if self._flip_y:
      self._surf = pygame.transform.flip(self._surf, False, True)

    self._surf = pygame.transform.rotate(self._surf, self._angle)

    self.width, self.height = self._surf.get_size()
    w, h = self._orig_surf.get_size()
    ax, ay = self._untransformed_anchor
    anchor = transform_anchor(ax, ay, w, h, self._angle)
    self._anchor = (anchor[0] * self.scale, anchor[1] * self.scale)

    self.pos = p
    self._mask = None

  def collidepoint_pixel(self, x, y=0):
    if isinstance(x, tuple):
      y = x[1]
      x = x[0]
    if self._mask is None:
      self._mask = pygame.mask.from_surface(self._surf)

    xoffset = int(x - self.left)
    yoffset = int(y - self.top)
    if xoffset < 0 or yoffset < 0:
      return 0

    width, height = self._mask.get_size()
    if xoffset >= width or yoffset >= height:
      return 0

    return self._mask.get_at((xoffset, yoffset))

  def collide_pixel(self, actor):
    for a in [self, actor]:
      if a._mask is None:
        a._mask = pygame.mask.from_surface(a._surf)

    xoffset = int(actor.left - self.left)
    yoffset = int(actor.top - self.top)

    return self._mask.overlap(actor._mask, (xoffset, yoffset))

  def collides_with(self, actor):
    angle = math.radians(self._angle)
    costheta = math.cos(angle)
    sintheta = math.sin(angle)
    width, height = self._surf.get_size()
    half_width = width / 2
    half_height = height / 2

    tx = actor.x - self.x
    ty = actor.y - self.y
    rx = tx * costheta - ty * sintheta
    ry = ty * costheta + tx * sintheta

    return rx > -half_width and rx < half_width and ry > -half_height and ry < half_height

  def obb_collidepoint(self, x, y=0):
    if isinstance(x, tuple):
      y = x[1]
      x = x[0]
    angle = math.radians(self._angle)
    costheta = math.cos(angle)
    sintheta = math.sin(angle)
    width, height = self._surf.get_size()
    half_width = width / 2
    half_height = height / 2

    tx = x - self.x
    ty = y - self.y
    rx = tx * costheta - ty * sintheta
    ry = ty * costheta + tx * sintheta

    if rx > -half_width and rx < half_width and ry > -half_height and ry < half_height:
      return True

    return False

  def circle_collidepoint(self, radius, x, y=0):
    if isinstance(x, tuple):
      y = x[1]
      x = x[0]
    rSquare = radius ** 2
    dSquare = (x - self.x)**2 + (y - self.y)**2

    if dSquare < rSquare:
      return True

    return False


  def draw(self):
    screen.blit(self._surf, self.topleft)

  def get_rect(self):
    return self._rect

class Platform(Actor):
    _EPS = 0.001

    def __init__(self, image, pos, solid=False, sticky=False, suspendable=False, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.solid = solid
        self.sticky = sticky
        self.suspendable = suspendable

    def _horizontal_overlap(self, actor):
        return actor.right > self.left and actor.left < self.right

    def _stop_vertical(self, actor):
        if hasattr(actor, 'vy'):
            actor.vy = 0

    def collides_with_actor(self, actor):
        if self.solid:
            return actor.colliderect(self)

        vy = getattr(actor, 'vy', 0)
        if vy < 0:
            return False

        if not self._horizontal_overlap(actor):
            return False

        curr_bottom = actor.bottom
        next_bottom = curr_bottom + vy

        return (
            (curr_bottom <= self.top + self._EPS and next_bottom >= self.top - self._EPS)
            or actor.colliderect(self)
        )

    def check_collision_with_actor(self, actor):
        vy = getattr(actor, 'vy', 0)

        # One-way platform (non-solid): only land when moving down.
        if not self.solid:
            if vy >= 0 and self._horizontal_overlap(actor):
                curr_bottom = actor.bottom
                next_bottom = curr_bottom + vy
                if curr_bottom <= self.top + self._EPS and next_bottom >= self.top - self._EPS:
                    actor.bottom = self.top
                    self._stop_vertical(actor)
                    return True

            # If already overlapping due to precision, snap to the top when coming from above.
            if vy >= 0 and actor.colliderect(self) and actor.centery <= self.centery:
                actor.bottom = self.top
                self._stop_vertical(actor)
                return True

            return False

        # Solid platforms: prevent tunneling by checking whether the actor will cross
        # the top/bottom edge when it later applies y += vy.
        if self._horizontal_overlap(actor):
            if vy > 0:
                curr_bottom = actor.bottom
                next_bottom = curr_bottom + vy
                if curr_bottom <= self.top + self._EPS and next_bottom >= self.top - self._EPS:
                    actor.bottom = self.top
                    self._stop_vertical(actor)
                    return True
            elif vy < 0:
                curr_top = actor.top
                next_top = curr_top + vy
                if curr_top >= self.bottom - self._EPS and next_top <= self.bottom + self._EPS:
                    actor.top = self.bottom
                    self._stop_vertical(actor)
                    return self.suspendable

        # If we don't overlap, nothing more to do.
        if not actor.colliderect(self):
            return False

        # Stable resolution for remaining overlaps (often caused by horizontal movement).
        # Prefer vertical resolution based on motion/relative position to reduce corner jitter.
        if vy >= 0 and actor.centery <= self.centery:
            actor.bottom = self.top
            self._stop_vertical(actor)
            return True

        if vy <= 0 and actor.centery >= self.centery:
            actor.top = self.bottom
            self._stop_vertical(actor)
            return self.suspendable

        # Otherwise, push out horizontally.
        overlap_left = actor.right - self.left
        overlap_right = self.right - actor.left

        if overlap_left < overlap_right:
            actor.x -= overlap_left
        else:
            actor.x += overlap_right

        if self.sticky:
            self._stop_vertical(actor)

        return True

class Button:

  def __init__(
    self,
    text,
    pos,
    size,
    *,
    fontsize=36,
    fontname=None,
    text_color="black",
    bg_color="white",
    hover_color="lightgray",
    pressed_color="gray",
    border_color="black",
    border_width=2,
    enabled=True,
  ):
    self.pos = pos
    self.size = size
    self.text = text

    self.fontsize = fontsize
    self.fontname = fontname
    self.text_color = text_color

    self.bg_color = bg_color
    self.hover_color = hover_color
    self.pressed_color = pressed_color
    self.border_color = border_color
    self.border_width = border_width

    self.enabled = enabled

    self._is_pressed = False
    self._is_hovered = False

  @property
  def width(self):
    return int(self.size[0])

  @property
  def height(self):
    return int(self.size[1])

  @property
  def rect(self):
    r = pygame.Rect(0, 0, self.width, self.height)
    r.center = self.pos
    return r

  def collidepoint(self, x, y=None):
    if y is None:
      x, y = x
    return self.rect.collidepoint(x, y)

  def update(self, mouse_pos=None):
    """Optionnel : met à jour l'état hover.

    Tu peux appeler `button.update(mouse_pos)` dans `update()`.
    """
    if mouse_pos is None:
      mouse_pos = pygame.mouse.get_pos()
    self._is_hovered = self.enabled and self.collidepoint(mouse_pos)

  def draw(self):
    r = self.rect

    if not self.enabled:
      color = "darkgray"
    elif self._is_pressed:
      color = self.pressed_color
    elif self._is_hovered:
      color = self.hover_color
    else:
      color = self.bg_color

    screen.draw.filled_rect(r, color)
    if self.border_width and self.border_width > 0:
      screen.draw.rect(r, self.border_color)

      screen.draw.text(
      str(self.text),
      center=r.center,
      fontsize=self.fontsize,
      fontname=self.fontname,
      color=self.text_color,
    )

