import pgzrun
from pgzhelper import *

TITLE = 'Platformer'

WIDTH = 800
HEIGHT = 600

pgzrun.go()