from cmath import phase

import pyttsx3 # Les textes récités seront geré avec pyttsx3
import pygame # La musique du jeu sera geré avec pygame.
from tkinter import * # L'affichage de fenêtre sera geré avec tkinter.

class Vocaux:
    def __init__(self):
        self.parole = pyttsx3.init()

    def vocalises(self, phrase):  # Fonction qui dicte les phrases
        self.parole.say(phrase)  # Dis la phrase
        self.parole.runAndWait()  # Puis s'arrête

class Son: # Création de la classe qui va geré la musique.
    def __init__(self, chemin_fichier):
        pygame.mixer.init()
        pygame.mixer.music.load(chemin_fichier) # Téléchargement de la musique avec le chemin du fichier.
        pygame.mixer.music.set_volume(0.5) # Réduction du volume de la musique.

    def jouer_bruit(self, chemin_bruit, volume):
        self.bruit = pygame.mixer.Sound(chemin_bruit) # Téléchargement d'un bruit avec le chemin du fichier.
        self.bruit.set_volume(volume)  # Réduction du volume de la musique.
        self.bruit.play() # Lancer le son.


class Fenetre: # Création de la classe qui va geré l'affichage de la fenêtre ainsi que l'histoire.

    def __init__(self):
        self.fenetre = Tk() # Création de la fenêtre.

        # Variable pour la couleur du fond, très utilisée par la suite.
        self.fond = 'green'

        # personalisation de la fenetre
        self.fenetre.title("Histoire interactive") # Nom.
        self.fenetre.geometry("1280x720") # Taille.
        self.fenetre.config(background=self.fond) # Couleur.
        # Malheureusement, je ne suis pas parvenu à faire que ma fenêtre puisse s'agrandir. Cela marche, mais les boutons seront au mauvais endroit.

        # Création d'une boite ou vont être affiché les textes de l'histoire.
        self.boite = Frame(self.fenetre, bg='green', bd=4, relief=SUNKEN)
        self.boite.pack(expand=YES)

        # Bouton avec une flèche (↺)* en haut à gauche. * Copier-coller
        bouton_recommencer = Button(self.fenetre, text="↺", font=("Arial", 14), width=2, height=1, command=self.recommencer)
        # Positionné avec un petit espace depuis le bord gauche.
        bouton_recommencer.place(x=10, y=10)

        # Bouton avec une croix (✖)* en haut à droite. * Copier-coller
        bouton_fermer = Button(self.fenetre, text="✖", font=("Arial", 14), width=2, height=1, command=self.fermer_fenetre)
        # Positionné avec un petit espace depuis le bord droit.
        bouton_fermer.place(x=1230, y=10)

        # Les textes de départ.
        # Titre de situation.
        self.Texte_titre = Label(self.boite, text="Salut aventurier, montes le Cervin !", font=('Aptos', 60), bg="green",
                                 fg="white")
        self.Texte_titre.pack()

        # Question à la ligne.
        self.Texte_sous_titre = Label(self.boite, text="Premièrement, veux-tu changer la couleur de l'arrière plan ?",
                                      font=('Aptos', 30), bg="green", fg="white")
        self.Texte_sous_titre.pack()

        # Texte d'information pour le joueur.
        self.Texte_retour_vert = Label(self.fenetre,
                                       text="Appuyez 2 fois sur le même bouton pour revenir à l'écran vert.",
                                       font=('Courrier', 10), bg="green", fg="white")
        self.Texte_retour_vert.pack(pady=10, side=BOTTOM)

        # Les boutons de départ.
        # Bouton bleu affiché à gauche.
        self.bouton_bleu = Button(self.fenetre, text="Bleu", font=('Arial', 80), bg='white', fg="green",
                                  command=self.changer_couleur_bleu, height=2, width=5, relief=RAISED)
        self.bouton_bleu.place(x=100, y=350)

        # Bouton rouge affiché à droite.
        self.bouton_rouge = Button(self.fenetre, text="Rouge", font=('Arial', 80), bg='white', fg="green",
                                   command=self.changer_couleur_rouge, height=2, width=5, relief=RAISED)
        self.bouton_rouge.place(x=870, y=350)

        # Bouton "ok" pour valider la commande.
        self.bouton_ok = Button(self.fenetre, text="OK", font=('Arial', 20), bg='white', fg="black",
                                command=self.command_ok, height=2, width=5, relief=RAISED)
        self.bouton_ok.pack(pady=150, padx=35, side=BOTTOM)

        # Création de trois cœurs. Copier-coller
        self.coeur1 = Label(self.fenetre, text="❤️", font=("Arial", 50), bg="green", fg="red")
        self.coeur2 = Label(self.fenetre, text="❤️", font=("Arial", 50), bg="green", fg="red")
        self.coeur3 = Label(self.fenetre, text="❤️", font=("Arial", 50), bg="green", fg="red")

        # Placement des cœurs dans la fenêtre.
        self.coeur1.place(x=525, y=300)
        self.coeur2.place(x=605, y=300)
        self.coeur3.place(x=685, y=300)

        # Variable qui verifies le nombre de vies.
        self.vies = 3

        # Texte qui indique le nombre de vies.
        self.Texte_vie = Label(self.fenetre, text="vous avez " + str(self.vies) + " vies", font=('Courrier', 10),
                               bg="green", fg="white")
        self.Texte_vie.place(x=593, y=380)

        # Création d'un inventaire.
        self.inventaire = []

        # Texte qui indique les objets dans l'inventaire.
        self.Texte_inventaire = Label(self.fenetre, text="vous avez " + str(self.inventaire) + " dans votre inventaire", font=('Courrier', 10),
                               bg="green", fg="white")

        # Histoire.
        # Variable qui verifies les choix du joueur. Initialement sur None.
        self.choix = None

        # Variables qui verifies l'étape à laquelle se trouve le joueur.
        self.etape = 1

        # Utiliser qu'une fois pour verifier que le joueur ne tourne pas en boucle à une étape de l'histoire.
        self.afk = 0

        # Moment où le joueur parvient chez le marchand.
        # Boite qui affichera, par la suite, les boutons d'achat.
        self.zone_marchand = Frame(self.fenetre, bg=self.fond)

        self.colonne_gauche = Frame(self.zone_marchand, bg=self.fond) # Boite qui afficheras, par la suite, les boutons d'achat de la colonne gauche de self.zone_marchand.
        self.colonne_droite = Frame(self.zone_marchand, bg=self.fond) # Boite qui afficheras, par la suite, les boutons d'achat de la colonne gauche de self.zone_marchand.

        # Boutons de gauche.
        self.bouton_3vies = Button(self.colonne_gauche, text="Gagner tout de suite contre 3 vies", width=40, bg="white",
               command=self.gagner_direct)
        self.bouton_1vie = Button(self.colonne_gauche, text="Gagner une vie gratuitement", width=40, bg="white",
               command=self.gagner_vie)
        self.bouton_equipement = Button(self.colonne_gauche, text="Acheter un équipement d'escalade contre 1 vie", width=40, bg="white",
               command=self.acheter_escalade)

        # Boutons de droite
        self.bouton_planches = Button(self.colonne_droite, text="Acheter des planches avec du bois", width=40, bg="white",
               command=self.acheter_planches)
        self.bouton_bateau = Button(self.colonne_droite, text="Acheter un bateau contre des planches ou une hache", width=40, bg="white",
               command=self.acheter_bateau)
        self.bouton_pomme = Button(self.colonne_droite, text="Gagner une vie contre une pomme", width=40, bg="white",
               command=self.vendre_pomme)

        # Variables nécessaires pour certaines disparitions de boutons.
        self.vie_gratuite = 0
        self.equipement_escalade = 0
        self.hache_ou_non = 0

        # Bouton qui permet de sortir du magasin.
        self.bouton_sortie = Button(self.fenetre, text="Sortir du magasin", font=('Arial', 20), bg='white', fg="black",
                                command=self.sortir_magasins, height=2, width=15, relief=RAISED)

        # Variable permettant au programme de savoir de quelle manière le joueur à gagner ou perdu.
        self.condition_victoire = 0
        self.condition_defaite = 0

        # Musique
        self.son = Son("musique_adventure.mp3") # Lancement de la musique importé.
        pygame.mixer.music.play(loops=-1) # Fonction permettant de faire tourner la musique en boucle.

        self.vocaliseur = Vocaux()  # Création d'une instance de la classe Vocaux


    def fermer_fenetre(self): # Fonction permettant d'arrêter le jeu en fermant la fenêtre ou avec le bouton pour faire la même opération.
        self.fenetre.destroy()
        pygame.mixer.music.stop() # Fonction permettant d'arrêter la musique lorsque le joueur ne veut plus jouer.



    # Fonction qui actualise la fenêtre au changement de couleur.
    def update(self):
        texte_bg = [self.fenetre,self.boite,self.Texte_titre,self.Texte_sous_titre,self.Texte_retour_vert,self.Texte_vie,self.Texte_inventaire]
        # Appliquer la couleur au fond et à tous les textes.
        for textes in texte_bg:
            textes.config(bg=self.fond)

        # Configuration pour les textes des boutons.
        self.bouton_bleu.config(fg=self.fond)
        self.bouton_rouge.config(fg=self.fond)

        # Même chose pour les objets pas encore afficher.
        self.zone_marchand.config(bg=self.fond)
        self.colonne_droite.config(bg=self.fond)
        self.colonne_gauche.config(bg=self.fond)

        # Configuration des cœurs avec bg et fg
        coeurs = [self.coeur1, self.coeur2, self.coeur3]
        for coeur in coeurs:
            coeur.config(bg=self.fond, fg="red")



    # Action qui change la couleur du fond en bleu ou vert
    def changer_couleur_bleu(self):
        if self.fond == 'green' or self.fond == 'red':
            self.fond = 'blue' # Bleu
            Fenetre.update(self)
            self.son.jouer_bruit("blue.mp3", 0.5) # Vocal 'Bleu !'

        else: # Si le fond est déja bleu.
            self.fond = 'green' # Vert
            Fenetre.update(self)
            self.son.jouer_bruit("green.mp3", 0.5) # Vocal 'Vert !'

    # Action qui change la couleur du fond en rouge ou vert
    def changer_couleur_rouge(self):

        if self.fond == 'green' or self.fond == 'blue':
            self.fond = 'red' # Rouge.
            Fenetre.update(self)
            # Ici les cœurs change de couleur sinon on ne les voit pas.
            self.coeur1.config(fg="pink")
            self.coeur2.config(fg="pink")
            self.coeur3.config(fg="pink")
            self.son.jouer_bruit("red.mp3", 0.5) # Vocal 'Rouge !'

        else: # Si le fond est déja rouge.
            self.fond = 'green' # Vert
            Fenetre.update(self)
            self.son.jouer_bruit("green.mp3", 0.5) # Vocal 'Vert !'

    # Fonction appeler au moment où le bouton a choisi la couleur.
    def command_ok(self):
        # Changement de configuration des boutons rouge et bleu en : oui, non
        self.bouton_bleu.config(text="oui", command=lambda: self.quel_bouton("oui"))
        self.bouton_rouge.config(text="non", command=lambda: self.quel_bouton("non"))

        self.son.jouer_bruit("bravo_son.mp3", 0.5) # Jouer le son "bravo_son.mp3"

        # Plusieurs changements pour le début du jeu.
        self.bouton_ok.config(text= "Inventaire", width=10, command=self.afficher_inventaire)
        self.Texte_retour_vert.destroy()
        self.Texte_titre.config(text="Début de l'histoire")
        self.Texte_sous_titre.config(text="Voulez-vous jouer ?")


        self.fenetre.after(500,  self.vocaliseur.vocalises, "Début de l'histoire, Voulez-vous jouer ?")


    def bouton_choix(self):
        # Si le joueur appuie sur oui ou non. Renvoie à la fonction "quel_bouton avec comme indice : oui ou non
        self.bouton_bleu.config(text="oui", command=lambda: self.quel_bouton("oui"))
        self.bouton_rouge.config(text="non", command=lambda: self.quel_bouton("non"))

    def quel_bouton(self, nom): # Fonction qui permet de faire avancer l'histoire avec les choix du joueur.

        if nom == "oui":
            self.choix = True # Si oui, choix = vrai.
            print(f"Choix: {self.choix}, Étape actuelle: {self.etape}") # Ici, on peut voir sur la console à quelle étape on est et quel choix a été fait. (True)
            self.son.jouer_bruit("oui.mp3", 0.25) # Vocal 'Yes !'

        else:
            self.choix = False # Sinon, choix = faux.
            print(f"Choix: {self.choix}, Étape actuelle: {self.etape}") # Ici, on peut voir sur la console à quelle étape on est et quel choix a été fait. (False)
            self.son.jouer_bruit("non.mp3",0.08) # Vocal 'No !'

        self.histoire() # Reprendre l'histoire

    def vie_controle(self): # À chaque fois que le joueur perd une vie cette fonction se lance.

        if self.vies >= 3: # Si son nombre de vies est > ou = à 3 alors :
            self.Texte_vie.config(text="vous avez " + str(self.vies) + " vies") # Afficher le nombre de vies.
        if self.vies == 2: # Si son nombre de vies est = à 2 alors :
            self.coeur3.place_forget() # Faire disparaître le 3ᵉ cœur.
            self.son.jouer_bruit("degat_son.mp3", 0.5) # Vocal 'Arch !'
            self.Texte_vie.config(text="vous avez " + str(self.vies) + " vies") # Afficher le nombre de vies.
        if self.vies == 1: # Si son nombre de vies est = à 1 alors :
            self.coeur2.place_forget() # Faire disparaître le 2ᵉ cœur.
            self.Texte_vie.config(text="vous avez " + str(self.vies) + " vies") # Afficher le nombre de vies.
            self.son.jouer_bruit("degat_son.mp3", 0.5) # Vocal 'Arch !'
        if self.vies <= 0: # Si son nombre de vies est < ou = à 1 alors :

            self.Texte_sous_titre.config(text="Fin, vous avez perdu toutes vos vies") # On change le sous-titre, mais on laisse le titre afin de faire comprendre la défaite.
             # On fait disparaître le reste.
            self.bouton_bleu.destroy()
            self.bouton_rouge.destroy()
            self.coeur1.destroy()
            self.coeur2.destroy()
            self.coeur3.destroy()
            self.Texte_vie.destroy()

            self.son.jouer_bruit("defeate_son.mp3", 0.5) # Son de défaite.

            self.bouton_ok.config(text= "Restart", command=self.recommencer) # Un bouton restart est placé afin de pouvoir rejouer sans relancer le programme.
            self.bouton_ok.pack(pady=150, padx=35, side=BOTTOM) # Placement du bouton "Restart"

            self.condition_defaite = 1
            self.fenetre.after(500, self.vocaliseur.vocalises, "Fin, vous avez perdu toutes vos vies")


    def recommencer(self): # Fonction appelée pour recommencer le jeu.
        self.fenetre.destroy()  # Ferme l’ancienne fenêtre
        nouvelle_fenetre = Fenetre()  # Crée une nouvelle fenêtre.
        nouvelle_fenetre.fenetre.mainloop() # Faire tourner la nouvelle fenêtre.

    def afficher_inventaire(self): # Fonction qui affiche l'inventaire.
        self.Texte_inventaire = Label(self.fenetre, text="vous avez " + str(self.inventaire) + " dans votre inventaire",font=('Courrier', 10),bg=self.fond, fg="white")
        self.Texte_inventaire.place(x=523, y=700)
        self.bouton_ok.config(command=self.supprimer_inventaire) # La nouvelle fonction du bouton est maintenant de faire disparaître l'inventaire.
        self.son.jouer_bruit("open_bag.mp3", 0.5) # Son d'ouverture/fermeture de sac.

    def supprimer_inventaire(self): # Fonction pour faire disparaître l'inventaire.
        self.Texte_inventaire.destroy()
        self.bouton_ok.config(command=self.afficher_inventaire) # La nouvelle fonction du bouton est maintenant de faire disparaître l'inventaire à nouveau.
        self.son.jouer_bruit("open_bag.mp3", 0.5) # Son d'ouverture/fermeture de sac.

     # Objectif : Quand j'appuie une fois l'inventaire s'affiche, la deuxième fois, il disparaît'


    def histoire(self): # Partie qui gère l'histoire.
        # Etape 1
        if self.etape == 1:
            if self.choix:  # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="L'aventure commence !")
                self.Texte_sous_titre.config(text="Voulez-vous entrer dans la forêt ?")
                self.fenetre.after(500, self.vocaliseur.vocalises, "L'aventure commence ! Voulez-vous entrer dans la forêt ?")

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="Vous avez choisi de ne pas jouer.")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Vous avez choisi de ne pas jouer.")
                self.vies -= 3 # - 3 vies
                self.vie_controle() # Verification des vies, --> défaite.

            # Passer à l'étape suivante
            self.etape = 2
            self.bouton_choix()  # Afficher à nouveau les boutons pour la prochaine étape

        # Etape 2 : Choix dans la forêt
        elif self.etape == 2:
            if self.choix:  # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Vous entrez dans la forêt. 2 sentiers s'offrent à vous.",font=("Aptos", 30))
                self.Texte_sous_titre.config(text=" Voulez-vous suivre celui de droite ?")
                if self.afk == 0 :
                    self.fenetre.after(500,self.vocaliseur.vocalises, "Vous entrez dans la forêt. 2 sentiers s'offrent à vous. Voulez-vous suivre celui de droite ?")
                self.afk += 1 # Pour si le joueur dit non pour le chemin de droite et gauche.
                self.etape = 4
                self.bouton_choix() # Passer à l'étape suivante
                if self.afk > 2: # Si le joueur dit non pour le chemin de droite et gauche.
                    self.Texte_titre.config(text="Vous n'arrivez pas à vous décider. Ça vous fatigue et vous perdez un vie.")
                    self.Texte_sous_titre.config(text="Voulez-vous refaire un choix de chemin ?")
                    self.fenetre.after(500, self.vocaliseur.vocalises, "Vous n'arrivez pas à vous décider. Ça vous fatigue et vous perdez une vie.")
                    self.vies -= 1
                    self.vie_controle() # Vérification de vie.
                    if self.condition_defaite == 0:
                        self.fenetre.after(500, self.vocaliseur.vocalises,"Voulez-vous refaire un choix de chemin ?")
                    self.bouton_choix()
                    self.etape = 3

            else:  # Si le joueur a choisi "non".
                self.etape = 4
                self.choix = True
                self.histoire() # Passer à l'étape suivante



        # Etape 3 : Partie afk
        elif self.etape == 3:
            if self.choix:  # Si le joueur a choisi "oui".
                self.afk -= 3 # réinitialisation d'afk.
                self.revenir_au_sentier() # Etape 2, True

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="Il a commencé à neiger, vous avez froid et perdez une vie. Quelqu'un vous a donné une hache.", font=('Aptos', 20))
                self.Texte_sous_titre.config(text="Voulez-vous aller chez le marchand ?")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Il a commencé à neiger, vous avez froid et perdez une vie. Quelqu'un vous a donné une hache.")
                self.vies -= 1
                self.vie_controle() # Vérification de vie.
                if self.condition_defaite == 0:
                    self.fenetre.after(500, self.vocaliseur.vocalises, "Voulez-vous aller chez le marchand ?")
                self.hache_ou_non =+ 1
                self.inventaire.append("hache") # ajouter 'hache' dans l'inventaire.
                self.etape = 17

        # Etape 4 : Suivre le sentier ou non
        elif self.etape == 4:
            if self.choix:  # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Vous suivez un sentier qui débouche sur un lac somptueux, vous apercevez le Cervin derrière.", font=('Aptos', 20))
                self.Texte_sous_titre.config(text="Voulez vous traverser le lac ?")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Vous suivez un sentier qui débouche sur un lac somptueux, vous apercevez le Cervin derrière. Voulez vous traverser le lac ?")
                self.etape = 9

            else:  # Si le joueur a choisi "non".
                self.Texte_sous_titre.config(text="Alors celui de gauche ?")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Alors celui de gauche ?")
                self.etape = 5

            self.bouton_choix()

        # Etape 4 : Suivre le chemin de gauche.
        elif self.etape == 5:
            if self.choix :  # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Il n'y a rien ici, en plus une branche vous est tombé sur la tête.")
                self.Texte_sous_titre.config(text="Voulez-vous rebrousser chemin ?")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Il n'y a rien ici, en plus une branche vous est tombé sur la tête.")
                self.vies -= 1
                self.vie_controle() # Vérification de vie.
                if self.condition_defaite == 0:
                    self.fenetre.after(500, self.vocaliseur.vocalises, " Voulez-vous rebrousser chemin ?")
                self.etape = 6
                self.bouton_choix()

            else:  # Si le joueur a choisi "non".
                self.afk += 2
                self.revenir_au_sentier() # Etape 2 bis, True

        # Etape 6 : Chemin de gauche : continuer ou arrêter.
        elif self.etape == 6:
            if self.choix:  # Si le joueur a choisi "oui".
                self.revenir_au_sentier() # Etape 2, True

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(
                    text="Vous mouriez de faim, un gentil homme vous a donné une pomme... ")
                self.Texte_sous_titre.config(text="Voulez-vous manger la pomme ?")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Vous mouriez de faim, un gentil homme vous a donné une pomme... ")
                self.vies -= 1
                self.vie_controle()
                if self.condition_defaite == 0:
                    self.fenetre.after(500, self.vocaliseur.vocalises, "Voulez-vous manger la pomme ?")
                self.etape = 7
                self.bouton_choix()
                self.inventaire.append("pomme") # ajouter 'pomme' dans l'inventaire.

        # Etape 7 : Manger pomme ou non.
        elif self.etape == 7:
            if self.choix:  # Si le joueur a choisi "oui".
                self.Texte_titre.config( text="La pomme était pourrie.")
                self.fenetre.after(500, self.vocaliseur.vocalises, "La pomme était pourrie.")
                self.vies -= 1 # Vérification de vie.
                self.vie_controle() #Pas de suite, car fin de toute facon.

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="Vous pouvez peut-être l'échanger chez le marchand.")
                self.Texte_sous_titre.config(text="Voulez-vous aller chez le marchand ?")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Vous pouvez peut-être l'échanger chez le marchand. Voulez-vous aller chez le marchand ?")
                self.etape = 8
                self.bouton_choix()

        # Etape 8 : Marchand ou non.
        elif self.etape == 8:
            if self.choix:  # Si le joueur a choisi "oui".
                self.revenir_marchand() # Etape 17, True

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="La neige est tombée et vous avez extrêmement froid.")
                self.fenetre.after(500, self.vocaliseur.vocalises, "La neige est tombée et vous avez extrêmement froid.")
                self.vies -= 1
                self.vie_controle()  # Pas de suite, car fin de toute facon.

        # Etape 9 : Traverser le lac ou non.
        elif self.etape == 9:
            if self.choix:  # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Comment faire, vous n'avez pas de bateau.")
                self.Texte_sous_titre.config(text="Voulez vous en chercher un ? ")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Comment faire, vous n'avez pas de bateau. Voulez vous en chercher un ?")
                self.etape = 10
                self.bouton_choix()

            else:  # Si le joueur a choisi "non".
                self.Texte_sous_titre.config(text="Alors voulez vous allez chez le marchand du lac ?")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Alors voulez vous allez chez le marchand du lac ?")
                self.etape = 17

        # Etape 10 : Chercher bateau ou pas.
        elif self.etape == 10:
            if self.choix:  # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Cela vous prend trop d'énergie et vous perdez une vie.")
                self.Texte_sous_titre.config(text="Voulez-vous rebrousser chemin ? ")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Cela vous prend trop de d'énergie et vous perdez une vie. ")
                self.vies -= 1
                if self.condition_defaite == 0:
                    self.fenetre.after(500, self.vocaliseur.vocalises,"Voulez-vous rebrousser chemin ?")
                self.vie_controle() # Vérification de vie.
                self.etape = 11


            else:  # Si le joueur a choisi "non".
                self.Texte_sous_titre.config(text="Alors voulez-vous en construire un ?")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Alors voulez-vous en construire un ?")
                self.etape = 12

            self.bouton_choix()

        # Etape 11 : revenir de la recherche de bateau ou non.
        elif self.etape == 11:
            if self.choix:  # Si le joueur a choisi "oui".
                self.revenir_au_lac() # Etape 4, True.

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="La fatigue est intense et vous perdez encore une vie.")
                self.Texte_sous_titre.config(text="Voulez-vous aller en forêt ? ")
                self.fenetre.after(500, self.vocaliseur.vocalises, "La fatigue est intense et vous perdez encore une vie. ")
                self.vies -= 1
                self.vie_controle() # Vérification de vie.
                if self.condition_defaite == 0:
                    self.fenetre.after(500, self.vocaliseur.vocalises,"Voulez-vous aller en forêt ?")
                self.etape = 13
                self.bouton_choix()

        # Etape 12 : construire bateau ou pas.
        elif self.etape == 12:
            if self.choix:  # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Vous n'avez pas de bois.")
                self.Texte_sous_titre.config(text="Voulez-vous aller dans la forêt ? ")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Vous n'avez pas de bois. Voulez-vous aller dans la forêt ? ")
                self.etape = 13
                self.bouton_choix()

            else:  # Si le joueur a choisi "non".
                self.Texte_sous_titre.config(text="Alors voulez-vous aller chez le marchand du lac ?")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Alors voulez-vous aller chez le marchand du lac ?")
                self.etape = 17

        # Etape 13 : Forêt ou non.
        elif self.etape == 13:
            if self.choix:  # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Il n'y a rien ici. Cette marche vous a fatigué et vous avez perdu une vie.")
                self.Texte_sous_titre.config(text="Voulez-vous rebrousser chemin ? ")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Il n'y a rien ici. Cette marche vous a fatigué et vous avez perdu une vie.  ")
                self.vies -= 1
                self.vie_controle() # Vérification de vie.
                if self.condition_defaite == 0:
                    self.fenetre.after(500, self.vocaliseur.vocalises, "Voulez-vous rebrousser chemin ?")
                self.etape = 14
                self.bouton_choix()

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="Vous avez suivi un chemin qui vous a amené en face d'un magasin.")
                self.Texte_sous_titre.config(text="Alors voulez-vous aller chez le marchand du lac ?")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Vous avez suivi un chemin qui vous a amené en face d'un magasin. Alors voulez-vous aller chez le marchand du lac ?")
                self.etape = 17

        # Etape 14 : Forêt : rebrousser chemin ou non.
        elif self.etape == 14:
            if self.choix: # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Lors de votre retour, vous êtes tombé nez à nez sur un ours affamé. Il vous a dévoré sans hésitation")
                self.fenetre.after(500,  self.vocaliseur.vocalises, "Lors de votre retour, vous êtes tombé nez à nez sur un ours affamé. Il vous a dévoré sans hésitation")
                self.vies -= 3
                self.vie_controle() #Fin de toute manière


            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="Vous trouver une scie coincée dans un arbre.")
                self.Texte_sous_titre.config(text="Voulez-vous la prendre ?")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Vous trouver une scie coincée dans un arbre. Voulez-vous la prendre ?")
                self.etape = 15
                self.bouton_choix()

        # Etape 15 : prendre scie ou non.
        elif self.etape == 15:
            if self.choix: # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Vous voilà muni d'une très jolie scie")
                self.Texte_sous_titre.config(text="Voulez-vous couper du bois ?")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Vous trouver une scie coincée dans un arbre. Voulez-vous la prendre ?")
                self.etape = 16
                self.bouton_choix()

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="Alors allez-vous chez le marchand ?")
                self.fenetre.after(500,  self.vocaliseur.vocalises, "Alors allez-vous chez le marchand ?")
                self.etape = 17
                self.bouton_choix()

        # Etape 16 : couper bois ou non.
        elif self.etape == 16:
            if self.choix: # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Vous avez maintenant du bois, mais vous vous êtes blessé avec la scie.")
                self.Texte_sous_titre.config(text="Voulez-vous aller chez le marchand ?")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Vous avez maintenant du bois, mais vous vous êtes blessé avec la scie. ")
                self.inventaire.append("bois") # ajouter 'bois' dans l'inventaire
                self.vies -= 1
                self.vie_controle()  # Vérification de vie.
                if self.condition_defaite == 0:
                    self.fenetre.after(500, self.vocaliseur.vocalises, "Voulez-vous aller chez le marchand ?")
                self.etape = 17
                self.bouton_choix()

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="Alors allez-vous chez le marchand ?")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Alors allez-vous chez le marchand ?")
                self.etape = 17
                self.bouton_choix()

        # Etape 17 : Marchand : Tout les chemin gagnant mènent ici.
        elif self.etape == 17:
            if self.choix: # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Vous êtes chez le marchand.")
                self.Texte_sous_titre.config(text="Vous pouvez acheter ce que vous voulez.")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Vous êtes chez le marchand. Vous pouvez acheter ce que vous voulez.")
                self.interface_marchand() # Afficher les boutons du magasin.

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="Une horde de loups vous a chassé et vous êtes devant la maison du marchand.")
                self.Texte_sous_titre.config(text="Voulez-vous entrer ?")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Une horde de loups vous a chassé et vous êtes devant la maison du marchand. Voulez-vous entrer ?")
                self.etape = 18
                self.bouton_choix()

        # Etape 18 : entrer chez le marchand ou non.
        elif self.etape == 18:
            if self.choix:  # Si le joueur a choisi "oui".
                self.revenir_marchand() # retourner chez le marchand. étape 17, True

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="La horde de loups vous a dévoré sans pitié.")
                self.fenetre.after(500, self.vocaliseur.vocalises,"La horde de loups vous a dévoré sans pitié.")
                self.vies -= 3
                self.vie_controle()  # Fin de toute manière

        # Etape 19 : sortie du magasin.
        elif self.etape == 19:
            self.condition_victoire += 1 # À partir d'ici, il est seulement possible de gagner en montant au sommet du Cervin.
            if "bateau" in self.inventaire: # Si le joueur a acheté un bateau alors :
                self.Texte_titre.config(text="Vous êtes sorti du magasin. Mais une horde de loups vous as suivi.")
                self.Texte_sous_titre.config(text="Voulez-vous traverser le lac avec votre nouveau bateau ?")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Vous êtes sorti du magasin. Mais une horde de loups vous as suivi. Voulez-vous traverser le lac avec votre nouveau bateau ?")
                self.etape = 20

            else: # Si le joueur n'en a pas acheté.
                self.Texte_titre.config(text="Vous êtes sorti du magasin. Mais une horde de loups vous a suivi.")
                self.Texte_sous_titre.config(text="Voulez-vous faire le tour du lac en courant ?")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Vous êtes sorti du magasin. Mais une horde de loups vous a suivi. Voulez-vous faire le tour du lac en courant ?")
                self.etape = 23

        # Etape 20 : traverser le lac avec le bateau ou non.
        elif self.etape == 20:
            if self.choix: # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Vous êtes arrivé de l'autre coté. Il ne vous reste plus qu'à monter.")
                self.Texte_sous_titre.config(text="Voulez-vous grimper avec un équipement ?")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Vous êtes arrivé de l'autre coté. Il ne vous reste plus qu'à monter. Voulez-vous grimper avec un équipement ?")
                self.etape = 21

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="La horde de loups vous a dévoré sans pitié.")
                self.fenetre.after(500, self.vocaliseur.vocalises,"La horde de loups vous a dévoré sans pitié.")
                self.vies -= 3
                self.vie_controle()  # Fin de toute manière

        # Etape 21: grimper ou non.
        elif self.etape == 21:
            if self.choix: # Si le joueur a choisi "oui".
                if "équipement d'escalade" in self.inventaire: # Si le joueur a acheté un équipement d'escalade alors :
                    self.victoire() # victoire.

                else: # Si le joueur n'en a pas acheté.
                    self.Texte_titre.config(text="Vous n'avez pas d'équipement d'escalade.")
                    self.Texte_sous_titre.config(text="Voulez-vous retournez au magasin ?")
                    self.fenetre.after(500, self.vocaliseur.vocalises, "Vous n'avez pas d'équipement d'escalade. Voulez-vous retournez au magasin ?")
                    self.etape = 22

            else: # Si le joueur a choisi "non".
                self.revenir_cervin() # Etape 22, False


        # Etape 22 : retourner au magasin ou non.
        elif self.etape == 22:
            if self.choix: # Si le joueur a choisi "oui".
                self.revenir_marchand() # retourner chez le marchand. étape 17, True

            else: # Si le joueur a choisi "non".
                self.Texte_sous_titre.config(text="Voulez-vous suivre le chemin qui monte au sommet ?")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Voulez-vous suivre le chemin qui monte au sommet ?")
                self.etape = 24

        # Etape 23 : faire le tour du lac ou non.
        elif self.etape == 23:
            if self.choix: # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Le chef de meute vous a combattu et vous l'avez vaincu. Ce combat vous a fait perdre une vie.")
                self.Texte_sous_titre.config(text="Voulez-vous suivre le chemin qui monte au sommet ?")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Le chef de meute vous a combattu et vous l'avez vaincu. Ce combat vous a fait perdre une vie. ")
                self.vies -= 1
                self.vie_controle() # Vérification de vie.
                if self.condition_defaite == 0:
                    self.fenetre.after(500, self.vocaliseur.vocalises,"Voulez-vous suivre le chemin qui monte au sommet ?")
                self.etape = 24

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="La horde de loups vous a dévoré sans pitié.")
                self.vies -= 3
                self.vie_controle()  # Fin de toute manière

        # Etape 24 : suivre le chemin pour le sommet ou pas.
        elif self.etape == 24:
            if self.choix: # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Vous êtes arrivé au refuge à bout de souffle. Le manque d'énergie vous a fait perdre une vie.")
                self.Texte_sous_titre.config(text="Voulez-vous vous reposer avant de partir?")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Vous êtes arrivé au refuge à bout de souffle. Le manque d'énergie vous a fait perdre une vie. ")
                self.vies -= 1
                self.vie_controle() # Vérification de vie.
                if self.condition_defaite == 0:
                    self.fenetre.after(500, self.vocaliseur.vocalises, "Voulez-vous vous reposer avant de partir ?")
                self.etape = 25

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="Vous avez suivi un autre chemin et vous êtes tombé dans une crevasse. Personne ne vous a secouru.")
                self.fenetre.after(500, self.vocaliseur.vocalises, "Vous avez suivi un autre chemin et vous êtes tombé dans une crevasse. Personne ne vous a secouru.")
                self.vies -= 3
                self.vie_controle()  # Fin de toute manière

        # Etape 25 : se reposer ou non.
        elif self.etape == 25:
            if self.choix: # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Vous avez bien fait, vous êtes maintenant prêt à grimper.")
                self.Texte_sous_titre.config(text="Voulez-vous monter au sommet ?")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Vous avez bien fait, vous êtes maintenant prêt à grimper. Voulez-vous monter au sommet ?")
                self.etape = 26

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="Vous êtes parti de nuit et avez fait une chute fatale lors de votre ascension.")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Vous êtes parti de nuit et avez fait une chute fatale lors de votre ascension.")
                self.vies -= 3
                self.vie_controle()  # Fin de toute manière

        # Etape 26 : monter au sommet ou non.
        elif self.etape == 26:
            if self.choix: # Si le joueur a choisi "oui".
                self.Texte_titre.config(text="Vous êtes arrivé au sommet sans aucun soucis")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Vous êtes arrivé au sommet sans aucun soucis")
                self.victoire() # victoire

            else:  # Si le joueur a choisi "non".
                self.Texte_titre.config(text="Vous abandonnez maintenant ? a dis le propriétaire du refuge. Vous êtes parti grimper.")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Vous abandonnez maintenant ? a dis le propriétaire du refuge. Vous êtes parti grimper.")
                self.victoire() # victoire


    def revenir_au_sentier(self):
        # Revenir à l'étape 2 (le choix du sentier)
        self.etape = 2
        self.choix = True
        self.histoire()


    def revenir_au_lac(self):
        # Revenir à l'étape 4 (le choix du lac)
        self.etape = 4
        self.choix = True
        self.histoire()


    def revenir_marchand(self):
        # Revenir/aller à l'étape 17 (marchand)
        self.etape = 17
        self.histoire()
        self.choix = True

    def revenir_cervin(self):
        # Revenir à l'étape 22 (le choix du chemin vers le sommet)
        self.etape = 22
        self.histoire()
        self.choix = False

    def interface_marchand(self):

        # cacher les boutons oui/non
        self.bouton_bleu.place_forget()
        self.bouton_rouge.place_forget()

        # Créer un cadre pour les options du marchand et positionner tous les boutons déjà crée

        self.zone_marchand.pack(pady=20)

        self.colonne_gauche.pack(side=LEFT, padx=40)
        self.colonne_droite.pack(side=RIGHT, padx=40)

        self.bouton_3vies.pack(pady=5)
        self.bouton_1vie.pack(pady=5)
        self.bouton_equipement.pack(pady=5)

        self.bouton_planches.pack(pady=5)
        self.bouton_bateau.pack(pady=5)
        self.bouton_pomme.pack(pady=5)

        self.bouton_sortie.place(x=515,y=600)




    def gagner_direct(self):
        if self.vies >= 3:
            self.victoire() # victoire

        else:
            self.Texte_sous_titre.config(text="Pas assez de vies.")
            self.fenetre.after(500, self.vocaliseur.vocalises,"Pas assez de vies.")

    def gagner_vie(self):
        if self.vie_gratuite >= 1:
            self.Texte_sous_titre.config(text="Vous avez déja acheté 1 vie.")
            self.fenetre.after(500, self.vocaliseur.vocalises,"Vous avez déja acheté 1 vie.")
            self.bouton_1vie.pack_forget() # faire disparaître le bouton.


        else:
            self.vies += 1
            self.Texte_sous_titre.config(text="+1 vie !")
            if self.vies == 2:
                self.coeur2.place(x=605, y=300) # Placer le cœur pour la nouvelle vie.
            if self.vies == 3:
                 self.coeur3.place(x=685, y=300) # Placer le cœur pour la nouvelle vie.
            self.vie_gratuite += 1
            self.Texte_vie.config(text="vous avez " + str(self.vies) + " vies")  # Afficher le nombre de vies.
            self.bouton_1vie.pack_forget() # faire disparaître le bouton.
            self.son.jouer_bruit("bravo_son.mp3", 0.5) # Jouer le son "bravo_son.mp3"

            self.fenetre.after(500,self.vocaliseur.vocalises,"plus une vie !")


    def acheter_escalade(self):
        if self.equipement_escalade >= 1:
            self.Texte_sous_titre.config(text="Vous avez déja acheté 1 équipement d'escalade.")
            self.fenetre.after(500, self.vocaliseur.vocalises,"Vous avez déja acheté 1 équipement d'escalade.")
            self.bouton_equipement.pack_forget() # faire disparaître le bouton.


        else:
            if self.vies >= 1:
                self.vies -= 1
                self.inventaire.append("équipement d'escalade") # Ajouter "équipement d'escalade" dans l'inventaire.
                self.vie_controle() # enlever la vie
                self.Texte_sous_titre.config(text="Équipement d'escalade acheté.")
                self.equipement_escalade += 1
                self.bouton_equipement.pack_forget() # faire disparaître le bouton.
                self.son.jouer_bruit("bravo_son.mp3", 0.5)  # Jouer le son "bravo_son.mp3"
                self.fenetre.after(500, self.vocaliseur.vocalises,"Équipement d'escalade acheté.")

            else:
                self.Texte_sous_titre.config(text="Pas assez de vies.")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Pas assez de vies.")
                self.bouton_equipement.pack_forget() # faire disparaître le bouton.

    def acheter_planches(self):
        if "bois" in self.inventaire:
            self.inventaire.remove("bois") # enlever 'bois' dans l'inventaire.
            self.inventaire.append("planches") # ajouter 'planche' dans l'inventaire.
            self.Texte_sous_titre.config(text="Planches achetées.")
            self.bouton_planches.pack_forget() # faire disparaître le bouton.
            self.son.jouer_bruit("bravo_son.mp3", 0.5) # Jouer le son "bravo_son.mp3"
            self.fenetre.after(500, self.vocaliseur.vocalises,"Planches achetées.")
        else:
            self.Texte_sous_titre.config(text="Pas de bois.")
            self.fenetre.after(500, self.vocaliseur.vocalises,"Pas de bois.")
            self.bouton_planches.pack_forget() # faire disparaître le bouton.



    def acheter_bateau(self):
        if "planches" in self.inventaire or "hache" in self.inventaire:
            self.inventaire.append("bateau") # ajouter 'bateau' dans l'inventaire.

            if self.hache_ou_non == 0:
                self.Texte_sous_titre.config(text="Bateau acheté avec des planches.")
                self.inventaire.remove("planches") # enlever 'planches' dans l'inventaire.
                self.fenetre.after(500, self.vocaliseur.vocalises,"Bateau acheté avec des planches.")
            else:
                self.Texte_sous_titre.config(text="Bateau acheté avec une hache.")
                self.fenetre.after(500, self.vocaliseur.vocalises,"Bateau acheté avec une hache.")
                self.inventaire.remove("hache") # enlever 'hache' dans l'inventaire.
            self.bouton_bateau.pack_forget() # faire disparaître le bouton.
            self.son.jouer_bruit("bravo_son.mp3", 0.5) # Jouer le son "bravo_son.mp3"

        else:
            self.Texte_sous_titre.config(text="Pas de planches et pas de hache.")
            self.fenetre.after(500, self.vocaliseur.vocalises,"Pas de planches et pas de hache.")




    def vendre_pomme(self):
        if "pomme" in self.inventaire:
            self.inventaire.remove("pomme") # enlever 'pomme' dans l'inventaire.
            self.vies += 1
            self.Texte_vie.config(text="vous avez " + str(self.vies) + " vies")  # Afficher le nombre de vies.
            self.Texte_sous_titre.config(text="Pomme vendue ! +1 vie.")
            if self.vies == 2:
                self.coeur2.place(x=605, y=300) # Placer le cœur pour la nouvelle vie.
            if self.vies == 3:
                 self.coeur3.place(x=685, y=300) # Placer le cœur pour la nouvelle vie.
            self.bouton_pomme.pack_forget() # faire disparaître le bouton.
            self.son.jouer_bruit("bravo_son.mp3", 0.5) # Jouer le son "bravo_son.mp3"
            self.fenetre.after(500,  self.vocaliseur.vocalises,"Pomme vendue ! plus une vie")

        else:
            self.Texte_sous_titre.config(text="Pas de pomme à vendre.")
            self.fenetre.after(500,  self.vocaliseur.vocalises,"Pas de pomme à vendre.")
            self.bouton_pomme.pack_forget() # faire disparaître le bouton.

    def sortir_magasins(self):
        # Replacer le bouton oui et non.
        self.bouton_bleu.place(x=100, y= 350)
        self.bouton_rouge.place(x=870, y= 350)

        # Faire disparaitre les boutons du magasin.
        self.bouton_3vies.pack_forget()
        self.bouton_1vie.pack_forget()
        self.bouton_equipement.pack_forget()
        self.bouton_planches.pack_forget()
        self.bouton_bateau.pack_forget()
        self.bouton_pomme.pack_forget()
        self.colonne_droite.pack_forget()
        self.colonne_gauche.pack_forget()
        self.zone_marchand.pack_forget()
        self.bouton_sortie.place_forget()

        self.son.jouer_bruit("bravo_son.mp3", 0.5) # Jouer le son "bravo_son.mp3"

        self.etape = 19
        self.histoire() # Recommencer l'histoire à l'étape 19




    def victoire(self):
        self.son.jouer_bruit("son_victoire.mp3", 0.5) # Jouer le son pour la victoire.
        # Détruire tous les boutons sauf les textes et le bouton pour recommencer.
        self.coeur1.destroy()
        self.coeur2.destroy()
        self.coeur3.destroy()
        self.Texte_vie.destroy()
        self.Texte_inventaire.destroy()
        self.bouton_3vies.destroy()
        self.bouton_1vie.destroy()
        self.bouton_equipement.destroy()
        self.bouton_planches.destroy()
        self.bouton_bateau.destroy()
        self.bouton_pomme.destroy()
        self.zone_marchand.destroy()
        self.bouton_sortie.destroy()
        self.bouton_rouge.destroy()
        self.bouton_bleu.destroy()

        # Vérifier comment le joueur à gagner et utiliser la bonne phrase.
        if self.condition_victoire == 0:
            self.Texte_sous_titre.config(text="Bravo vous avez gagné grâce à votre achat !")
            self.fenetre.after(500, self.vocaliseur.vocalises,"Bravo vous avez gagné grâce à votre achat !")

        else:
            self.Texte_sous_titre.config(text="Bravo vous avez gagné en arrivant au sommet !")
            self.fenetre.after(500, self.vocaliseur.vocalises,"Bravo vous avez gagné en arrivant au sommet !")

        self.bouton_ok.config(text= "Restart", command=self.recommencer) # Changer le bouton inventaire en un bouton 'Restart'.




Fenetre().fenetre.mainloop() # Faire tourner le jeu en boucle.
