vie = 100
ordi = 0
inventaire = []

from PIL import Image
Image.open('Homestead_Upper_Barn_Computer.webp').show()

print("Vous arrivez dans une grange. Il fait nuit et vous êtes seul. Votre vie est à" , vie)
print("Vous sortez de la grange et croisez une gentille sorcière.")

#dialogue avec Kinchana
print("Kinchana: Coucou mon petit! Bienvenu dans Flee the Laladu.")
print("Ton but ici est de t'enfuir en piratant des ordinateurs cachés que tu pourras trouver tout en échappant des griffes de Laladu, qui est le monstre qui reigne sur cette ferme. Toutes décisions à un impact.")
ordi = ordi + 1
print("Pour mieux comprendre je te donne un premier ordinateur à pirater. Vous obtenez un ordinateur:", ordi)

#marteau/vitesse
reponse = input("Avant que tu partes à la recherche de ta liberté, je te laisse choisir entre une potion qui double ta vitesse ou un marteau.")
while reponse not in ["marteau", "vitesse", "potion"]:
    reponse = input ("marteau ou vitesse?")

if reponse == "marteau":
    inventaire.append("marteau")
    print("Vous obtenez un marteau:", inventaire)


elif reponse == "vitesse"or "potion":
    inventaire.append("vitesse")
    print("Vous doublez votre vitesse:", inventaire)

#croiser Laladu
from playsound import playsound
playsound('bruitlaladu.mp4')
print("En sortant de la grange, vous croiser Laladu qui vous attaque!!!")

if "marteau" in inventaire:
    print("Vous frappez Laladu et vous fuyez sans perdre de vie:", vie)

if "vitesse" in inventaire:
    vie = vie - 40
    print("Vous arrivez à fuir mais l'épuisement de la fuite vous fait perdre de la vie:", vie)

#En fuyant vous trouvez le labyrinthe


def labyrinthe():
    print("Pendant la fuite vous apercevez un labyrinthe, vous décider de l'explorer.")
    print("Trois entrées sont libres.")
    reponse = input("Quel côté voulez vous explorer, gauche, droite ou continuer tout droit?")
    while reponse not in ["gauche", "droite", "tout droit"]:
        reponse = input("Dans quel direction voulez vous aller?")

    if reponse == "gauche":
        gauche()

    elif reponse == "droite":
        droite()

    elif reponse == "tout droit":
        droit()



def gauche():
    print("Vous trouvez un ordinateur déjà pirater par une certaine Cocotte.:", ordi)
    print("Après vous être perdu en cherchant d'autres ordinateurs, vous revenez à l'entrer du labyrinthe.")
    labyrinthe()


def droit():
    print("Laladu vous suit et vous asssome par derrière, vous avez flop. Elle vous enferme dans une capsule et vous mourrez congelé.")
    print("GAME OVER")


def marteau():
    global vie
    if "marteau" in inventaire:
        vie = vie - 40
        print("Laladu arrive à vous frapper.:", vie)
        print("Vous fuyez sans aider Cocotte.")
        print("Plus tard, Cocotte vous retrouve, elle est très énervée car vous l'avez abandonné.")
        vie = vie - 60
        print("Elle vous prend alors votre marteau et vous frappe sur la tête pour se venger:", vie)
        print("GAME OVER")

    else:
        print("Vous arrivez à vous enfuir mais Cocotte se fait attraper par Laladu et finit par mourrir.")
        print("Quel flop, Vous fuyez les deux, mais sans succès. Laladu vous attrape tout les deux et vous congèle éternellement.")
        print("GAME OVER")



def droite():
    global ordi 
    global vie
    print("Vous trouvez Cocotte dans une capsule et vous la libérez. Elle vous propose de la suivre.")
    reponse = input("Voulez vous la suivre ou explorer la maison à côté de la grange?")
    while reponse not in ["explorer", "suivre"]:
        reponse = input ("Que voulez vous faire?")


    if reponse == "explorer":
        print("Pendant que vous exploriez la maison, Cocotte s'est faite attraper par Laladu qui l'a ensuite enfermé dans une autre capsule. Vous avez essayé de la sauver. Malheureusement vous n'êtes pas arrivé à temps. Cocotte est morte.")
        ordi = ordi + 2
        print("Vous avez ensuite trouvé deux autres ordinateurs, en partie déjà piraté par Cocotte, que vous avez terminer de pirater. Comme ordonné par KinChana, vous chercher la porte de sortie.:", ordi)
        print("... Vous découvrez qu'il est impossible d'ouvrir la porte seul. Vous êtes donc coincé ici et condanné à fuir Laladu.")
        print("GAME OVER")


    elif reponse == "suivre":
        ordi = ordi + 2
        print("Cocotte vous demande de l'aider pour finaliser le piratage de deux ordinateurs qu'elle n'avait pas fini de pirater. Elle en profite pour vous faire visiter la maison.:", ordi)
        print("En montant au deuxième étage, vous entendez des bruits étranges derrière vous. En vous retrounant, vous croisez Laladu.")
        reponse = input("Que voulez vous faire? Fuir ou proteger Cocotte?")
        while reponse not in ["fuir", "proteger",]:
            reponse = input ("Fuir ou proteger?")

        if reponse == "proteger":

            if "marteau" in inventaire:
                print("Vous frappez Laladu et prenez la fuite avec Cocotte.")
                ordi = ordi + 1
                print("Vous remontez au deuxième pour pirater le dernier ordinateur.:", ordi)
                print("Vous allez jusqu'à la porte de sortie et vous commencez à l'ouvrir. Mais, avant que vous puissiez finir, Laladu vous frappe par derrière et vous perdez de la vie:", vie)
                print("Cocotte vous prend votre marteau et réussi à faire fuir Laladu.")
                from playsound import playsound
                playsound('porte.mp3')
                print("Vous arrivez enfin à ouvrir l'issue de secours et vous vous enfuyez avec Cocotte")
                print("GAGNEE")

            else:
                print("Quel flop, Vous arrivez à fuir mais Cocotte se fait attrapée et meurt. ...Vous découvrez qu'il est impossible d'ouvrir la porte seul. Vous êtes donc coincé ici et condanné à fuir Laladu.")
                print("GAME OVER")

        elif reponse == "fuir":
            marteau()


labyrinthe()







