from playsound import playsound #installer playsound avant d'éxécuter le code
inventaire = []
argent = 60


def jouer_son(chemin_fichier): #trouvé à l'aide de chat gpt car nous ne nous rappelions plus comment ajouter du son
    playsound(chemin_fichier)
    
    
def debut():
    global inventaire#accède à la variable de l'inventaire comme "global argent"
    inventaire = [] #remet l'inventaire à zéro pour permettre le bon déroulement de l'histoire après avoir pris le portail et recommencé l'histoire.
    global argent
    argent = 60
    
    print("Vous arrivez avec votre vaisseau sur une nouvelle planète nommée Bartaba. Vous devez ramasser un certain nombre d'objets tous d'une valeur différente pour atteindre la somme de 150 pièces pour pouvoir repartir.")
    reponse = input("Voulez-vous partir directement explorer la planète ou étudier les différents aspects de cette planète ? (explorer / étudier)")
    
    while reponse not in ["explorer", "étudier"]:
        print("Pas compris")
        reponse = input("Voulez-vous partir  directement explorer la planète ou étudier les différents aspects de cette planète ? (explorer / étudier)")
    
    if reponse == "étudier":
        etudier()
        
    elif reponse == "explorer":
        explorer()

    
def etudier():
    global argent #trouvé sur internet
    
    print("Vous vous rendez compte que vous possedez un ordinateur sur lequel vous pouvez commander des objets. Vous avez un solde de 60 pièces")
    reponse = input("Que voulez-vous acheter ? ( lampe de poche / bouclier / épée )")
    
    while reponse not in ["lampe de poche", "bouclier", "épée"]:
        print("Pas compris")
        reponse = input("Que voulez-vous acheter ? ( lampe de poche (15) / bouclier (30) / épée (60) )")
    
    if reponse == "lampe de poche":
        print("Achat confirmé")
        inventaire.append("lampe de poche")
        argent = argent - 15
        print("Vous ajoutez une lampe de poche à votre inventaire et payez 15 pièces")
        print("Vous avez", argent, "pièces")
         
    elif reponse == "bouclier":    
        print("Achat confirmé")
        inventaire.append("bouclier")
        argent = argent - 30
        print("Vous ajoutez un bouclier à votre inventaire et payez 30 pièces")
        print("Vous avez", argent, "pièces")
         
    elif reponse == "épée":
        print("Achat confirmé")
        inventaire.append("épée")
        argent = argent - 60
        print("Vous ajoutez une épée à votre inventaire et payez 60 pièces")
        print("Vous avez", argent, "pièces")
        
    portes()    

    
def explorer():
    global argent
    
    print("Vous sortez du vaisseau et vous laissez guider vers l'entrée principale. Vous voyez un couloir sombre et sinueux.")
    reponse = input("Vous l'emprunter et vous vous trouvez face à deux portes. Voulez-vous aller à gauche ou à droite ?")
    
    while reponse not in ["gauche", "droite"]:
        print("Pas compris")
        reponse = input("Vous l'emprunter et vous vous trouvez face à deux portes. Voulez-vous aller à gauche ou à droite ?")
        
    if reponse == "gauche":
        print("Vous franchisez la porte et tombez dans un trou avec des pieux. Vous mourrez. Pensez à étudier avant de vous jeter la tête baissée.")
        print("DEFAITEEE")
        
    elif reponse == "droite":
        print("C'est votre jour de chance ! Vous tombez sur une salle aux trésors. Vous ramassez 130 pièces puis continuez votre exploration.")
        argent = argent + 130
        print("Vous avez", argent, "pièces")
        print("Un jeune nain malicieux vous arrête et vous propose de vous échanger le trésor contre la victoire dit-il...")
        reponse = input("Acceptez vous cette proposition? (oui / non)")

        while reponse not in ["oui", "non"]:
            print("Pas compris")
            reponse = input("Acceptez vous cette proposition? (oui / non)")
            
        if reponse == "oui":
            argent = argent - 130
            print("Vous avez", argent, "pièces")
            print("Le jeune nain vous guide jusqu'au fin fond du batiment. Mais tout à coup...")
            print("Vous tombez sur la maléfique daronne d'Axel. Manque de chance : elle était énervé car Axel n'était pas aller se coucher à 21h30. Elle vous atomise avec la technique du lancé de la claquette du Seigneur.")
            print("DEFAITEEEE")
            
        elif reponse == "non":
            print("Suite à votre refus, il craque complétement, vous détruit votre trésor et commence à vous attaquer.")
            argent = argent - 130
            print("A cause de lui, vous avez perdu votre trésor, il vous reste donc plus que", argent, "pièces")
            reponse = input("Voulez-vous lui mettre un chassé du seigneur ou vous laisser faire par peur d'être maudit? (chassé du seigneur / laisser faire)")
            
            while reponse not in ["chassé du seigneur", "laisser faire"]:
                print("Pas compris")
                reponse = input("Voulez-vous lui mettre un chassé du seigneur ou vous laisser faire par peur d'être maudit? (chassé du seigneur / laisser faire)")
                
            if reponse == "chassé du seigneur":
                playsound("ronaldo-siuuuu.mp3")
                print("Le nain s'envole en rebondissant tel un ballon (tu m'étonnes)... Tu arrives à le récupérer inconscient et voit un autre nain qui veut apparemment l'acheter (bizarre bizarre...)")
                reponse = input("Souhaites-tu le vendre (suspect tout ça) ou le laisser s'enfuir une fois qu'il aura repris connaissance? (vendre / laisser s'enfuir)")
                
                while reponse not in ["vendre", "laisser s'enfuir"]:
                    print("Pas compris")
                    reponse = input("Souhaites-tu le vendre (suspect tout ça) ou le laisser s'enfuir une fois qu'il aura repris connaissance? (vendre / laisser s'enfuir)")
                
                if reponse == "vendre":
                    print("Sage décision, malgrès sa corpulence, il valait tout de même 200 pièces")
                    retour_vaisseau()
                    
                elif reponse == "laisser s'enfuir":
                    print("C'est tout ce que tu trouves à faire après t'être fait agressé... Ce nain valait sûrement son prix dommage pour toi.")
                    retour_vaisseau()
            elif reponse == "laisser faire":
                print("Après votre choix lugubre et vous être fait démarré par ce nain, vous remettez en question toute votre existence et périssez ici-bas.")
                print("DEFAITEEE")


def portes():
    global argent
    
    print("Vous décidez de partir en direction de l'entrée principale")
    reponse = input("Vous voyez 2 portes devant vous. Voulez-vous aller à droite ou à gauche?")
    
    while reponse not in ["gauche", "droite"]:
        print("Pas compris")
        reponse = input("Vous voyez 2 portes devant vous. Voulez-vous aller à droite ou à gauche?")
        
    if reponse == "gauche":
        print("Vous voyez un long chemin et y avancez au bout de 5 minutes de marche vous tombez sur un terrible monstre")
        if "épée" in inventaire:
            print("Grâce à votre épée, vous tuez le monstre après un dur combat et récupérez 200 pièces.")
            argent = argent + 200
            print("Vous avez", argent, "pièces")
            reponse = input("Voulez-vous retourner en arrière et rentrer ou continuer à explorer ? (retour / continuer)")
            while reponse not in ["retour", "continuer"]:
                print("Pas compris")
                reponse = input("Voulez-vous retourner en arrière et rentrer ou continuer à explorer ? (retour / continuer)")
            if reponse == "retour":
                retour_vaisseau()
            elif reponse == "continuer":
                print("Vous voyez une pièce lumineuse au loin. Vous y allez mais en arrivant vous apercevez une araignée qui commence à vous courir après. Fatigué de votre combat, vous n'arrivez plus à faire un pas. Vous êtes sur le point de vous faire manger mais vous apercevez un portail sur votre gauche...")
                reponse = input("Voulez-vous prendre le portail ? (oui / non)")
                while reponse not in ["oui", "non"]:
                    print("Pas compris")
                    reponse = input("Voulez-vous prendre le portail ? (oui / non)")
                if reponse == "oui":
                    print("Ce portail vous permet de vous rammenez au début de votre aventure et de changer vos décisions. Bonne chance jeune aventurier")
                    debut()
                elif reponse == "non":
                    print("Il vaudrait mieux écouter votre corps avant de prendre une telle décision. L'araignée vous mange et vous mourrez dans de terribles souffrances.")
                    print("DEFAITE")
        elif "épée" not in inventaire:
            if "lampe de poche" in inventaire:
                print("Vous réussissez à l'aveugler grâce à votre lampe de poche et à vous enfuir. Malheureusement il vous est impossible de retourner explorer et vous êtes dans l'obligation de rentrer au vaisseau.")
                retour_vaisseau()
            elif "lampe de poche" not in inventaire:
                print("Le monstre casse votre bouclier et vous périssez au combat... Il fallait mieux s'équiper")
                print("DEFAITE")

    elif reponse == "droite":    
        print("Vous voyez des escaliers que vous descendez.")
        print("Vous trouvez en bas un moteur d'une valeur de 75 pièces et l'ajoutez à votre inventaire.")
        inventaire.append("Moteur")
        argent = argent + 75
        print("Vous avez",argent, "pièces")
        reponse = input("Voulez-vous déjà rentrer ou continuer à explorer (rentrer / explorer) ? ")
        
        while reponse not in["rentrer", "explorer"]:
            print("Pas compris")
            reponse = input("Voulez-vous déjà rentrer ou continuer à explorer (rentrer / explorer) ? ")
       
        if reponse == "explorer":
            print("Vous continuez à explorer mais vous vous faite écraser par la maman de Dorian, un spécimène très rare sur cette planète. Vous avez eu de la chance dans votre malheur d'avoir pu la rencontrer...")
            print("Défaite !!")
           
        elif reponse == "rentrer":
                retour_vaisseau()


def retour_vaisseau():
    global argent
    
    print("Vous rentrez au vaisseau et vendez tout ce que vous avez récupéré. Espérons que vous avez récupéré l'argent requis.")
   
    if argent >= 150:
        print("BIEN JOUEEEEEEEE VICTOIREEEEE")
   
    else:
         print("DEFAITE")
         
                  
debut()
    
        
    
        
        
        
        