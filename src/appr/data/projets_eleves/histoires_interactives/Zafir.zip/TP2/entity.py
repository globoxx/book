from printassets import *


class Attack():
    def __init__(self,name,cost=0,damage=0,heal=0,affichage=None):
        self.name = name
        self.cost = cost
        self.damage = damage
        self.heal = heal

        self.affichage = affichage

class Weapon():
    def __init__(self,name=None,thumbnail="",attack=[],rank=None):
        self.name = name
        self.thumbnail = thumbnail
        self.attack = attack
        self.rank = rank

Hand = Weapon(name="Main",
            thumbnail="👊",
            attack=[
                Attack(name="Coup de poing direct",cost=-10,damage=-5,affichage=f"{color_print('Coup de poing direct',olive)}, {color_print('énergie -10',purple)} {color_print('dégât -5',rouge)}"),
                Attack(name="Uppercut",cost=-15,damage=-8,affichage=f"{color_print('Uppercut',olive)}, {color_print('énergie -15',purple)}, {color_print('dégât -8',rouge)}"),
                Attack(name="Crochet",cost=-25,damage=-15,affichage=f"{color_print('Crochet',olive)}, {color_print('énergie -25',purple)}, {color_print('dégât -15',rouge)}"),
                Attack(name="Repos",cost=10,affichage=f"{color_print('Repos',olive)}, {color_print('gain d énergie 10',bleu)}")
            ],
            rank="Basique"
            )

Dagger = Weapon(name="Dague moisie",
              thumbnail="🗡️",
            attack=[
                Attack(name="Tranchant fétide",cost=-15,damage=-10,affichage=f"{color_print('Tranchant fétide',olive)}, {color_print('énergie -15',purple)} {color_print('dégât -10',rouge)}"),
                Attack(name="Coupe putride",cost=-30,damage=-20,affichage=f"{color_print('Coupe putride',olive)}, {color_print('énergie -30',purple)}, {color_print('dégât -20',rouge)}"),
                Attack(name="Estoc empoisonné",cost=-50,damage=-30,affichage=f"{color_print('Estoc empoisonné',olive)}, {color_print('énergie -50',purple)}, {color_print('dégât -30',rouge)}"),
                Attack(name="Repos insalubre",cost=25,affichage=f"{color_print('Repos insalubre',olive)}, {color_print('gain d énergie 25',bleu)}")
            ],
            rank="Commun"
            )

Shield = Weapon(name="Bouclier de Datura",
              thumbnail="🛡️",
            attack=[
                Attack(name="Mur offensif",cost=-20,damage=-10,affichage=f"{color_print('Mur offensif',olive)}, {color_print('énergie -20',purple)} {color_print('dégât -10',rouge)}"),
                Attack(name="Coup d'acier",cost=-50,damage=-25,affichage=f"{color_print('Coup d acier',olive)}, {color_print('énergie -50',purple)}, {color_print('dégât -25',rouge)}"),
                Attack(name="Mur defensif",cost=75,affichage=f"{color_print('Mur defensif',olive)}, {color_print('gain d énergie 75',bleu)}"),
                Attack(name="Surplus de force",cost=-75,heal=15,affichage=f"{color_print('Surplus de force',olive)}, {color_print('énergie -50',purple)}, {color_print('récupère +15 de vie',rose)}")
            ],
            rank="Legendary"
            )

Twins = Weapon(name="Les Jumeaux",
              thumbnail="⚔️",
            attack=[
                Attack(name="Frappe égalitaire",cost=-10,damage=-10,affichage=f"{color_print('Frappe égalitaire',olive)}, {color_print('énergie -8',purple)}, {color_print('dégât -8',rouge)}"),
                Attack(name="Tourbillon des lames",cost=-30,damage=-25,affichage=f"{color_print('Tourbillon des lames',olive)}, {color_print('énergie -30',purple)}, {color_print('dégât -25',rouge)}"),
                Attack(name="Repos de noble",cost=25,affichage=f"{color_print('Repos de noble',olive)}, {color_print('gain d énergie 25',bleu)}"),
            ],
            rank="Rare"
            )

Flute = Weapon(name="Flûte",
               thumbnail="🪈",
               attack=[
                   #Attack(name="Ensorceleuse",cost=-50,burn=-5,burn_time=10,affichage=f"{color_print('Ensorceleuse',olive)}, {color_print('énergie -50',purple)}, {color_print('brûlure -5x10 🔥',orange)}"),
                   Attack(name="Ré mineur",cost=-20,damage=-10,affichage=f"{color_print('Ré mineur',olive)}, {color_print('énergie -20',purple)}, {color_print('dégât -10',rouge)}"),
                   Attack(name="Musique de farfadet",cost=-90,heal=25,affichage=f"{color_print('Musique de farfadet',olive)}, {color_print('énergie -90',purple)}, {color_print('récupère +25 de vie',rose)}"),
                   Attack(name="Note flemmarde",cost=20,damage=-5,affichage=f"{color_print('Note flemmarde',olive)}, {color_print('énergie +20',bleu)}, {color_print('dégât -5',rouge)}")
                   ],
            rank="Legendary"
               )

Admin = Weapon(name="One shot",
               thumbnail="👽",
               attack=[
                   Attack(name="One shot",damage=-150,affichage=f"{color_print('One shot',(255,0,0))}, {color_print('dégât ∞',rouge)}")
                       ],
                rank="Supreme"
               )

class Player():
    def __init__(self,
                 name='Guest',
                 life=100,
                 max_life=100,
                 stamina=100,
                 max_stamina=100,
                 inventory = [Hand],
                 use=Hand,
                 ):
        self.use = use
        self.name = name
        self.life = life
        self.max_life = max_life
        self.stamina = stamina
        self.max_stamina = max_stamina
        self.inventory = inventory

joueur = Player(inventory=[Hand],use=Hand)

Spartium  = Player(name="Spartium Le Perfide",use=Dagger,life=50,max_life=50)

Datura  = Player(name="Datura La Mort Blanche",use=Shield,life=100,max_life=100)

Belladone = Player(name="Belladone La Favorite",use=Flute,life=150,max_life=150)