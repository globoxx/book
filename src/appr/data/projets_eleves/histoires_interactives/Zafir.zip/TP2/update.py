import time
from printassets import *
from math import *
from voice import clear_os

#permet de montrer l'inventaire
def show_inventory(target,offset=0,filtre=None):
    index = offset
    clear_os()
    if filtre == None:
        print(f"Inventaire de {target.name}:")
    else:
        print(f"{filtre.__name__} de {target.name}:")
    for item in target.inventory:
        if filtre != None:
            if isinstance(item,filtre):
                index += 1
                print(f"{index}. {item.thumbnail} {item.name}")
        else:
            index += 1
            print(f"{index}. {item.thumbnail} {item.name}")
    clear_os()

#animation de modification de la vie + update bien évidemment
def life_update(target, amount):

    full = color_print("■" * int(target.life // 5),(life_color))
    empty = color_print("□" * int(20*(target.max_life/100) - (max(0,target.life) // 5)),(255,255,255))
    print('❤️',full,empty," ",int(target.life)," %"," ",sep="",end="\r")

    if not amount == 0:
        t = 0.17
        time.sleep(t)
        for i in range(5):
            if target.life <= target.max_life:
                target.life += amount/5
                full = color_print("■" * int(max(0,ceil(target.life)) // 5),(life_color))
                empty = color_print("□" * int(20*(target.max_life/100) - (max(0,ceil(target.life)) // 5)),(255,255,255))
                print('❤️',full,empty," ",int(max(0,target.life))," %", " "*10, sep="", end="\r")

                if target.life <= 0:
                    print("")
                    target.life = 0
                    return target
                
                time.sleep(t)
                t -= 0.03
            else:
                target.life = target.max_life

    print('❤️',full,empty," ",round(target.life)," %", " ", sep="")
    target.life = int(round(target.life))
    return target

#animation de modification de stamina + update bien évidemment
def stamina_update(target, amount):
    full = color_print("■" * int(target.stamina // 5),(stamina_color))
    empty = color_print("□" * int(20*(target.max_stamina/100) - (max(0,target.stamina) // 5)),(255,255,255))
    print('💪',full,empty," ",int(target.stamina)," %"," ",sep="",end="\r")

    if not amount == 0:
        t = 0.17
        time.sleep(t)
        for i in range(5):
            if target.stamina+amount/5 <= target.max_stamina:
                target.stamina += amount/5
                full = color_print("■" * int(max(0,ceil(target.stamina)) // 5),(stamina_color))
                empty = color_print("□" * int(20*(target.max_stamina/100) - (max(0,ceil(target.stamina)) // 5)),(255,255,255))
                print('💪',full,empty," ",int(max(0,target.stamina))," %", " "*10, sep="", end="\r")

                if target.stamina <= 0:
                    print("")
                    target.stamina = 0
                    return target
                
                time.sleep(t)
                t -= 0.03
            else:
                target.stamina = target.max_stamina

    print('💪',full,empty," ",round(target.stamina)," %", " ", sep="")
    target.stamina = int(round(target.stamina))
    return target

#mais les interface de fight en haut du terminal
def put_in_front():
    print("\x1b[1C")
    for i in range(100):#clear le terminal a coup de schlagos de flemme de réfléchir
        print("\x1b[3A")
        print(" "*log_width)

#update les stats du lanceur d'attaque
def update_stats_user(target,chosen):
    print(f"\n{color_print(target.name,vert)}")
    if target.life <= target.max_life:
        target = life_update(target,chosen.heal)
    if target.stamina <= target.max_stamina:
        target = stamina_update(target,chosen.cost)
    time.sleep(1)
    return target

#update les stats de la victime de l'attaque
def update_stats_choose(target,chosen):
    print(f"\n{color_print(target.name,vert)}")
    target = life_update(target,chosen.damage)
    target = stamina_update(target,0)
    time.sleep(1)
    return target