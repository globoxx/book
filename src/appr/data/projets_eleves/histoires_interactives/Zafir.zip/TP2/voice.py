import pygame
from pydub import AudioSegment
from io import BytesIO
import keyboard
import shutil
from math import *

pygame.init()

#EN GROS dans ce fichier .py en envois un string et sa le dit a l'oral avec cette voix "animal crossing" que j'ai ESSAYER de répliquer
def jouer_segment(audio_path, start_time, end_time,voice='default'):
    if voice=='B':
        speed = 25
        rate = 0.5
        wait = 250
    else:
        speed = 3
        rate = 2
        wait = 250
    # Charger le fichier audio
    audio = AudioSegment.from_file(audio_path)

    # Découper l'audio
    segment = audio[start_time:end_time]
    segment = segment.speedup(playback_speed=speed)
    segment = segment._spawn(segment.raw_data, overrides={
        "frame_rate": int(segment.frame_rate * rate)  # Multipliez le taux d'échantillonnage par 1.2 (vous pouvez ajuster ce facteur)
    })


    # Convertir en format WAV (Pygame ne supporte pas tous les formats)
    audio_wav = segment.export(BytesIO(), format="wav")

    # Créer un objet Sound de Pygame à partir des données audio WAV
    sound = pygame.mixer.Sound(audio_wav)

    sound.play()

    # Attendre que le son soit terminé
    pygame.time.wait(int(sound.get_length() * wait))

#voix de deepl
audio_path = "sound/Alphabet.wav"

alphabet = {
    'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4,
    'f': 5, 'g': 6, 'h': 7, 'i': 8, 'j': 9,
    'k': 10, 'l': 11, 'm': 12, 'n': 13, 'o': 14,
    'p': 15, 'q': 16, 'r': 17, 's': 18, 't': 19,
    'u': 20, 'v': 21, 'w': 22, 'x': 23, 'y': 24,
    'z': 25,
    'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4,
    'F': 5, 'G': 6, 'H': 7, 'I': 8, 'J': 9,
    'K': 10, 'L': 11, 'M': 12, 'N': 13, 'O': 14,
    'P': 15, 'Q': 16, 'R': 17, 'S': 18, 'T': 19,
    'U': 20, 'V': 21, 'W': 22, 'X': 23, 'Y': 24,
    'Z': 25,
}

width,height = shutil.get_terminal_size()

#fait parler le texte lettre par lettre
def say(texte):
    te = []
    for letter in texte:
        te.append(letter)
        print("".join(te),end="\r",flush=True)
        if keyboard.is_pressed('ctrl') == True:
            break
            
        if letter in alphabet:
            place = alphabet[letter]
        else:
            place = 27
        start_time = 500+place*490
        end_time = 1000+place*490
        jouer_segment(audio_path, start_time, end_time)

#nom un peu mensonger c'est juste pour faire des separtions pour éviter de se perdre entre chaque dialogue
def clear_os():
    print("-------------------------------------")

#c'est la ou sont envoyé les strings en premier, puis ils sont traité
def speak(question,inp=True,clear=True):
    say(question)
    if inp==True:
        answer = input(question)
        if clear==True:
            clear_os()
        return answer
    if inp==False:
        print(question)