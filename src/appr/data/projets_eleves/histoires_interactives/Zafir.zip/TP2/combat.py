from math import *
import random as rand
from voice import *
from entity import *
from update import *
import time
from bot import IA_attack
import sys



def show_possibility(target):

    possibility = []
    i = 0
    for a in target.use.attack:
        i+=1
        possibility.append(str(i))
        print(f"{i}.",a.affichage)
        #print(f"{color_print(a.name,(0,255,0))}, énergie {color_print(a.cost,(0,0,255))}, dégât {color_print(a.damage,(255,0,0))}")
    answer = None
    stamina_check = False
    while answer not in possibility or stamina_check == True:
        answer = input("--> ")
        print("\033[2A")
        print("            ",end="\r")
        if answer in possibility:
            stamina_check = target.stamina+target.use.attack[int(answer)-1].cost < 0
        if stamina_check == True:
            print(color_print("                  pas assez d'énérgie",rouge))
            print("\033[2A")
        else:
            print("                                      ")
            print("\033[2A")
    chosen = target.use.attack[int(answer)-1]
    return target,chosen
    
def fight(target1,target2):
    put_in_front()
    flip_flop = rand.choice([True,False]) #choisit qui commence a attacker
    sliding_string(f"{color_print(target1.name,(0,255,0))} VS {color_print(target2.name,(255,0,0))}")
    print(f"que choisie tu d'ituliser comme arme contre {target2.name}:\n")

    choice = []
    index_possible =[]
    for enumerate in range(len(target1.inventory)):
        obj = target1.inventory[enumerate]

        if isinstance(obj,Weapon):
            choice.append(obj)
            index_possible.append(str(enumerate))
            print(f"{enumerate}. {obj.name}")
    answer = None

    while answer not in index_possible:
        answer = input("--> ")
        print("\033[2A")
        print("            ",end="\r")

    target1.use=target1.inventory[int(answer)]
    print("")
    print(f"Tu à équipé \"{target1.use.name}\" pour ce combat")
    time.sleep(1)

    put_in_front()
    print(f"\n{color_print(target1.name,vert)}")
    life_update(target1,0)
    stamina_update(target1,0)
    print(f"\n{color_print(target2.name,vert)}")
    life_update(target2,0)
    stamina_update(target2,0)
    time.sleep(1)

    if flip_flop == True:
        print(f'{target1.name} commence:')

    else:
        print(f'{target2.name} commence')

    while target1.life > 0 and target2.life > 0:
        if flip_flop == True:
            print(f'Attaque de {target1.name} pour {target1.use.thumbnail} {target1.use.name}:')
            target1,chosen = show_possibility(target1)
            put_in_front()
            clear_os()
            print(f"{target1.name} itulise {chosen.name}")
            target1 = update_stats_user(target1,chosen)
            target2 = update_stats_choose(target2,chosen)
            clear_os()

        if flip_flop == False:
            print(f'c\'est à {target2.name} d\'attaquer')
            #time.sleep(rand.random(1,4))
            for i in range(rand.randrange(1,3)):
                print(f"{target2.name} choisie.   ",end="\r")
                time.sleep(0.5)
                print(f"{target2.name} choisie.. ",end="\r")
                time.sleep(0.5)
                print(f"{target2.name} choisie...",end="\r")
                time.sleep(0.5)
            print(f"                                          ",end="\r")
            target2,chosen = IA_attack(target2)
            put_in_front()
            clear_os()
            print(f"{target2.name} itulise {chosen.name}")
            target1 = update_stats_choose(target1,chosen)
            target2 = update_stats_user(target2,chosen)
            clear_os()
        flip_flop = not flip_flop

    if target1.life < target2.life:
        Mort(f"Vous avez été vaincu par {target2.name}")
    elif target2.life < target1.life:
        target1.life = target1.max_life
        target1.stamina = target1.max_stamina
        speak(f"{target2.name} n'est plus en état de se battre")
        return target2.use
    
def Mort(message):
    print(message)
    sys.exit(0)