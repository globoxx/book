from math import *
from voice import *
from entity import *
from update import *
import time
from combat import *

#explicite non ?
negatives = ["Non", "non", "Pas du tout", "pas du tout", "Pas vraiment", "pas vraiment", "Pas nécessairement", "pas nécessairement", "Pas sûr", "pas sûr", "Pas certain", "pas certain", "Plutôt non", "plutôt non", "Absolument pas", "absolument pas", "Jamais", "jamais", "Aucunement", "aucunement", "Pas forcément", "pas forcément", "Hors de question", "hors de question", "Impossible", "impossible", "Inenvisageable", "inenvisageable", "Négatif", "négatif"]
positives = ["Oui", "oui", "Ouais", "ouais", "Ouep", "ouep", "Si", "si", "Affirmatif", "affirmatif", "Tout à fait", "Tout a fait", "tout a fait", "tout à fait", "Bien sûr", "Bien sur", "bien sûr", "bien sur", "Assurément", "Assurement", "assurément", "assurement", "Absolument", "absolument", "D'accord", "D accord", "d'accord", "d accord", "OK", "ok", "D'acc", "D acc", "d'acc", "d acc", "Entendu", "entendu", "C'est bon", "c'est bon", "C'est d'accord", "c'est d'accord", "Ça marche", "ça marche",""]

for i in range(100):#clear le terminal a coup de schlagos de flemme de réfléchir
    print(" ")

def WhatsYourName():
    answer = "non"
    while not answer in positives:
        name = speak("Quel est ton nom déjà ? ",clear=False)
        joueur.name = name
        answer = speak(f"Es tu bien sur que tu t'appeles {joueur.name} ? ",clear=False)
        if answer not in positives:
            print("\x1b[2A")
            print("                                                                                     ",end="\r")
            print("\x1b[2A")
            print("                                                                                     ",end="\r")

###################################### Début de l'histoire ######################################
speak("Si vous voulez sauter les dialogues, appuyez sur CTRL. Et si vous avez compris, appuyez juste sur Entrée.", clear=False)
answer = speak("Veux-tu sauter l'histoire ?")
if answer not in positives:
    speak("Il y a fort longtemps, un petit village du nom de Verdoyant vivait paisiblement en alliance avec le Royaume des Plantes nommé Alca. Les échanges s'y", inp=False)
    speak("déroulaient sans difficulté, les récoltes étaient bonnes, le gibier abondant, et les échanges de soldats entre ces deux entités étaient récurrents.", inp=False)
    speak("Mais un jour...", clear=False)
    print("")
    speak("Spartium, le perfide du royaume d'Alca, le plus vicieux des six d'Alca, décida de mettre fin à cette trêve.", inp=False)
    speak("Il mentit sur la mort de son jeune frère Florus, qu'il avait assassiné par jalousie, et rejeta la faute sur le village de Verdoyant.", inp=False)
    speak("Aussitôt, la mère Mandragore, reine prospère du royaume, se métamorphosa en une bête de rancœur. Par sa magie, elle pétrifia tous les habitants du pauvre village", inp=False)
    speak("ainsi que les mercenaires humains qui étaient dans son royaume. Dans un élan de rage incontrôlable, elle transforma tous les Alcas en goules enragées.", clear=False)
    print("")
    speak("Découvert, Spartium fut exilé à vie par sa famille dans le village qu'il avait assassiné.", inp=False)
    speak("Désormais, il erre dans les petites ruelles, se nourrissant de la chair pétrifiée de ce qui est encore mangeable.", clear=False)
    print("")
    speak("Miraculeusement, de ce drame émergea un enfant, sous le nom de .", inp=False, clear=False)
    print("\x1b[2A")
    for i in range(3):
        print("Miraculeusement, de ce drame émergea un enfant, sous le nom de .  ", end="\r")
        time.sleep(0.5)
        print("Miraculeusement, de ce drame émergea un enfant, sous le nom de .. ", end="\r")
        time.sleep(0.5)
        print("Miraculeusement, de ce drame émergea un enfant, sous le nom de ...", end="\r")
        time.sleep(0.5)
    print("")
    WhatsYourName()
    print("")
    speak(f"...sous le nom de {joueur.name}, caché par sa famille dans une trappe à l'arrière de leur maison.", inp=False)
    speak("Cet enfant, ayant vu le drame de la mort de son père et la disparition de sa mère ainsi que de tout le village, à travers une fente de la trappe, en sortit rancunier.", inp=False)
    speak(f"{joueur.name} avait un don : la liaison bâtarde de ses deux parents, entre un humain et un Alca, lui conférait une force débordante.", inp=False)
    speak("Il s'appuya donc sur cet atout et se lança à la poursuite de ses assassins.")
else:
    WhatsYourName()
    clear_os()

speak("Vous êtes hors de la trappe, vous débordez de rage envers le royaume d'à côté, les Alcas. Vous faites face à votre premier dilemme...", inp=False)

clear_os()
speak("1. Veux-tu la mort de la Reine.", inp=False)
speak("2. Veux-tu vivre une vie paisible", inp=False)
answer = speak("--> ")
if answer == "2":
    Mort("Tu as décidé de ne pas être le personnage principal, tu vivras quelques jours avant de te faire dévorer par une goule.")
speak("Tu marches en direction de la rivière qui fait office de frontière quand tu tombes nez à nez...", inp=False)
speak(f"avec {Spartium.name} ...")
print("")
loot = fight(joueur, Spartium)
answer = speak(f"Veux-tu prendre {loot.name} de Spartium ? ", clear=False)
if answer in positives:
    joueur.inventory.append(loot)
    show_inventory(joueur)
speak("Bravo, tu as vaincu ta première goule, mais ce ne sera pas la dernière...", inp=False)
speak("Tu continues ton chemin et traverses le pont qui passe au-dessus de la rivière", inp=False)
speak("Pour t'arrêter devant les portes du royaume d'Alca, mais la porte est gardée par l'une des 5", inp=False)
speak(f"{Datura.name}...")
print("")
loot = fight(joueur, Datura)
answer = speak(f"Veux-tu prendre {loot.name} ? ", clear=False)
if answer in positives:
    joueur.inventory.append(loot)
    show_inventory(joueur)
speak(f"Après avoir vaincu Datura, {joueur.name} se tenait devant les portes du royaume, son cœur battant avec la fureur d'un guerrier et la détermination d'un homme qui ne connaissait que la vengeance.", inp=False)
speak("Les portes massives semblaient se dresser comme les gardiennes dernières d'un royaume corrompu par la haine et la trahison.", inp=False)
speak(f"{joueur.name} se baladait dans la ville en direction du château. Et s'arrêta devant une maison de chevalier...", inp=False)
clear_os()
speak("1. Continuer son chemin", inp=False)
speak("2. Fouiller la maison", inp=False)
answer = speak("--> ")
if answer == "2":
    speak("Rien dans la maison...", inp=False)
    speak("Chercher dans le jardin ?", inp=False)
    answer = speak("--> ")
    if answer in positives:
        speak("Une statue humaine gît dans le jardin brandissant quelque chose, vous vous rapprochez.", inp=False)
        speak("Vous avez trouvé une arme nommée les Jumeaux ! Voulez-vous la prendre ?", inp=False)
        answer = speak("--> ")
        if answer in positives:
            joueur.inventory.append(Twins)
            show_inventory(joueur)
speak("Vous continuez votre chemin...", inp=False)
speak("Maintenant aux portes du château, le seul obstacle qui vous fait face est Belladone la favorite.", inp=False)
speak("Elle se dresse entre vous et la salle de la reine, une seule option s'offre à vous : la mort de Belladone...")
loot = fight(joueur, Belladone)
answer = speak(f"Veux-tu prendre {loot.name} de Belladone ? ", clear=False)
if answer in positives:
    joueur.inventory.append(loot)
    show_inventory(joueur)
speak(f"Maintenant Belladone vaincue, plus rien ne séparait {joueur.name} de Mandragore...")
speak("Bon, je n'ai plus de temps pour le combat final, donc on va dire qu'elle a fait un AVC... FIN")