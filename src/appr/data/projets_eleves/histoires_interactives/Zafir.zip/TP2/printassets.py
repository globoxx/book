import shutil
import time
from math import *

#preset de couleur
life_color = (255,0,0)
stamina_color = (0,191,255)
rouge = (255,0,0)
purple = (160,43,147)
olive = (78,167,46)
bleu = (37,105,173)
vert = (0,255,0)
orange = (255,140,0)
rose = (234,66,88)
log_width,log_height = shutil.get_terminal_size()

#animation de VS au début d'un combat, je sais c'est impossible a lire
def sliding_string(string):
    for i in range(-log_width//2,log_width//2):
        if i != 0:
            val = tan(((i+1)*pi)/(log_width*1.25))/pi
        if i == 0:
            val = 0
        val = (val+1)/2
        val *= log_width
        print("\x1b[2A")
        print(" "*int(val-len(string)+10),string,end="\r")
        time.sleep(0.01)
    print(" "*log_width)
    print(" "*log_width)

#colorier les strings
def color_print(string, color):
    r, g, b = color
    color_code = f"\x1b[38;2;{r};{g};{b}m"
    string = color_code + str(string) + "\x1b[0m"
    return string

"""
code pour colorier le print "string" avec l'argument color, 
" \x1b[ ", est le préfixe des séquences de contrôle ANSI.
" 38;2; ", est une séquence spécifique pour spécifier une couleur RGB (38 est la séquence pour colorier un texte),(le "2" signifie 3 entrée (0,1,2) = RGB)
" {r};{g};{b} ", sont les entrées de couleur 

soit tu itulise \033[ soit \x1b (se sont des "synonymes")
\033[ == \x1b[ # ca permet de faire comprendre a l'ordinateur que l'on veut utiliser ASCII

\x1b[0m # Style de texte normal
\x1b[1m # Style de texte gras
\x1b[4m # Style de texte souligné
\x1b[7m # Style de texte inversé (couleurs inversées)

\x1b[48;5;{code}m # Définir la couleur d'arrière-plan (8 bits = 256 couleurs (2**8))
\x1b[38;5;{code}m # Définir la couleur du texte (8 bits = 256 couleurs (2**8))
\x1b[48;2;{r};{g};{b}m # Définir la couleur d'arrière-plan (RGB)
\x1b[38;2;{r};{g};{b}m # Définir la couleur du texte (RGB)

\x1b[2J # Effacer l'écran

\x1b[H # Déplacer le curseur en haut à gauche
\033[K # effacer la ligne actuelle
\033[F # remonter d'une ligne
\033[E # descends d'une ligne
\033[XB #descends de X ligne
\033[XA #monte de X ligne

f"\x1b[38;2;{r};{g};{b}m{STRING}\x1b[0m" # colorie un STRING avec une valeur r/g/b
"""