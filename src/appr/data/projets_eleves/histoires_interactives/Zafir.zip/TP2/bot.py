import random as rand

#IA très simple vraiment bête mais j'avais pas le temps de pousser le machin
def IA_attack(target):
    number = rand.randint(0,len(target.use.attack)-1)
    chosen = target.use.attack[number]

    if target.life+chosen.heal>target.max_life or target.stamina+chosen.cost<0 or target.stamina+chosen.cost>100:
        while target.life+chosen.heal>target.max_life or target.stamina+chosen.cost<0 or target.stamina+chosen.cost>100:
            number = rand.randint(0,len(target.use.attack)-1)
            chosen = target.use.attack[number]


    return target,chosen