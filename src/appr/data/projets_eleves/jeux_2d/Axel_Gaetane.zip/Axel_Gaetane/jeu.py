import pgzrun
import pgzero
from pgzero.keyboard import keyboard
from pgzhelper import *

TITLE = 'Runner'

WIDTH = 800
HEIGHT = 600

# Variables de difficulté de base
difficulte = "Base"
obstacle_vitesse = 10
hauteur_saut = -15

# Classe pour le joueur
class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = [f'tanks_tanknavy3.png']
        self.vy = 0
        self.game_over = False
        self.score = 0

    def update(self):
        self.y += self.vy
        self.vy += 1
        if self.y > 400:
            self.y = 400
            self.vy = 0

        if keyboard.space and self.y == 400: #càd qu'il touche le sol, permet que le joueur ne vole pas
            self.vy = hauteur_saut
            sounds.jump.play()

        if self.collides_with(obstacle):
            self.game_over = True

        if self.collides_with(objet): #augmente le score en ramassant un
            objet.x = 850
            self.score += 1

    def reset(self):
        self.x = 100
        self.y = 400
        self.vy = 0
        self.game_over = False
        self.score = 0

# Classe pour l'obstacle
class Obstacle(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

    def update(self):
        self.x -= obstacle_vitesse + player.score #augment la vitesse en fonction du score
        if self.x < -50:
            self.x = 850
            player.score += 1

    def reset(self):
        self.x = 850
        self.y = 430

# Classe pour l'objet à ramasser
class Objet(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

    def update(self):
        self.x -= obstacle_vitesse + player.score
        if self.x < -50:
            self.x = 850

class Nuage(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

player = Player('tanks_tanknavy3.png', (100, 400))
obstacle = Obstacle('tanks_mineoff.png', (850, 430))
objet = Objet('tanks_cratearmor.png', (100, 300)) #ajoute l'image de l'objet ajouté
nuages = [Nuage('cloud2.png',(800, 100)),Nuage('cloud4.png',(100, 100)), Nuage('cloud5.png',(400, 100))]
music.play('ninja_music')

# Dessine le jeu
def draw_game():
    screen.fill((163, 232, 254))
    screen.draw.filled_rect(Rect(0, 400, 800, 200), (88, 242, 152))
    for nuage in nuages:
        nuage.draw()
    player.draw()
    obstacle.draw()
    objet.draw() #dessine l'objet ajoouté
    screen.draw.text(f'Score: {player.score}', (15, 10), color=(0, 0, 0), fontsize=30)
    if player.game_over: #affiche un écran noir si le joueur est en game over
        screen.fill((0, 0, 0))
        screen.draw.text('Game Over', centerx=400, centery=270, color=(255,255,255), fontsize=60)

# Dessine le menu (à l'aide de Chat GPT)
def draw_menu():
    screen.fill((0, 0, 0))
    screen.draw.text('Menu - Choisir la difficulté', centerx=400, centery=100, color=(255, 255, 255), fontsize=50)
    screen.draw.text(f'1. Facile', centerx=400, centery=200, color=(255, 255, 255), fontsize=40)
    screen.draw.text(f'2. Moyen', centerx=400, centery=250, color=(255, 255, 255), fontsize=40)
    screen.draw.text(f'3. Difficile', centerx=400, centery=300, color=(255, 255, 255), fontsize=40)
    screen.draw.text('Appuyez sur 1, 2 ou 3 pour commencer', centerx=400, centery=350, color=(255, 255, 255), fontsize=30)

def choisir_difficulte(diff): #diff car sinon la difficulte reste = base
    global obstacle_vitesse, hauteur_saut, difficulte #permet de modifier les variables dans la fonction
    difficulte = diff
    if difficulte == "Facile":
        obstacle_vitesse = 5
        hauteur_saut = -10
    elif difficulte == "Moyen":
        obstacle_vitesse = 10
        hauteur_saut = -15
    elif difficulte == "Difficile":
        obstacle_vitesse = 15
        hauteur_saut = -20

# Met à jour le jeu
def update():
    if difficulte == "Base":
        if keyboard.K_1:
            choisir_difficulte("Facile")
        elif keyboard.K_2:
            choisir_difficulte("Moyen")
        elif keyboard.K_3:
            choisir_difficulte("Difficile")
    elif not player.game_over:
        player.animate(30)
        player.update()
        obstacle.update()
        objet.update() # dessine l'objet ajouté
    else:
        # relance la partie si on appuye sur R et qu'on est en game over (évite de miss click)
        if keyboard.r and player.game_over:
            player.reset()
            obstacle.reset()

#Problème résolu par Chat GPT
def draw() :
    if difficulte == "Base" :
        draw_menu()
    else:
        draw_game()

pgzrun.go()

# Améliorations :
# Facile : Correction des sauts infinis, Ecran de game over, les obstacles accélèrent avec le score
# Moyen : Relancer le jeu, obstacle à éviter en restant au sol, (ramasser des objets qui aug. le score (même que l'autre))
# Difficile : création d'un menu de difficulté