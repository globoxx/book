from pgzhelper import *
from random import *
TITLE = 'flappy_bird'
WIDTH = 800
HEIGHT = 600
GRAVITY = 0.7

def timer():
    player.time += 1

def detect_border_coin(actor):
    if actor.x < 0:
        actor.x = WIDTH
        actor.y = tuyau1.y + 250
        piece.ramassee = False

def detect_border(actor):
    if actor.x < 0:
        actor.x = WIDTH
        actor.y = randint(-80, 190)
        tuyau2.y = tuyau1.y + 500

class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ["bird0", "bird1", "bird2"]
        self.time = 0
        self.vy = 0
        self.speed = 3
        self.score = 0
        self.game_over = False
        self.is_moving = False

    def update(self):
        self.vy += GRAVITY

        if keyboard.space:
            self.vy = -7
            self.is_moving = True

        self.y += self.vy

        if tuyau1.collides_with(self):
            self.game_over = True

        if tuyau2.collides_with(self):
            self.game_over = True

        if piece.collides_with(self) and piece.ramassee == False:
            self.score += 1
            piece.ramassee = True
            sounds.coin.play()

        if self.y < 0:
            self.game_over = True

        if self.y >HEIGHT:
            self.game_over = True

class Tuyau(Actor):
    def __init__(self, image, pos, **kwards):
        super().__init__(image, pos, **kwards)
        self.speed = 3

    def update(self):
        if player.game_over == False:
            self.x -= self.speed

        detect_border(self)

class Piece(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = 3
        self.ramassee = False

    def update(self):
        if player.game_over == False:
            self.x -= self.speed

        detect_border_coin(self)

music.play('adventure')
clock.schedule_interval(timer, 1)
tuyau1 = Tuyau("top", (100, 100), height = 350)
tuyau2 = Tuyau("bottom", ( 100, 600) ,height = 350)
player = Player('bird0', (WIDTH/2, HEIGHT/2-100))
piece = Piece("coin", (100, 350))

def draw():
    screen.fill('sky blue')
    screen.draw.text("score: " + str(player.score), (0, 0))
    screen.draw.text("temps: " + str(player.time), (0, 15))
    tuyau1.draw()
    tuyau2.draw()
    player.draw()

    if piece.ramassee == False:
        piece.draw()

    if player.game_over == True :
        screen.fill("black")
        screen.draw.text("GAME OVER", center = (WIDTH/2, HEIGHT/2), color = "red")
        screen.draw.text("score: " + str(player.score), (WIDTH/2 - 30, HEIGHT/2+15))
        screen.draw.text("temps: " + str(player.time), (WIDTH/2 - 30, HEIGHT/2 + 30))
        clock.unschedule(timer)

    if player.is_moving == True :
            player.animate()

def update():
    tuyau1.update()
    tuyau2.update()
    player.update()
    piece.update()
