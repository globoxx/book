from pgzrun import *

TITLE = 'Mon premier platformer'

WORLD_MAP = [
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,5,0,0,0,0,6,4,0,0,0,5,0,0,0,0,5,0,0,0,0,5,4,0,0,0,5,0,0,0,0,5,0,0,0,0,5,4,0,0,0,5,0],
    [0,0,0,1,0,0,0,1,7,1,0,0,1,1,0,0,0,0,1,0,0,0,1,1,1,0,0,1,1,0,0,0,0,1,0,0,0,1,1,1,0,0,1,1,0],
    [0,0,0,0,0,0,0,0,0,0,5,5,0,0,0,4,0,7,0,0,0,0,0,0,0,5,5,7,0,0,0,0,0,0,0,0,0,0,0,0,5,5,0,0,0],
    [1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1],
]

WORLD_MAP_2 = [
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0],
    [0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,4,0,0,0,1,1,5,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [5,5,5,0,0,0,4,0,4,4,0,0,0,5,4,4,4,4,4,0,0,0,5,5,5,5,4,5,5,5,5,5,5,5,5,5,5,5,5,2,5,5,5,5,5],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
]

TILE_SIZE = 70
ROWS = len(WORLD_MAP)
COLS = len(WORLD_MAP[0])

WIDTH = 1000
HEIGHT = ROWS * TILE_SIZE

GRAVITY = 0.3

class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.vx = 0
        self.vy = 0
        self.speed = 3
        self.vie = 3
        self.game_over = False
        self.score = 0

    def update(self):
        self.vy += GRAVITY

        if keyboard.d:
            for platform in platforms:
                platform.x -= self.speed
            self.flip_x = False
        elif keyboard.a:
            for platform in platforms:
                platform.x += self.speed
            self.flip_x = True

        for platform in platforms:
            platform.check_collision_with_actor(self)

        if keyboard.space and self.vy == 0:
            self.vy = -10
        if self.vie == 0:
            self.game_over = True

        if self.x < 0:
            self.game_over = True
        if self.y > HEIGHT:
            self.game_over = True

        self.y += self.vy

class Slime(Actor):
    def __init__(self, image, pos, max_distance_x, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ['slime_green1', 'slime_green2']
        self.vy = 0
        self.vx = 0
        self.speed = 1
        self.max_distance_x = max_distance_x
        self.distance_x = 0
        self.player_reference = player

    def update(self):
        self.vy += GRAVITY

        for platform in platforms:
            platform.check_collision_with_actor(self)

        self.x += self.speed
        self.y += self.vy

        if not (0 <= self.distance_x <= self.max_distance_x):
            self.flip_x = not self.flip_x
            self.speed = -self.speed

        if self.player_reference.x < self.x:
            self.x -= self.speed
        elif self.player_reference.x > self.x:
            self.x += self.speed

        if player.collides_with(self) and player.vie > 0:
            player.vie -= 1
            self.to_remove = True

class Coin(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = 3
        self.ramassee = False

    def update(self):
        if player.collides_with(self):
            self.to_remove = True
        if keyboard.d:
            self.x -= self.speed
        elif keyboard.a:
            self.x += self.speed

        if player.collides_with(self) and not self.ramassee:
            player.score += 1
            self.ramassee = True

class Portal(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = 3

    def update(self):
        if player.collides_with(self) and keyboard.e:
            print('Niveau 2 !')
            global platforms, slimes, coins, portals
            platforms, slimes, coins, portals = load_level(WORLD_MAP_2)

        if keyboard.d:
            self.x -= self.speed
        elif keyboard.a:
            self.x += self.speed

class Missile(Actor):
    def __init__(self, image, pos, direction, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.direction = direction
        self.angle = direction
        self.speed = 20
        self.vy = 0

    def update(self):
        self.move_in_direction(self.speed)
        self.vy += GRAVITY
        self.y += self.vy
        for slime in slimes:
             if self.collides_with(slime):
                slime.to_remove = True
                self.to_remove = True

def on_mouse_down(pos):
    direction = player.angle_to(pos)
    missile = Missile('missile', (player.x, player.y), direction)
    missiles.append(missile)

def load_level(world_map):
    platforms = []
    slimes = []
    coins = []
    portals = []

    for row in range(ROWS):
        for col in range(COLS):
            pos = (col * TILE_SIZE + TILE_SIZE / 2, row * TILE_SIZE + TILE_SIZE / 2)
            if world_map[row][col] == 1:
                platform = Platform('grass_tile', pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 2:
                platform = Platform('grass_tile', pos, solid=True, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 3:
                platform = Platform('grass_tile', pos, solid=True, sticky=True, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 4:
                slime = Slime('slime_green1', pos, max_distance_x=300)
                slimes.append(slime)
            elif world_map[row][col] == 5:
                coin = Coin('coin', pos)
                coins.append(coin)
            elif world_map[row][col] == 6:
                portal = Portal('portal', pos, width=TILE_SIZE)
                portals.append(portal)

    return platforms, slimes, coins, portals

player = Player('alien_walk1', (WIDTH / 2, 100))
music.play('adventure')
platforms, slimes, coins, portals = load_level(WORLD_MAP)
missiles = []

def draw():
    screen.fill('sky blue')
    screen.draw.text("vie: " + str(player.vie), (0, 0))
    screen.draw.text("score: " + str(player.score), (40, 0))
    player.draw()
    for slime in slimes:
        slime.draw()
    for platform in platforms:
        platform.draw()
    for coin in coins:
        coin.draw()
    for portal in portals:
        portal.draw()
    for missile in missiles:
        missile.draw()

    if player.game_over:
        screen.fill('black')
        screen.draw.text("GAME OVER", (WIDTH / 2, HEIGHT / 2))

    if player.score >= 20:
        screen.fill('white')
        screen.draw.text("Victoire !", (WIDTH / 2, HEIGHT / 2), color='black')

def update():
    player.update()
    for slime in slimes:
        slime.update()
    for coin in coins:
        coin.update()
    for portal in portals:
        portal.update()
    for missile in missiles:
        missile.update()

    remove_actors(coins)
    remove_actors(slimes)
    remove_actors(missiles)

pgzrun.go()# Ecrit ton programme ici ;-)
