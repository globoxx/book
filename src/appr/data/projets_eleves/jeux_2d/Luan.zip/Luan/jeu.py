import pgzrun
from pgzhelper import *
from random import *

TITLE = 'Hit the fly'

WIDTH = 800
HEIGHT = 600

def draw():
    screen.blit('grass', (0, 0))
    player.draw()
    piece.draw()  # création du dessin de la pièce
    for ennemy in ennemies:
        ennemy.draw()
    for missile in missiles:
        missile.draw()
    screen.draw.text(f'Score: {player.score}', (15, 10), color=(0, 0, 0), fontsize=30) #ajoute le score en haut à gauche
    if player.game_win: # Si le jeu est terminé
        screen.fill("black") #ajoute un ecran noir
        screen.draw.text('Game win', centerx=400, centery=270, color=(255, 255, 255), fontsize=60) #ajout du text game win
    if player.game_over: #si le jeu est perdu
        screen.fill("black")
        screen.draw.text('Game over', centerx=400, centery=270, color=(255, 255, 255), fontsize=60)





def update():
    if player.game_win == False and player.game_over == False : #pour que le game_win soit possible et la defaite
        player.update()
        for ennemy in ennemies:
            ennemy.update()
            ennemy.animate()
        for missile in missiles:
            missile.update()
        for ennemy in ennemies: #pour pouvoir perdre
            if player.collides_with(ennemy):
                player.game_over = True

        remove_actors(ennemies)
        remove_actors(missiles)



def on_mouse_down(pos):
    missile = Missile('missile', (player.x, player.y))
    missile.speed = player.missile_speed #changement de vitesse du missile quand celui-ci est touché
    missile.direction = player.angle_to(pos)
    missile.angle = missile.direction
    missiles.append(missile)

def add_ennemy():
    ennemy = Ennemy('fly1', (randint(0, WIDTH), randint(0, HEIGHT)))
    ennemies.append(ennemy)




class Piece(Actor):  #rajouter la pièce qui booste notre personnage
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)


class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = 3
        self.missile_speed = 5 #vitesse de base du missile qui change en fonction de la pièce.
        self.score = 0 #ajout du conteur à zero
        self.game_win = False #pour que la win soit possible
        self.game_over =  False # pour pouvoir perdre

    def update(self):
        if keyboard.a:
            self.x -= self.speed
            self.flip_x = True
        if keyboard.d:
            self.x += self.speed
            self.flip_x = False
        if keyboard.w:
            self.y -= self.speed
        if keyboard.s:
            self.y += self.speed
    def add_score(self):
        self.score +=1
        if self.score > 5: #pour avoir une victoire
            self.game_win = True



class Ennemy(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ['fly1', 'fly2']
        self.direction = randint(0, 360)
        self.speed = 3
        self.conteur2 = 0 # empêche les ennemies d'apparaitre à vie

    def update(self):
        self.direction += randint(-10, 10)
        self.move_in_direction(self.speed)
        if self.x > 800: # renvoie les ennemies en arrière
            self.x = 0
            self.conteur2 += 1
        if self.x < 0:
            self.x = 800
            self.conteur2 += 1
        if self.y > 600:
            self.y = 0
            self.conteur2 += 1
        if self.y < 0:
            self.y = 600
            self.conteur2 += 1

        if self.conteur2 > 3:
            self.to_remove = True

class Missile(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.conteur = 0 #conteur pour qu'il n'y ait pas trop missiles (n'apparaît pas à vie)


    def update(self):

        self.move_in_direction(self.speed)
        for ennemy in ennemies:
            if self.collides_with(ennemy):
                print('BOOOOM')
                player.add_score()  #ajoute le score de 1 si le player touche
                ennemy.to_remove = True
                self.to_remove = True

        if self.x > 800: #renvoie les missiles en arrière
            self.x = 0
            self.conteur +=1
        if self.x < 0:
            self.x = 800
            self.conteur += 1
        if self.y > 600:
            self.y = 0
            self.conteur += 1
        if self.y < 0:
            self.y = 600
            self.conteur += 1

        if self.conteur > 3:
            self.to_remove = True

        if self.collides_with(piece):
            player.missile_speed += 5  # si la pièce est prise changement de vitesse
            piece.x = randint (0,WIDTH) #changement de place
            piece.y = randint (0,HEIGHT) #changement de place
            self.to_remove = True # Le missile se détruit quand il est touché




player = Player('alien_walk1', (WIDTH/2, HEIGHT/2))
ennemy = Ennemy('fly1', (randint(0, WIDTH), randint(0, HEIGHT)))
ennemies = [Ennemy('fly1', (randint(0, WIDTH), randint(0, HEIGHT)))]
missiles = []
piece = Piece("coin",(randint(0, WIDTH), randint(0, HEIGHT))) #création de la piece



clock.schedule_interval(add_ennemy, 3.0) #il re apparait chaque 3 secondes.


# Voici un résumé rapide de tous les changements que j'ai apporté:
#-Système de score, conditions de victoire et de défaite, affichage de texte, nouvel acteur (pièce bonus), gestion du cycle de vie (rebonds/missiles), vitesse du missile qui augmente, missiles et mouches reviennent de l'autre côté s'ils sortent de l'écran


pgzrun.go()
