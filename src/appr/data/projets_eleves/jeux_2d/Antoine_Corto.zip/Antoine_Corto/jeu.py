# améliorations faciles : game over, système de score, missiles détruit si ils sortent de l'écran
# améliorations moyennes : système de vie , pièces boostants vitesse des missiles , périodes d'invincibilité
# améliorations difficiles : permet de poser des pièges




import pgzrun
from pgzhelper import *
from random import *

TITLE = 'Hit the fly'

WIDTH = 800
HEIGHT = 600

class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.game_over = False
        self.life = 100 # donne un nombre de PV
        self.speed = 3
        self.invincible = False
        self.missile_speed = 5
        self.score = 0
        self.spawn_trap = True # capacité de poser des pièges


    def update(self):

        if keyboard.a:
            self.x -= self.speed
            self.flip_x = True

        if keyboard.d:
            self.x += self.speed
            self.flip_x = False

        if keyboard.w:
            self.y -= self.speed

        if keyboard.s:
            self.y += self.speed

        if self.life > 0: # condition pour que le jeu s'arrête
            self.game_over = False
        else:
            self.game_over = True

        for ennemy in ennemies:
            if self.collides_with(ennemy) and not self.invincible: # si le joueur touche un ennemie, la condition game over devient vraie
                self.life -= 10
                sounds.grunt.play()
                self.invincible = True # rend le joueur invincible
                clock.schedule(self.plus_invincible, 2.0)  # durée d'invincibilité

    def plus_invincible(self): # retire l'invincibilité du joueur
        self.invincible = False

class Ennemy(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ['fly1', 'fly2']
        self.direction = randint(0, 360)
        self.speed = 3

    def update(self):
        self.direction += randint(-10, 10)
        self.move_in_direction(self.speed)

class Missile(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = player.missile_speed

    def update(self):
        self.move_in_direction(self.speed)
        for ennemy in ennemies:
            if self.collides_with(ennemy):
                print('BOOOOM')
                sounds.slap.play()
                ennemy.to_remove = True
                self.to_remove = True
                player.score += 1 # chaque ennemie tué augmente le score
        if self.x > WIDTH or self.y > HEIGHT or self.x < 0 or self.y < 0:
            self.to_remove = True

class Coin(Actor): # nouvelle classe pièce
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

    def update(self):
            if self.collides_with(player):
                sounds.collect.play()
                bonus = randint(1,3)
                if bonus == 1:
                    player.missile_speed += 10 # augmente la vitesse des missiles du joueur
                elif bonus == 2: # augmente la vitesse du joueur
                    player.speed += 1
                elif bonus == 3: # augmente les PV du joueur
                    player.life += 10
                self.to_remove = True

class Trap(Actor): # nouvelle classe piège
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

    def update(self):
        for ennemy in ennemies:
            if self.collides_with(ennemy): # tue un ennemi au contact
                print('CLANG')
                sounds.clack.play()
                ennemy.to_remove = True
                self.to_remove = True
                player.score += 1

def add_ennemy():
    ennemy = Ennemy('fly1', (randint(0, WIDTH), randint(0, HEIGHT)))
    ennemies.append(ennemy)

def on_mouse_down(pos):
    missile = Missile('missile', (player.x, player.y))
    missile.direction = player.angle_to(pos)
    missile.angle = missile.direction
    missiles.append(missile)



def add_trap(): # permet de poser un piège
    if player.spawn_trap == True:
        trap = Trap('barnacle', (player.x, player.y))
        traps.append(trap)
        player.spawn_trap = False
        clock.schedule(allow_spawn_trap, 5) # délai de X secondes entre deux pièges

def allow_spawn_trap():
    player.spawn_trap = True

def add_coin(): # permet au pièces d'apparaitre
    coin = Coin('coin_01', (randint(0, WIDTH), randint(0, HEIGHT)), width = 50, height = 50)
    coins.append(coin)



music.play('musique-douteuse')
spawn_trap = True
player = Player('alien_walk1', (WIDTH/2, HEIGHT/2))
ennemies = [Ennemy('fly1', (randint(0, WIDTH), randint(0, HEIGHT)))]
coins = [Coin('coin_01',(randint(0, WIDTH), randint(0, HEIGHT)), width = 50, height = 50)]
traps = []
missiles = []

clock.schedule_interval(add_ennemy, 1.0)
clock.schedule_interval(add_coin, 10.0)

def draw():
    screen.blit('grass', (0, 0))
    player.draw()
    for ennemy in ennemies:
        ennemy.draw()
    for missile in missiles:
        missile.draw()
    for coin in coins:
        coin.draw()
    for trap in traps:
        trap.draw()
    if player.game_over:
        screen.fill((0,0,0))
        screen.draw.text('Game Over', centerx = 400, centery = 270, color = (255, 255, 255), fontsize = 60) # affiche le game over
    screen.draw.text(f'Score: {player.score}', (15, 10), color = (0,0,0), fontsize = 30) # fait apparaitre le score
    screen.draw.text(f'Vie: {player.life}', (150, 10), color=(0, 0, 0), fontsize=30) # fait apparaitre la vie
def update():
    if not player.game_over:
        player.update()
        for ennemy in ennemies:
            ennemy.update()
            ennemy.animate()
        for missile in missiles:
            missile.update()
        for coin in coins:
            coin.update()
        for trap in traps:
            trap.update()
        remove_actors(ennemies)
        remove_actors(missiles)
        remove_actors(coins)
        remove_actors(traps)

        if keyboard.space: # permet de poser un piège en appuyant sur space
            add_trap()

pgzrun.go()