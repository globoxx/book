import random

import pgzrun  # Lancer le jeu avec pgzrun
import pgzero
from pgzero.clock import clock

from pgzhelper import *  # Fonctions utilitaires pour pgzero (ex: move_in_direction, collides_with, etc.)
from random import *  # Pour utiliser randint, choice, etc.

TITLE = 'Mon premier platformer'  # Titre de la fenêtre

# Carte du monde de départ, 0 = vide, 1 = plateforme, 4 = slime
WORLD_MAP = [
    [0,0,0,0,0,0,0,0,0,4,0,0,0,0,0],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
]

# Ajoute 20 lignes générées aléatoirement avec des probabilités biaisées pour placer des plateformes
for i in range(10):
    WORLD_MAP.append([round((randint(1,10)/10-0.29)) for col in range(15)])  # -0.3 = réduit chances d’avoir un 1
print(WORLD_MAP)
WORLD_MAP.reverse()  # Met le haut en bas pour correspondre à l’affichage écran

TILE_SIZE = 70  # Taille d’un bloc
ROWS = len(WORLD_MAP)  # Nombre de lignes
COLS = len(WORLD_MAP[0])  # Nombre de colonnes

WIDTH = COLS * TILE_SIZE  # Largeur totale écran
HEIGHT = ROWS * TILE_SIZE  # Hauteur totale écran
print(HEIGHT)

GRAVITY = 0.3  # Gravité appliquée au joueur

# Classe du joueur
class Player(Actors):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.vy = 0  # Vitesse verticale
        self.speed = 3  # Vitesse horizontale
        self.game_over = False
        self.vie = 3  # Nombre de vies
        self.score = 0  # Score du joueur

    def update(self):
        global platforms, slimes, coins

        if self.vie < 1:
            self.game_over = True  # Fin du jeu si plus de vie

        self.vy += GRAVITY  # Applique gravité
        if self.vy > 35:  # Tombe trop vite = mort
            self.game_over = True

        # Déplacement gauche
        if not self.x < 0:
            if keyboard.a:
                self.x -= self.speed
                if self.flip_x == False:
                    self.flip_x = True

        # Déplacement droite
        if not self.x > 1050:
            if keyboard.d:
                self.x += self.speed
                if self.flip_x == True:
                    self.flip_x = False

        # Collision avec les plateformes
        for platform in platforms:
            platform.check_collision_with_actor(self)

        # Saut
        if keyboard.space and self.vy == 0:
            self.vy = -10
            for i in range(5):  # Ajoute 5 nouvelles lignes au saut
                WORLD_MAP.reverse()
                if platforms:
                    min_y = min(p.y for p in platforms)  # Trouve la hauteur minimale
                    new_row = [round((randint(1,10)/10-0.29)) for col in range(15)]
                for col in range(COLS):
                    if new_row[col] == 1:
                        x = col * TILE_SIZE + TILE_SIZE / 2
                        y = min_y - TILE_SIZE
                        platform = Platform('grass_tile', (x, y), width=TILE_SIZE)
                        platforms.append(platform)
                WORLD_MAP.reverse()
            self.score += 10  # Ajoute des points au saut

        # Mort si trop haut
        if self.y < -10:
            self.game_over = True

        # Déplace tout vers le bas pour simuler le saut
        for platform in platforms:
            platform.y -= self.vy
        for slime in slimes:
            slime.y -= self.vy
            if slime.collides_with(self):
                slime.to_remove = True
                self.vie -= 1
                sounds.splat.play()
        for missile in missiles:
            missile.y -= self.vy

# Classe des ennemis
class Slime(Actors):
    def __init__(self, image, pos,  **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ['slime_green1', 'slime_green2']
        self.speed = 3
        self.direction = 0  # Direction de mouvement

    def update(self):
        self.direction = self.angle_to(player)  # Oriente vers le joueur
        self.move_in_direction(self.speed)

# Classe des pièces
class Coin(Actors):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

    def update(self):
        if player.collides_with(self):
            self.to_remove = True  # Supprime la pièce

# Classe des projectiles
class Missile(Actors):
    def __init__(self, image, pos, direction, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = 5
        self.direction = direction
        self.angle = direction

    def update(self):
        self.move_in_direction(self.speed)  # Avance dans la direction
        for slime in slimes:
            if self.collides_with(slime):
                sounds.explosion.play()
                slime.to_remove = True
                self.to_remove = True
                player.score += 150  # Ajoute des points

# Génère le niveau à partir de la carte
def load_level(world_map):
    platforms = []
    slimes = []
    coins = []

    for row in range(ROWS):
        for col in range(COLS):
            pos = (col * TILE_SIZE + TILE_SIZE / 2, row * TILE_SIZE + TILE_SIZE / 2)
            pos_slime=(choice([0, WIDTH]), randint(0,HEIGHT))
            if world_map[row][col] == 1:
                platform = Platform('grass_tile', pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 2:
                platform = Platform('grass_tile', pos, solid=True, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 3:
                platform = Platform('grass_tile', pos, solid=True, sticky=True, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 4:
                slime = Slime('slime_green1', pos_slime)
                slimes.append(slime)
            elif world_map[row][col] == 5:
                coin = Coin('coin', pos)
                coins.append(coin)

    return platforms, slimes, coins

# Trouve la position de départ du joueur
player_start_x = 100
player_start_y = 100
for col in range(COLS):
    if WORLD_MAP[-2][col] == 1 and WORLD_MAP[-3][col]!=1:
        player_start_x = col * TILE_SIZE + TILE_SIZE / 2
        player_start_y = (ROWS-3) * TILE_SIZE - 40
        break

player = Player('alien_walk1', (player_start_x, player_start_y))  # Crée le joueur

missiles = []
platforms, slimes, coins = load_level(WORLD_MAP)  # Charge le niveau

music.play('adventure')  # Joue la musique de fond

# Fonction pour ajouter un slime toutes les 5 secondes
def add_slime():
    a = randint(0, 1)
    pos_deb = 0 if a == 0 else WIDTH
    pos_slime = (pos_deb, randint(0, HEIGHT))
    i = randint(1, 2)
    slime = Slime(f'slime_green{i}', pos_slime)
    slimes.append(slime)
clock.schedule_interval(add_slime, 5.0)

# Clique souris = tirer un missile
def on_mouse_down(pos):
    direction = player.angle_to(pos) 
    missile = Missile('missile', (player.x, player.y), direction)
    if len(missiles) < 3:
        missiles.append(missile)
print (choice([0, WIDTH]))

# Dessine tout à l'écran
def draw():
    screen.fill('sky blue')
    
    for platform in platforms:
        platform.draw()
    for coin in coins:
        coin.draw()
    for slime in slimes:
        slime.draw()
    if player.game_over:
        screen.draw.text('Game Over', centerx=WIDTH/2, centery=HEIGHT/2, color=(0,0,0), fontsize=180)
        screen.draw.text('Press Space to close', centerx=WIDTH/2, centery=HEIGHT/2+100, color=(0,0,0), fontsize=60)
    for missile in missiles:
        missile.draw()
    player.draw()
    screen.draw.text(f'Score: {player.score}', (15,10), color=(0,0,0), fontsize=60)
    screen.draw.text(f'Vie: {player.vie}', (WIDTH-140,10), color=(0,0,0), fontsize=60)
    screen.draw.text(f'Missiles restants: {3-len(missiles)}', (15,50), color=(0,0,0), fontsize=30)

# Met à jour tout le jeu (logique)
def update():
    if not player.game_over:
        player.update()
        for slime in slimes:
            slime.update()
        for coin in coins:
            coin.update()
        for missile in missiles:
            missile.update()
            # Supprime missile hors écran
            if missile.y > HEIGHT or missile.y < 0 or missile.x > WIDTH or missile.x < 0:
                missiles.remove(missile)
        for platform in platforms:
            if platform.y > HEIGHT+150 or platform.y < -300:
                platforms.remove(platform)
        remove_actors(coins)
        remove_actors(slimes)
        remove_actors(missiles)
    else:
        if keyboard.space == True:
            exit()  # Ferme le jeu si on appuie sur espace

pgzrun.go()  # Lance le jeu
