import pygame, sys
from pygame.locals import QUIT


import pgzrun
import pgzero
from pgzero.keyboard import keyboard

from pgzhelper import *



TITLE = 'Mon premier platformer'

WORLD_MAP = [
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 5, 0, 0, 0, 0, 6, 4, 0, 0, 0, 5, 0],
    [0, 0, 0, 3, 0, 0, 0, 1, 1, 1, 0, 0, 2, 2, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0],
    [1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]

WORLD_MAP_2 = [
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 4, 0, 0, 0, 1, 1, 5, 1, 0, 0, 0, 0, 0, 0],
    [5, 5, 5, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 5, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]

TILE_SIZE = 70
ROWS = len(WORLD_MAP)
COLS = len(WORLD_MAP[0])

WIDTH = COLS * TILE_SIZE
HEIGHT = ROWS * TILE_SIZE

GRAVITY = 0.3

score = 0
show_portal_text = False


class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.vy = 0
        self.score = 0
        self.speed = 3
        self.game_over = False
        

    def update(self):
        if self.game_over:
            return

        self.vy += GRAVITY

        if keyboard.a:
            self.x -= self.speed
            self.flip_x = True
        elif keyboard.d:
            self.x += self.speed
            self.flip_x = False

        for platform in platforms:
            platform.check_collision_with_actor(self)

        if keyboard.space :
            if self.vy == 0:
                self.vy = -10
            sounds.jump.play()  # j'ai ajoute le son des sauts

        self.y += self.vy

        for slime in slimes:
            if self.colliderect(slime):
                self.game_over = True

        if self.y > HEIGHT:
            self.game_over = True

    def is_on_ground(self):
        for platform in platforms:
            if self.colliderect(platform) and self.y < platform.y:
                return True
        return False


class Slime(Actor):
    def __init__(self, image, pos, max_distance_x, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ['slime_green1', 'slime_green2']
        self.vy = 0
        self.vx = 0
        self.speed = 2
        self.max_distance_x = max_distance_x
        self.distance_x = 0

    def update(self):
        self.vy += GRAVITY

        for platform in platforms:
            platform.check_collision_with_actor(self)

        self.x += self.speed
        self.y += self.vy
        self.distance_x += self.speed

        if not (0 <= self.distance_x <= self.max_distance_x):
            self.flip_x = not self.flip_x
            self.speed = -self.speed


class Coin(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

    def update(self):
        if player.collides_with(self):
            global score
            score += 1
            self.to_remove = True


class Portal(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

    def update(self):
        global show_portal_text
        if self.colliderect(player):
            show_portal_text = True
            if keyboard.e:
                 print('Niveau 2 !')
            global platforms
            global slimes
            global coins
            global portals
            platforms, slimes, coins, portals = load_level(WORLD_MAP_2)

        else:
            show_portal_text = False
               


def load_level(world_map):
    platforms = []
    slimes = []
    coins = []
    portals = []
    for row in range(ROWS):
        for col in range(COLS):
            pos = (col * TILE_SIZE + TILE_SIZE / 2, row * TILE_SIZE + TILE_SIZE / 2)
            if world_map[row][col] == 1:
                platform = Platform('grass_tile', pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 2:
                platform = Platform('grass_tile', pos, solid=True, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 3:
                platform = Platform('grass_tile', pos, solid=True, sticky=True, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 4:
                slime = Slime('slime_green1', pos, max_distance_x=300)
                slimes.append(slime)
            elif world_map[row][col] == 5:
                coin = Coin('coin', pos)
                coins.append(coin)
            elif world_map[row][col] == 6:
                portal = Portal('portal', pos, width=TILE_SIZE)
                portals.append(portal)

    return platforms, slimes, coins, portals


player = Player('alien_walk1', (100, 100))

platforms, slimes, coins, portals = load_level(WORLD_MAP)


def draw_game_over():
    screen.fill('black')
    screen.draw.text('Game Over', center=(WIDTH // 2, HEIGHT // 2), fontsize=60, color='white')
    screen.draw.text('Press SPACE to Restart', center=(WIDTH // 2, HEIGHT // 2 + 80), fontsize=30, color='white')


def draw():
    if player.game_over:
            draw_game_over() 
            return
            
    screen.fill('sky blue')
    player.draw()
    for slime in slimes:
        slime.draw()
    for platform in platforms:
        platform.draw()
    for coin in coins:
        coin.draw()
    for portal in portals:
        portal.draw()

    screen.draw.text(f'Cherry: {score}', topleft=(10, 10), fontsize=40, color='black')

    if show_portal_text:
        screen.draw.text("Press E", center=(player.x, player.y - 50), fontsize=30, color='white')


def update():
    global score, show_press_e
    if player.game_over:
        if keyboard.space:  # Redémarrer le jeu si le joueur appuie sur espace
            restart_game()
        return
        
    player.update()
    for slime in slimes:
        slime.update()
    for coin in coins:
        coin.update()
    for portal in portals:
        portal.update()

    remove_actors(coins)


def restart_game():
    global platforms, slimes, coins, portals           #chatgpt m'a aidé pour restart la game, j'ai toujours un problème avec le score
    player.pos = (100, 100)  
    player.vy = 0
    player.game_over = False
    score = 0
    platforms, slimes, coins, portals = load_level(WORLD_MAP) 

pgzrun.go()