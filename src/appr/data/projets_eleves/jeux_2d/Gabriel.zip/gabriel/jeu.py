import pgzrun
from pgzhelper import *
from random import *

TITLE = 'Hit the Fly'
WIDTH = 800
HEIGHT = 600

game_state = "menu"
difficulty = "normal"
score = 0
high_scores = {"facile": 0, "normal": 0, "difficile": 0}

difficulty_settings = {
    "facile": 2,
    "normal": 3,
    "difficile": 5
}

vie_par_difficulte = {
    "facile": 3,
    "normal": 2,
    "difficile": 1
}

vie = 0

music.play('adventure')
music.set_volume(0.5)

class Player(Actor1):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = 3

    def update(self):
        if keyboard.a:
            self.x -= self.speed
            self.flip_x = True
        if keyboard.d:
            self.x += self.speed
            self.flip_x = False
        if keyboard.w:
            self.y -= self.speed
        if keyboard.s:
            self.y += self.speed
        self.wrap_around()

    def wrap_around(self):
        if self.x < 0:
            self.x = WIDTH
        elif self.x > WIDTH:
            self.x = 0
        if self.y < 0:
            self.y = HEIGHT
        elif self.y > HEIGHT:
            self.y = 0

class Ennemy(Actor1):
    def __init__(self, image, pos, speed, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ['fly1', 'fly2']
        self.direction = randint(0, 360)
        self.speed = speed

    def update(self):
        self.direction += randint(-10, 10)
        self.move_in_direction(self.speed)
        self.wrap_around()

    def wrap_around(self):
        if self.x < 0:
            self.x = WIDTH
        elif self.x > WIDTH:
            self.x = 0
        if self.y < 0:
            self.y = HEIGHT
        elif self.y > HEIGHT:
            self.y = 0

class Heart(Actor1):
    def __init__(self, pos, speed):
        super().__init__('coeurplein', pos)
        self.direction = randint(0, 360)
        self.speed = speed

    def update(self):
        self.direction += randint(-10, 10)
        self.move_in_direction(self.speed)
        self.wrap_around()

    def wrap_around(self):
        if self.x < 0:
            self.x = WIDTH
        elif self.x > WIDTH:
            self.x = 0
        if self.y < 0:
            self.y = HEIGHT
        elif self.y > HEIGHT:
            self.y = 0

class Missile(Actor1):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = 5

    def update(self):
        global score
        self.move_in_direction(self.speed)
        if self.x < 0 or self.x > WIDTH or self.y < 0 or self.y > HEIGHT:
            self.to_remove = True

        for ennemy in ennemies:
            if self.collides_with(ennemy):
                ennemy.to_remove = True
                self.to_remove = True
                score += 1
                sounds.explosion.play()

def add_ennemy():
    ennemy = Ennemy('fly1', (randint(0, WIDTH), randint(0, HEIGHT)), difficulty_settings[difficulty])
    ennemies.append(ennemy)

def add_heart():
    heart = Heart((randint(0, WIDTH), randint(0, HEIGHT)), difficulty_settings[difficulty])
    hearts.append(heart)

def on_mouse_down(pos):
    global game_state, difficulty, score

    if game_state == "menu":
        if 250 <= pos[1] <= 300:
            difficulty = "facile"
        elif 350 <= pos[1] <= 400:
            difficulty = "normal"
        elif 450 <= pos[1] <= 500:
            difficulty = "difficile"

        game_state = "jeu"
        score = 0
        init_game()

    elif game_state == "game_over":
        if 350 <= pos[1] <= 400:
            game_state = "menu"

    else:
        missile = Missile('missile', (player.x, player.y))
        missile.direction = player.angle_to(pos)
        missile.angle = missile.direction
        missiles.append(missile)

def on_key_down(key):
    if key == keys.Q and game_state == "jeu":
        directions = [0, 45, 90, 135, 180, 225, 270, 315]
        for angle in directions:
            missile = Missile('missile', (player.x, player.y))
            missile.direction = angle
            missile.angle = angle
            missiles.append(missile)

def init_game():
    global player, ennemies, missiles, vie, hearts
    player = Player('alien_walk1', (WIDTH / 2, HEIGHT / 2))
    ennemies = [Ennemy('fly1', (randint(0, WIDTH), randint(0, HEIGHT)), difficulty_settings[difficulty])]
    missiles = []
    hearts = []
    vie = vie_par_difficulte[difficulty]
    clock.schedule_interval(add_ennemy, 5.0)
    clock.schedule_interval(add_heart, 50.0)

def draw():
    screen.fill((50, 50, 50))

    if game_state == "menu":
        screen.draw.text("Hit the Fly", center=(WIDTH // 2, 100), fontsize=60, color="white")
        screen.draw.text("Choisissez la difficulté :", center=(WIDTH // 2, 200), fontsize=40, color="white")

        screen.draw.filled_rect(Rect((300, 250), (200, 50)), "gray")
        screen.draw.text("Facile", center=(400, 275), fontsize=30, color="white")

        screen.draw.filled_rect(Rect((300, 350), (200, 50)), "gray")
        screen.draw.text("Normal", center=(400, 375), fontsize=30, color="white")

        screen.draw.filled_rect(Rect((300, 450), (200, 50)), "gray")
        screen.draw.text("Difficile", center=(400, 475), fontsize=30, color="white")

    elif game_state == "jeu":
        screen.blit('grass', (0, 0))
        player.draw()
        for ennemy in ennemies:
            ennemy.draw()
        for missile in missiles:
            missile.draw()
        for heart in hearts:
            heart.draw()

        screen.draw.text(f"Score: {score}", topright=(WIDTH - 20, 10), fontsize=30, color="white")
        screen.draw.text(f"Vie: {vie}", topleft=(20, 10), fontsize=30, color="white")

    elif game_state == "game_over":
        screen.draw.text("Game Over", center=(WIDTH // 2, 150), fontsize=60, color="red")
        screen.draw.text(f"Score final: {score}", center=(WIDTH // 2, 250), fontsize=40, color="white")
        screen.draw.text(f"Meilleur score ({difficulty}): {high_scores[difficulty]}", center=(WIDTH // 2, 300), fontsize=40, color="yellow")

        screen.draw.filled_rect(Rect((300, 350), (200, 50)), "gray")
        screen.draw.text("Retour au menu", center=(400, 375), fontsize=30, color="white")

def update():
    global game_state, high_scores, vie

    if game_state == "jeu":
        player.update()

        for heart in hearts:
            heart.update()
            if heart.collides_with(player):
                hearts.remove(heart)
                if vie < vie_par_difficulte[difficulty]:
                    vie += 1

        for ennemy in ennemies:
            ennemy.update()
            ennemy.animate()
            if ennemy.collides_with(player):
                ennemies.remove(ennemy)
                vie -= 1
                sounds.splat.play()
                if vie <= 0:
                    if score > high_scores[difficulty]:
                        high_scores[difficulty] = score
                    game_state = "game_over"

        for missile in missiles:
            missile.update()

        remove_actors(ennemies)
        remove_actors(missiles)
        remove_actors(hearts)

pgzrun.go()
