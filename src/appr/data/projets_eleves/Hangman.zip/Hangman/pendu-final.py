import tkinter as tk
from PIL import Image, ImageTk
import random

# Define window parameters
root = tk.Tk()
root.title("The Hangman Game")
root.geometry("500x410")
root.iconbitmap('icon.ico')

# Image parameters (size)
ImageSizeX = 200
ImageSizeY = 200

# Load images and resize
images = []
for i in range(12):
    image_path = f"state{i}.png"
    img = Image.open(image_path)
    img = img.resize((ImageSizeX, ImageSizeY), Image.NEAREST)
    images.append(ImageTk.PhotoImage(img))

# Function to switch image
def image_switcher(state):
    if state < 12:
        image_hangman.config(image=images[state])
    else:
        image_hangman.config(image=dead_image)

# Function to reset the game
def reset():
    global word_to_guess, word_display, wrong_letters, right_letters, counter_round, finished
    demarrer_button.destroy()
    recommencer_button.grid(row=7, column=1, columnspan=2)
    word_to_guess = random.choice(words)
    word_display = initialize_word_display(word_to_guess)
    wrong_letters = []
    right_letters = []
    counter_round = 0
    finished = False
    counter_round_label.config(text="essais restants : {} sur 12".format(12 - counter_round))
    output_option.config(text="")
    entry.delete(0, tk.END)
    image_switcher(0)
    input_option.set("letter")
    word_display_text.config(state=tk.NORMAL)
    word_display_text.delete(1.0, tk.END)
    word_display_text.insert(tk.END, word_display)
    word_display_text.config(state=tk.DISABLED)
    wrong_letters_label.config(text="Lettres fausses: [ - ]")

# Function to handle button click and letter/word validation
def on_button_click():
    global counter_round, finished
    user_input = entry.get().lower()
    demarrer_button.destroy()
    recommencer_button.grid(row=7, column=1, columnspan=2)
    cheated = False

    if counter_round < 12 and finished == False:
        if input_option.get() == "letter":
            if len(user_input) == 1:
                if user_input in alphabet:
                    if update_word_display(user_input) == True:
                        pass
                    else:
                        counter_round += 1
                else:
                    output_option.config(text="Tu veux jouer le malin hein ?")
                    counter_round +=1
            elif len(user_input) == 0:
                output_option.config(text="Insérez une lettre")
            elif len(user_input) > 1:
                output_option.config(text="N'insérez qu'une lettre à la fois")                
            else:
                output_option.config(text="Je ne sais pas ce que tu as fais, mais tu n'as vraiment pas l'air d'avoir envie de jouer...")
        else:
            if len(user_input) > 1: 
                if check_word_guess(user_input) == True:
                    finished = True
                else :
                    counter_round += 1
            else:
                output_option.config(text="L'option \"mot\" est selectionnée")

        counter_round_label.config(text="essais restants : {} sur 12".format(12 - counter_round))

        image_switcher(counter_round)
        if not cheated and "_" not in word_display:
            output_option.config(text="Bravo! Vous avez deviné le mot.")
            finished = True
            image_hangman.config(image=notDead_image)
            word_display_text.config(state=tk.NORMAL)
            word_display_text.delete(1.0, tk.END)
            word_display_text.insert(tk.END, word_to_guess)
            word_display_text.config(state=tk.DISABLED)
        entry.delete(0, tk.END)

    if counter_round == 12 and finished == False:
        finished = True
        output_option.config(text="Vous avez atteint la limite de tentatives.\nLe mot était \"{}\".\nRecommencez à nouveau.".format(word_to_guess))
    else:
        pass

# Function to initialize word display
def initialize_word_display(word):
    return "_ " * len(word)

# Function to update word display
def update_word_display(letter):
    global word_display
    letter_found = False
    added_new_letter = False
    for i, char in enumerate(word_to_guess):
        if char == letter and word_display[i * 2] == "_":
            word_display = word_display[:i * 2] + char + word_display[i * 2 + 1:]
            letter_found = True

    if not letter_found and letter not in wrong_letters and letter not in right_letters:
        add_wrong_letter(letter)
        added_new_letter = True
    else:
        right_letters.append(letter)

    word_display_text.config(state=tk.NORMAL)
    word_display_text.delete(1.0, tk.END)
    word_display_text.insert(tk.END, word_display)
    word_display_text.config(state=tk.DISABLED)
    return not added_new_letter

# Function to add wrong letter
def add_wrong_letter(letter):
    wrong_letters.append(letter)
    wrong_letters_label.config(text="Lettres fausses: [ " + ", ".join(wrong_letters) + " ]")

# Function to check word guess
def check_word_guess(word_guess):
    global word_display
    isCharOnly = True

    for i in range(len(word_guess)):  # Corrected the loop to iterate over indices using range(len())
        found = False  # Variable to track if a character is found in the alphabet
        for l in alphabet:
            if word_guess[i] == l:
                found = True
                break
        if not found:  # Check if the character was not found in the alphabet
            isCharOnly = False
            break  # Exit the loop early if a non-alphabet character is found
    
    if word_guess == word_to_guess:
        output_option.config(text="Correct! Vous avez deviné le mot.")
        image_hangman.config(image=notDead_image)
        word_display_text.config(state=tk.NORMAL)
        word_display_text.delete(1.0, tk.END)
        word_display_text.insert(tk.END, word_to_guess)
        word_display_text.config(state=tk.DISABLED)
        return True
    elif isCharOnly == True:
        output_option.config(text="Incorrect! Essayez encore.")
        return False
    else:
        output_option.config(text="Tappe bien sur ton clavier stp.")
        return False

# Load words from file
def extractWords(file_path):
    with open(file_path, 'r') as file:
        words = [line.strip() for line in file]
    return words

# GUI Initialization
words = extractWords("filtered_words.txt")
word_to_guess = random.choice(words)
word_display = initialize_word_display(word_to_guess)
counter_round = 0
wrong_letters = []
right_letters = []
alphabet = ["","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
finished = False


counter_round_label = tk.Label(root, text="Insérez une lettre ou cliquez sur \n \"démarrer\" pour commencer")
instructions_label = tk.Label(root, text="Lettre ou un mot complet ==>")
entry = tk.Entry(root, fg="black", bg="#dce5e2", width=25)
click = tk.Button(root, text="Tester", command=on_button_click)
output_option = tk.Label(root, text="")
word_display_text = tk.Text(root, height=1, width=len(word_display), font=("Courier", 16), state=tk.DISABLED)
recommencer_button = tk.Button(root, text="Recommencer", command=reset)
demarrer_button = tk.Button(root, text="Démarrer", command=reset)


dead_image = Image.open('dead.png')
dead_image = dead_image.resize((ImageSizeX, ImageSizeY))
dead_image = ImageTk.PhotoImage(dead_image)

notDead_image = Image.open('notDead.png')
notDead_image = notDead_image.resize((ImageSizeX, ImageSizeY))
notDead_image = ImageTk.PhotoImage(notDead_image)


image_hangman = tk.Label(root, image=images[0])
input_option = tk.StringVar()
input_option.set("letter")
letter_radio = tk.Radiobutton(root, text="Lettre", variable=input_option, value="letter")
word_radio = tk.Radiobutton(root, text="Mot", variable=input_option, value="word")
wrong_letters_label = tk.Label(root, text="Lettres fausses: [ - ]")

image_hangman.grid(row=0, column=1, columnspan=2)
instructions_label.grid(row=1, column=0, columnspan=1)
entry.grid(row=1, column=1, columnspan=2)
click.grid(row=1, column=3)
output_option.grid(row=2, column=1, columnspan=2)


letter_radio.grid(row=3, column=1)
word_radio.grid(row=3, column=2)

word_display_text.grid(row=4, column=1, columnspan=2)

wrong_letters_label.grid(row=5, column=1, columnspan=2)
counter_round_label.grid(row=6, column=1, columnspan=2)
demarrer_button.grid(row=7, column=1, columnspan=2)

entry.bind('<Return>', lambda event=None: click.invoke())
root.mainloop()
