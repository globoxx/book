Bienvenue dans le jeu de pendu ! Voici les règles du jeu :

1. Le but du jeu est de deviner un mot aléatoire en un minimum de tentatives.
2. Le jeu commence en affichant le mot à deviner sous forme de tirets, chacun représentant une lettre du mot.
3. Vous avez le choix entre deux options d'entrée : "lettre" ou "mot".
    3.1 Si vous choisissez "lettre", vous devez entrer une seule lettre à la fois. Si cette lettre se trouve dans le mot à deviner, elle sera révélée à sa position respective. Sinon, une tentative sera décomptée.
    3.2 Si vous choisissez "mot", vous devez entrer un mot complet. Si ce mot correspond au mot à deviner, il sera révélé en entier. Sinon, une tentative sera décomptée.
4. Vous disposez de 12 tentatives pour deviner le mot. Chaque tentative ratée fera apparaître une partie du dessin du pendu.
5. Le jeu affiche les lettres déjà essayées et non trouvées dans la section "Lettres fausses".
6. Si vous devinez le mot avant d'épuiser vos tentatives, vous gagnez la partie et pouvez recommencer.
7. Si vous épuisez vos tentatives sans avoir deviné le mot, vous perdez la partie. Le mot sera alors révélé et vous pourrez recommencer.
8. Pour recommencer une nouvelle partie, cliquez sur le bouton "Recommencer".
Amusez-vous bien avec le jeu de pendu !