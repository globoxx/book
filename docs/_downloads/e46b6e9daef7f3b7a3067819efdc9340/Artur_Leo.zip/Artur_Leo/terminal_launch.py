from blessed import Terminal
term = Terminal()