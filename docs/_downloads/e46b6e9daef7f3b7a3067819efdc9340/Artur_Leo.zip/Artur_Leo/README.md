**Necessary libraries :**

  sys
  
  time
  
  colorama
  
  pillow(PIL)
  
  blessed
  
    pip3 install sys,time,colorama,pillow,blessed

> [!IMPORTANT]
> Due to using escape sequences please consider using a linux or maybe a windows native terminal

Here is the logic diagram of our project :
![Logigramme_TP_info_histoire_interactive_Artur_Leo(1)](https://github.com/user-attachments/assets/435289f6-2a1a-4e1c-b63c-562343349073)


Creators :
Artur Kapalka and Leo Chau,
1M02,
25th may, 2025
