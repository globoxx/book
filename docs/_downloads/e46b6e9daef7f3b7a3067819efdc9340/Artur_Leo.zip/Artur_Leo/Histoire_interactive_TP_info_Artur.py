#import histoirejeuperso as hp
from histoirejeuperso import gagné_jeu
from histoirejeuperso import actions_village
import sys,time
import colorama as col
import animated_frames
from typer import typer
from terminal_launch import term

age = 18
inscription = False
connaissance_jeu = False
connaissance_vac = False
symbols = ['⣾', '⣷', '⣯', '⣟', '⡿', '⢿', '⣻', '⣽']
fcyan = col.Fore.CYAN
fred = col.Fore.RED
fgreen = col.Fore.GREEN
fblue = col.Fore.BLUE
fmag = col.Fore.MAGENTA
fyel = col.Fore.YELLOW
sdim = col.Style.DIM
sbr = col.Style.BRIGHT
fwh = col.Fore.WHITE
save = '\x1b[s'
restore = '\x1b[u'
erase = '\x1b[0j'

def poserquestion():
    print(term.normal_cursor())
    reponse =  input()
    print(term.hide_cursor())
    return reponse
def achievement(achv_name):
    typer(text="Bravo !! Vous avez réalisé l'exploit : ",style=fcyan+sbr)
    typer(text=achv_name, style=fblue+sbr)
    typer(text="Attention certain peuvent impacter le déroulement de l'histoire", style=fred+sbr)




def inscrire():
    global inscription
    typer(text="Voulez-vous quand même vous inscrire à l'université ?",style=fmag+sbr)
    typer(text="\noui  ",style=fgreen+sbr,newline=False,spelling=False)
    typer(text="  non\n",style=fred+sbr,spelling=False)
    rep = poserquestion()
    if rep =="oui":
        inscription = True
    elif rep == "non":
        inscription = False
    else:
        print(restore)
        print(erase)
        print(restore)
        inscrire()



def vacances():
    global connaissance_jeu,connaissance_vac
    typer(text="Voulez-vous partir ou rester à la maison réviser et si partir alors à la mer ou à la ville ?",style=fmag+sbr,spelling=False)
    typer(text="reviser  ",style=fwh,newline=False,spelling=False)
    typer(text="  mer  ",style=fwh,newline=False,spelling=False)
    typer(text="  ville",style=fwh,spelling=False)
    if 'rep' not in locals():
        rep = poserquestion()
    if rep == "reviser":
       typer(text="Vous passez l'entierté de vos vacances à travailler")
    elif rep == "mer":
        typer(text="pendant votre repos à la mer vous faite connaissance d'une personne s'interessant aux mêmes choses que vous.\n")
        connaissance_vac = True
        achievement("Connaissance des vacances")
    elif rep == "ville":
        typer(text="Vous partez à Berlin.\nVous vous ennuyez à cause de la mauvaise météo.")
        typer(text="voulez-vous jouer à un jeu vidéo ou plutôt dormir ?")
        typer(text="jouer  ", style=fwh + sbr, newline=False, spelling=False)
        typer(text="  dormir", style=fwh + sbr, spelling=False)
        rep1 = poserquestion()
        if rep1 == "dormir":
            typer(text="Vous ne faites pas grand chose de vos vacances")
        elif rep1 == "jouer":
            typer(text="Vous lancez "+col.Fore.LIGHTBLUE_EX+"\"Hollow Knight\""+col.Style.RESET_ALL+", un jeu que vous ne connaissiez pas auparavant")
            for x in range(5):
                for i in symbols:
                    sys.stdout.write('\rle jeu charge '+i)
                    time.sleep(0.2)
            animated_frames.Hollow_knight_title()
            actions_village()
            connaissance_jeu = True
            achievement("Connaissance de " + col.Fore.LIGHTBLUE_EX + "\"Hollow Knight\"" + col.Style.RESET_ALL)
            if gagné_jeu == True:
                achievement("gagner au jeu "+col.Fore.LIGHTBLUE_EX+"\"Hollow Knight\""+col.Style.RESET_ALL)
            typer(text="Tu découvre un nouveau jeu, il te plais et tu te renseigne un peu plus dessus")
        else:
            print(restore)
            print(erase)
            print(restore)
            vacances()
    else:
        print(restore)
        print(erase)
        print(restore)
        vacances()



def check_inscription():
    global age
    if inscription == True:
        age += 3
        typer(text="Enfin, les résultats sont arrivés et contre toute attente vous les réussisez.\nVous partez à l'université.\nVous faites plein de connaissances ")
        typer(text="Tu vas à l'université. Tu fais plein de connaissances")
        check_connaissances_inscrit()
    elif inscription == False:
        age += 1
        typer(text="Malheureusement tu découvre que tu as passé les examens. Tu passe donc l'année à chercher un apprentissage\nVous trouver du travail mais vous n'y restez pas pendant longtemps\nVous voyagez entre differentes places de travail sans jamais trouver une place fixe pendant 10 ans")
        age += 10
        check_connaissance_vac_pas_inscrit()

def check_connaissance_vac_pas_inscrit():
    global age
    if connaissance_vac == True:
        age += 10
        typer(text="Un jour alors que vous etiez à votre n-ième entretient, le visage d'une des personnes vous parait famillière.\nC'était l'ami que vous aviez reoncontrez il y a dix ans pendant vos vacances\nFinalement il vous embauche sous raison que vous êtes encore assez jeune pour faire un aprentissage de racordement")
        time.sleep(4)
        typer(text="vous avez eu une vie difficile au départ mais heureusement quelqu'un vous a sauvé",style=fyel)
        typer(text="Votre âge auquel vous réussisez votre vie est de: "+str(age)+" ans")
    elif connaissance_vac == False:
        typer(text="votre vie continue mais vous n'arrivez pas à trouver de travail stable\nFinalement vous trouvez une offre très prometante et vous appliquez")
        time.sleep(4)
        if age < 35:
            typer(text=col.Fore.YELLOW+"Vous êtes enfin embaucher car vous êtes assez jeune")
            typer(text="Votre âge auquel vous réussisez votre vie est de: " + str(age) + " ans")
        else:
            typer(text="malheureseument votre application est refusée pour cause que vous êtes trop agé et que ce n'est plus assez rentable pour l'entreprise \nVous ne parvenez jamais à vivre une vie facile",style=fred)



def check_connaissances_inscrit():
    global age
    if connaissance_jeu == True:
        typer(text="pendant vos études vous rencontrez quelq'un ayant les mêmes passions pour le jeu vidéos surtout dans celui auquel vous avez joué pendant les vacances\nVous et votre ami vous lancez dans le gaming, après plusieurs année de travail acharné et des championats qui ne se passent pas toujours comme prévu vous réussissez à ateindre les championnats du monde")
        time.sleep(4)
        if gagné_jeu == True:
            typer(text="Vous gagnez les championats, avec l'argent que vous amassez vous ouvrez votre rêve ; un centre gaming pour les jeunes",style=fgreen)
            age += 15
            typer(text="Votre âge auquel vous réussisez votre vie est de: " + str(age) + " ans")
        elif gagné_jeu == False:
            age += 10
            typer(text="malheureusement vous perdez aux finales mais vous n'abandonnez pas et vous réassayez quelques années plus tard avec l'argent de tout les concours  vous arretez votre carrière, vous partez à la retraite ",style=fgreen)
            typer(text="Votre âge auquel vous réussisez votre vie est de: " + str(age) + " ans")
    elif connaissance_vac == True:
        time.sleep(4)
        age += 30
        typer(text="Vous finnissez vos études et après la pause d'été, vous rencontrez votre ami des vacances au bord de la mer et il vous propose une offre de travail dans son entreprise\nCette entreprise s'avère être un succès dans votre vie et vous la menez convenablement jusqu'à la fin",style=fgreen)
        typer(text="Votre âge auquel vous réussisez votre vie est de: " + str(age) + " ans")
    else:
        age += 15
        typer(text="Vous finnissez vos études mais vous ne trouver pas d'emploi")
        check_connaissance_vac_pas_inscrit()


def mainly():
    global age
    typer(text="Vous travaillez pendant 3h.\n"
          "À cause de votre travail acharné vous dormez assez mal.\n"
          "Le matin vous vous reveillez tard et ducoup vous devez partir en courant à l'école.\n"
          "Après les examens vous avez l'impression de les avoir totalement raté.")
    time.sleep(4)
    print(save)
    inscrire()
    typer(text="Les vacances arrivent et vous hésitez si partir en vacances")
    time.sleep(4)
    print(save)
    vacances()
    age += 1
    typer(text="Vos vacances arrivent à la fin et les résultats des examens devraient arriver bientôt")
    time.sleep(4)
    check_inscription()

