import sys
import time
import random

import colorama as col

dev = True  #if you want to skip the writig time

def print_char(char):
    sys.stdout.write(char)
    sys.stdout.flush()

def backspace():
    sys.stdout.write('\b \b')
    sys.stdout.flush()
def typer(text,style=None,min_delay=0.02,max_delay=0.1,newline=True,correcting_speed=0.2,spelling=True):
    a = 0
    if dev:
        spelling = False
        max_delay = 0
        min_delay = 0
    if style:
        text = style + text
    for char in text:
        delay = random.uniform(min_delay,max_delay)
        if spelling and random.randint(0,25) == 4 and a != 0:
            typo = random.choice('abcdefghijklmnopqrstuvwxyz')
            print_char(typo)
            time.sleep(correcting_speed)
            backspace()
            time.sleep(correcting_speed)
        print_char(char)
        time.sleep(delay)
    if a == 0:
        a += 1
    if newline:
        print(col.Style.RESET_ALL)
        print()


def typers(text,style=None,min_delay=0.02,max_delay=0.1,newline=True,correcting_speed=0.2,spelling=False):
    a = 0
    if dev:
        spelling = False
        max_delay = 0
        min_delay = 0
    if style:
        text = style + text
    for char in text:
        delay = random.uniform(min_delay,max_delay)
        if spelling and random.randint(0,25) == 4 and a != 0:
            typo = random.choice('abcdefghijklmnopqrstuvwxyz')
            print_char(typo)
            time.sleep(correcting_speed)
            backspace()
            time.sleep(correcting_speed)
        print_char(char)
        time.sleep(delay)
    if a == 0:
        a += 1
    if newline:
        print(col.Style.RESET_ALL)
        print()
