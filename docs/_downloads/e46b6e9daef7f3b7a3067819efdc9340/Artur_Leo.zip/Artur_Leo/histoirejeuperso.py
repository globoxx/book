import sys,time,animated_frames
from typer import typer,typers
import colorama as col
esc = '\x1b'
save = esc +'[s'
restore = esc+'[u'
erase = esc+'[0j'
exp_required_lvl = 1
final_boss = ""
fcyan = col.Fore.CYAN
fred = col.Fore.RED
fgreen = col.Fore.GREEN
fblue = col.Fore.BLUE
fmag = col.Fore.MAGENTA
fyel = col.Fore.YELLOW
sdim = col.Style.DIM
sbr = col.Style.BRIGHT
fwh = col.Fore.WHITE
rst = col.Style.RESET_ALL
stats_perso = {
    "argent":10,
    "force":0,
    "magie":0,
    "vie_max":5,
    "vie":5,
    "lvl":12,
    "exp_perso":0
}

dégats_monstres = {
    "slime": 1,
    "lapin":  3,
    "goblin":  10,
    "orc":  25,
    "liche":  25,
    "loup": 10,
    "final_boss":1000
}
stat_monstres = {
    "slime":  1,
    "lapin":  3,
    "goblin":  10,
    "orc":  25,
    "liche":  25,
    "loup": 10,
    "final_boss":50
}
exp_monstre = {
    "slime": 1,
    "lapin": 2,
    "goblin": 10,
    "orc": 20,
    "liche": 20,
    "loup": 10,
    "final_boss":1000
}


stats_armes_force = {
    "bâton en bois": 1,
    "épée en fer": 10,
"épée apocalypse":20
}

stats_armes_magie = {
    "bâton magique ataraxia": 5
}
location = "village"
quêtes_mage = {
    "La Grande Plaine":["slimes magique(écrivez slime) -> 1x slime = 1 exp","lapins de feu(écrivez lapin) -> 1x lapin = 2 exp"],
    "La Fôret Éthérée, lvl minimum 10":["liche(écrivez liche) -> 1x liche = 20 exp","orcs(écrivez orc) -> 1x orc = 10 exp"]
}
quêtes_guerrier = {
    "La Grande Plaine":["slimes(écrivez slime) -> 1x slime = 1 exp","lapins crocs(écrivez lapin) -> 1x lapin = 2 exp"],
    "La Fôret Éthérée, lvl minimum 5": ["goblins(écrivez goblin) -> 1x goblin = 10 exp", "Loups-Garous(écrivez loup) -> 1x Loups-Garous = 20 exp"]
}
inventaire = {
    "nourriture": ["pomme"],
    "armes": ["bâton en bois"],
    "loot": []
}
def choix_perso():
    global profession
    typers(text="Choissisez votre personnage:",style=fblue)
    typers(text="\n guerrier : "+fred+"vie 20,"+fblue+" force 10,"+fmag+" magie 0 \n mage : "+fred+"vie 20, "+fblue+"force 0, "+fmag+"magie 10 \n"+rst)
    profession = input()
    if profession =="guerrier":
        stats_perso["force"] += 10

    elif profession =="mage":
        stats_perso["magie"] += 10
    else:
        typers(text="vous n'avez pas choisit un personnage existant",style=fred)
        sys.exit()

    position = "au village"

    typer(text="vous êtes un "+profession+",actuellement vous vous trouvez "+position,style=sbr+fwh)


def animate(temp):
    for i in range(temp):
        sys.stdout.write(fgreen+sbr+'\rcombat en cours |')
        time.sleep(0.1)
        sys.stdout.write('\rcombat en cours /')
        time.sleep(0.1)
        sys.stdout.write('\rcombat en cours -')
        time.sleep(0.1)
        sys.stdout.write('\rcombat en cours \\')
        time.sleep(0.1)
    sys.stdout.write('\rle combat est terminé     '+rst)
def mort():
    total = stats_perso["argent"]+stats_perso["force"]+stats_perso["magie"]+stats_perso["vie_max"]+stats_perso["lvl"]
    typers(style=fred,text="Vous êtes mort. ")
    typers("Votre partie est términée, vos stats : \n Votre argent : "+fyel+str(stats_perso["argent"])+"\n Votre force : "+fblue+str(stats_perso["force"])+"\n Votre force magique : "+fmag+str(stats_perso["magie"])+"\n Votre vie totale : "+fred+str(stats_perso["vie_max"])+rst+"\n Votre niveau : "+str(stats_perso["lvl"])+"\n Votre score total : "+str(total))
    sys.exit()

def supermarché():
    global argent
    continued = True
    total = 0
    cadis = []
    def liste_courses():
        for i in cadis:
            typers(text=" "+i+"\n")

    while continued:
        typers(text="vous êtes au magasin, que voulez-vous acheter ? \n pomme -> +"+fred+" 1 vie -> "+fyel+"1 pièce"+rst+" \n steak -> + "+fred+"10 vies -> "+fyel+"8 pièces"+rst)
        achat = input()
        cadis.append(achat)
        typers("Avez-vous finis vos courses ?")
        fini = input()
        if fini == "oui":
            continued = False
    for i in cadis:
        if i == "pomme":
            total += 1
        elif i == "steak":
            total += 8
        else:
            typers("Vous avez choisit un objet qui n'existe pas : " + fred + i)
            cadis.remove(i)
    cadis.sort()
    typers("Voici vos courses : \n")
    liste_courses()
    typers("à payer: "+str(total))
    if total <= stats_perso["argent"]:
        typers("Merci pour vos achats")
        stats_perso["argent"] -= total
        typers("Il vous reste "+fyel+str(stats_perso["argent"])+" pièces")
    elif total < stats_perso["argent"]:
        typers("Vous n'avez pas assez d'argent")
        typers("Il vous manque "+fyel+str(total - stats_perso["argent"])+" pièces")

def forgeron():
    continued = True
    typers("Vous avez "+fyel+str(stats_perso["argent"])+" pièces")
    total = 0
    cadis = []
    def liste_courses():
        for i in cadis:
            typers(i+"\n")

    while continued:
        typers("vous êtes au forgeron, que voulez-vous acheter ? \n bâton en bois -> + "+fblue+"1 force -> "+fyel+"1 pièce \n épée en fer -> + "+fblue+"10 force ->"+fyel+" 8 pièces \n épée apocalypse -> + "+fblue+"20 force -> "+fyel+"30 pièces \n bâton magique ataraxia -> +"+fmag+" 5 magie -> "+fyel+"8 pièces ")
        achat = input()
        cadis.append(achat)
        typers("Avez-vous finis vos courses ?")
        fini = input()
        if fini == "oui":
            continued = False
    for i in cadis:
        if i == "bâton en bois":
            inventaire["armes"].append("bâton en bois")
            stats_perso["force"] += stats_armes_force[i]
            total += 1
        elif i == "épée en fer":
            inventaire["armes"].append("épée en fer")
            stats_perso["force"] += stats_armes_force[i]
            total += 8
        elif i == "épée apocalypse":
            inventaire["armes"].append("épée apocalypse")
            stats_perso["force"] += stats_armes_force[i]
            total += 30
        elif i == "bâton magique ataraxia":
            inventaire["armes"].append("bâton magique ataraxia")
            stats_perso["magie"] += stats_armes_magie[i]
            total += 8
        else:
            typers("Vous avez choisit un objet qui n'existe pas : "+fred+i)
            cadis.remove(i)
    cadis.sort()
    typers("Voici vos courses : \n")
    liste_courses()
    typers("à payer: "+fyel+str(total)+" pièces")
    if total <= stats_perso["argent"]:
        typers("Merci pour vos achats")
        stats_perso["argent"] -= total
        typers("Il vous reste "+fyel+str(stats_perso["argent"])+" pièces")
    elif total < stats_perso["argent"]:
        typers("Vous n'avez pas assez d'argent")
        typers("Il vous manque " +fyel+str(total - stats_perso["argent"])+" pièces")


def guilde():
    print(save)
    global stats_perso,plus
    while True:
        continuer = True
        typers("Vous êtes à la guilde")
        typers("Que voulez-vous faire ? \n regarder la liste des quêtes(quetes) \n regarder ses stats(stats) \n regarder votre coffre à items(items) \n partir")
        action = input()
        if action == "partir":
            return False
        elif action == "quetes":
            if profession == "guerrier":
                typers("Voici les quêtes disponibles, choisissez-en une")
                for key,values in quêtes_guerrier.items():
                    typers(f"{key}:")
                    for value in values:
                        typers(f"  {value}")
                choisit = input()
            elif profession == "mage":
                typers("Voici les quêtes disponibles, choisissez-en une")
                for key,values in quêtes_mage.items():
                    typers(f"{key}:")
                    for value in values:
                        typers(f"  {value}")
                choisit = input()
            while continuer:
                if choisit == "liche" or choisit == "orc":
                    if stats_perso["lvl"] <10:
                        typers("Votre niveau est trop bas pour pouvoir accéder à La Fôret Éthérée")
                        continuer = False
                if choisit == "goblin" or choisit == "loup":
                    if stats_perso["lvl"] <5:
                        typers("Votre niveau est trop bas pour pouvoir accéder à La Fôret Éthérée")
                        continuer = False
                typers("Vous allez tuer des "+str(choisit))
                animate(int(stat_monstres[choisit]))
                if stats_perso["force"] >= int(stat_monstres[choisit]) or stats_perso["magie"] >= int(stat_monstres[choisit]):
                    typers("vous avez battu le "+choisit)
                    stats_perso["exp_perso"] += int(exp_monstre[choisit])
                elif stats_perso["force"] < int(stat_monstres[choisit]) or stats_perso["magie"] < int(stat_monstres[choisit]):
                    typers("Le monstre est plus fort que vous. Vous perdez "+str(dégats_monstres[choisit]))
                    stats_perso["vie"] -= int(dégats_monstres[choisit])
                    typers("il vous reste"+str(stats_perso["vie"])+"sur"+str(stats_perso["vie_max"])+"vies")
                    if stats_perso["vie"] <=0:
                        mort()
                plus = True
                lvl_up()
                continuer = False
        elif action == "stats":
            typers(stats_perso)
        elif action == "items":
            typers("Votre inventaire :")
            typers(inventaire)
        else:
            print(restore)
            print(erase)
            print(restore)
running = True
def actions_village():
    print(save)
    global running,final_boss,gagné_jeu
    choix_perso()
    while running:
        Final_boss_check()
        typers("Où voulez-vous aller ? \n supermarché \n forgeron \n guilde \n arreter le jeux(écrivez stop)\n "+final_boss)
        action = input()
        if action == "supermarché":
            supermarché()
        elif action == "forgeron":
            forgeron()
        elif action == "guilde":
            guilde()
        elif action == "stop":
            for i in stats_perso:
                typers("Votre " + i+": "+ str(stats_perso[i]))
                gagné_jeu = False
            running = False
        elif action == "boss final":
            Final_boss()
            running = False
        else:
            print(restore)
            print(erase)
            print(restore)


def lvl_up():
    global exp_required_lvl,plus
    while plus:
        if stats_perso["exp_perso"] > exp_required_lvl:
            stats_perso["exp_perso"]+= 1
            exp_required_lvl *= 2
            typers(text="Bravo ! Vous êtes monté de 1 niveau",style=fcyan)
        else:
            plus = False
    typers("Votre niveau actuel est de "+fgreen+str(stats_perso["lvl"]))
def Final_boss_check():
    global final_boss
    if stats_perso["lvl"]>11:
        final_boss = "aller battre le boss final(écrivez boss final)"
gagné_jeu = None
def Final_boss():
    global gagné_jeu
    typers("Vous partez à la recherche du "+fred+sbr+"Roi Demon\n"+rst)
    print(save)
    animated_frames.running_knight_ver1()
    typer("Voulez vous gagner au jeu ?\n(je sais j'avais la flemme et pas d'idées, désolé)")
    gagner = input()
    if gagner == "oui":
        animated_frames.mini_knight_attack()
        gagné_jeu = True
    else:
        gagné_jeu = False


