from terminal_launch import term
import colorama as col
from typer import typer
from code_histoire_interactive_leo import dormir
from Histoire_interactive_TP_info_Artur import mainly
print(term.clear + term.hide_cursor())
leo=False
typer(text="Disclaimer : toutes vos réponses doivent être écrites en minuscules, uniquement avec les caractères de la table ASCII et utilisez des mots-clés",style=col.Fore.RED+col.Back.BLACK+col.Style.BRIGHT)
typer(text="Vous êtes rentré de l'école, vous venez d'avoir 18 ans mais il n'est pas temps de fêter car les examens commencent demain et vous n'êtes pas sûr si vous devriez travailler ce soir.")
print('\x1b[s')
def poserquestion():
    print(term.normal_cursor())
    reponse =  input()
    print(term.hide_cursor())
    return reponse

def start():
    typer(text="Voulez-vous réviser ou aller vous reposer",style=col.Fore.MAGENTA+col.Style.BRIGHT)
    typer(text="travailler  ",style=col.Fore.CYAN+col.Style.BRIGHT,newline=False)
    typer(text=" dormir", style=col.Fore.CYAN+col.Style.BRIGHT)
    rep = poserquestion()
    return rep



def check():
    global leo
    print('\x1b[s')
    rep = start()
    while rep != "travailler" and rep != "dormir":
        print('\x1b[u')
        print('\x1b[0J')
        print('\x1b[u')
        rep = start()
    if rep == "travailler":
        mainly()
    elif rep == "dormir":
        dormir()
        leo = True
        pass



check()
if leo == True:
    mainly()