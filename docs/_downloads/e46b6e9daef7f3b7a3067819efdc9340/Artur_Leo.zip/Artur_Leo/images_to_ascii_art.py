from PIL import Image,ImageEnhance

symbols = [" ",".",",","-","~",":",";","=","!","*","?","$","@","#"]
symbols_inverted = ["#","@","$","?","*","!","=",";",":""~","-",",","."," "]
symbolsbnw = [" ","#"]
dict = {
    "frame = r\"\"\"\\ \n":1,
    "\"\"\"":2
}

#imag = Image.open("")
#width,height = imag.size

def blacknwhite(image):
    blacknwhite = image.convert("1")
    return (blacknwhite)

def contrasting(image):
    contrast_factor = 3
    enhancer = ImageEnhance.Contrast(image)
    contrasted_image = enhancer.enhance(contrast_factor)
    return contrasted_image
def resize(image, new_width=200,new_height=30):
    resized_image = image.resize((new_width,new_height))
    return(resized_image)

def grayscaling(image):
    grayscaled = image.convert("L")
    return(grayscaled)

def pixel_to_asciigray(image):
    pixels = image.getdata()
    characters = "".join([symbols[pixel//25] for pixel in pixels])
    return(characters)

def maingray(image,save,new_width=200):
    new_image_data = pixel_to_asciigray(contrasting(grayscaling(resize(image))))
    pixel_count = len(new_image_data)
    ascii_image = "\n".join(new_image_data[i:(i+new_width)] for i in range(0,pixel_count,new_width))
    ascii_image2 = ascii_image.join(dict)
    print(ascii_image)
    with open(save,"w") as f:
        f.write(ascii_image2)

def pixel_to_asciibnw(image):
    pixels = image.getdata()
    characters = "".join([symbolsbnw[pixel//255] for pixel in pixels])
    return (characters)

def mainblacknwhite(image,save,new_width=200):
    new_image_data = pixel_to_asciibnw(blacknwhite(resize(image)))
    pixel_count = len(new_image_data)
    ascii_image = "\n".join((new_image_data[i:(i + new_width)] for i in range(0, pixel_count, new_width)))
    ascii_image2 = ascii_image.join(dict)
    print(ascii_image)
    with open(save, "w") as f:
        f.write(ascii_image2)



def principal():
    gray_or_bnw = input("do you want a black and white ascii art or a grayscaled ascii art ?\noption 1 or 2\n")

    directory = input("what photo do you want to transform (please put the complete directory):\n")

    saved = input("What will be the name of the text file containing the ascii art ?\n(please note that it will be saved in the place where this programm is)\n")
    try:
        image = Image.open(directory)
        if gray_or_bnw == "1":
            mainblacknwhite(image,saved)
        elif gray_or_bnw == "2":
            maingray(image,saved)
    except:
        print("the directory you mentioned is wrong or cannot be accessed")

principal()