import colorama
from typer import typer

blue = colorama.Fore.BLUE
normal = colorama.Style.RESET_ALL
red = colorama.Fore.RED
magenta = colorama.Fore.MAGENTA
yellow = colorama.Fore.YELLOW
save = '\x1b[s'
restore = '\x1b[u'
erase = '\x1b[0j'
age = 18

def dormir():
    global age
    typer("Tu es tout confiant, donc tu pars te coucher.\nHabillé en pyjama, tu te couches dans ton lit puis tu t'endors... \nBiiip biiip biiip, ton réveil sonne !")
    print(save)
    choix = input("Tu te réveilles et tu prends un petit-déjeuner ?")
    if choix == "oui":
        print(save)
        manger = input("Tu te mets à table, tu vas prendre quoi ? croissant ou tartine")
        if manger == "croissant":
            typer("Crunch... crunch, maintenant tu n'as plus faim.")
        elif manger == "tartine":
            print("En mangeant la moitié, tu fais tomber la part par terre.")
        else:
            faute()
    elif choix == "non":
        typer("Tu vois qu'il te reste encore du temps donc tu repars dans ton lit.")
    else:
        faute()
    typer("Tu sors de chez toi en direction de l'école en chantonnant.")
    typer("Pendant l'examen, tu trouves les exercices drôlement faciles mais tu ne te poses pas plus de questions que ça.")
    typer("En rentrant de l'école, tu vas fièrement vers tes parents pour te vanter de la facilité de l'examen, c'est sûr que tu allais réussir.")
    typer("Tu remontes dans ta chambre pour t'inscrire à l'université.")
    typer("Pendant les premières semaines des vacances, tu décides de réviser pour être prêt dans le futur.")
    typer("Mais lors de la troisième semaine, tu reçois les résultats et c'est un désastre, tu as loupé tes examens.")
    typer("Pendant un instant, tu penses rêver mais c'est bel et bien la réalité.")
    typer("Énervé, tu arrêtes de travailler et tu commences à ne plus sortir de ta chambre.")
    typer("Alors tes parents décident de te fuir en partant aux États-Unis et te donnent une consigne : ne rien casser dans la maison sinon tu seras expulsé.")
    typer("Tu décides donc d'aller jouer sur ton PC.")
    print(save)
    jeux = input("À quel jeu veux-tu jouer ? the_mage ou the_monster ?")
    if jeux == "the_mage":
        the_mage()
    elif jeux == "the_monster":
        print(save)
        typer("Tu te réveilles dans une petite grotte et en sortant, tu vois un jeune homme. Il explique qu'il a pris soin de toi pendant que tu étais dans le coma et qu'un désastre est arrivé : une faille est apparue sur Terre et des monstres sont apparus, maintenant la Terre est toute détruite et les monstres règnent sur cette planète.")
        typer("Tu joues pendant quatre heures et tu décides d'arrêter de jouer pour commander à manger.")
        nourriture = input("Tu prends sushi ou burger ?")
        if nourriture == "sushi":
            typer("Tu dépenses beaucoup mais tu passes un bon repas.")
        elif nourriture == "burger":
            typer("Tu manges à ta faim.")
        else:
            faute()
    else:
        faute()
    typer("Après avoir mangé, tu décides de remonter dans ta chambre pour continuer à jouer mais tu vois que tu n'as rien enregistré donc tu arrêtes de jouer.")
    typer("Quand tes parents rentrent, ils voient que tu n'as rien rangé chez toi et que la maison est dans un désordre pas possible.\nTes parents t'expulsent de la maison et te disent d'aller trouver un travail pour acheter une maison car à partir de maintenant ils ne vont plus t'héberger.")
    age += 1
    print(save)
    travail = input("Tu décides donc d'aller travailler et tu as le choix entre caissier ou concierge.")
    if travail == "caissier":
        typer("Grâce à ton travail tu as pu louer un studio et tu continues comme ça pendant 3 ans.")
        age += 3
    elif travail == "concierge":
        typer("Tu dois rester dans la rue pendant 2 semaines mais après ce temps tu arrives à louer un studio et tu continues de travailler pendant 4 ans.")
        age += 4
    else:
        faute()
    typer("Après des années de travail tu décides de changer de travail mais avec les études que tu as faites tu n'as pas beaucoup de choix qui s'offrent à toi.")
    typer("Donc tu cherches pendant 2 ans mais tu ne trouves rien.\nMais finalement tu as réussi à trouver un travail en tant que laveur de vitres pour une entreprise.")
    age += 2
    typer("Après 35 ans de travail tu tombes dans une grosse dépression et tu te remets en question.")
    age += 35
    typer("Tu te demandes pourquoi tu n'avais pas plus révisé quand tu étais plus jeune et que maintenant tu as " + str(age) + " ans donc tu ne pourras plus rattraper tout ça.")
    typer("Et à ce moment précis tu entends un gros BOOM puis..............")
    typer("Tu découvre que tu t'étais endormis sur ton canapé. Après ce rêve spécial tu te décide de travailler car tu as peur de finir comme dans ton rêve")
    

inventaire= []
def the_mage():
    global inventaire,arme
    typer("tu lances le jeux et ton personnage apparait dans l'espace puis une lumière viens te parler")
    print(save)
    habille = input("La lumière te demande quel habit tu voulais porter. Tu as le choix entre un caleçon ou mode_aléatoire")
    if habille == "caleçon":
        typer("maintenant, ton personnage porte un caleçon")
    elif habille == "mode_aléatoire":
        typer("tu tourne la roue des vetements \nbip bip bip, tu es tombé sur un caleçon \nQuel malheur!!!")
    else:
        faute()
    typer("BOUMMM!! \ntu ouvres les yeux est devant toi se trouve un roi et une reine, ils etaient jeunes \nils y avaient aussi beaucoup de chevalier autour de toi armée d'une lance et d'une grosse armure")
    typer( "roi:" +blue+"Cher hero, nous t'avons appeler pour une requete. Notre fille etait partie en voyage mais depuis 5 jours, nous ne recevons plus de ses nouvelles \n hier nous avons reçu une lettre de la part des bandits du royaume de goon \n et dans cette lettre est écrit que ils détiennent notre filles et si nous ne leur donnons pas 1 million de pieces d'or, alors ils tuerons notre fille")
    typer(normal+ "moi:" +red+ "Donc vous voulez que moi, un simple chevalier du royaume de 2, aie sauver la princesse ?")
    typer(normal+ "reine:" +magenta+ "OUI s'il vous plaît, nous avons demander a des centaines d'autres chevalier mais ils ont tous décliné notre offe")
    typer(normal+ "moi:" +red+ "quelle est donc cette fameuse récompense?")
    typer(normal+ "roi:" +blue+ "si tu arrives à sauver notre fille, nous t'offrons un marriage avec elle, tu deviendras donc un prince et nous te donnerons des terres dans le royaume")
    typer(normal+ "moi:" +red+ "mmh j'accepte l'offre \ndonner moi toute les information que vous connaisser pour que je parte a sa recherche")
    typer(normal+ "roi:" +blue+ "d'accord, voila les informations  que nous avons, bla...bla...bla...blaa \net voici votre les affaires qu'on va vous donnez pour cette expedition")
    typer(yellow+ "+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ piece d'or\n+ dague\n un sac à dos" )
    inventaire.extend(("dague","piece d'or","piece d'or","piece d'or","piece d'or","piece d'or","piece d'or","piece d'or","piece d'or","piece d'or","piece d'or","piece d'or","piece d'or","piece d'or","piece d'or","piece d'or","piece d'or","piece d'or"))
    inventaire.append("une bague magique")
    typer(normal + "avec l'argent que le roi t'a donné, tu décides d'aller au marché pour t'équiper avec de meilleur équipement\narrivé au marché tu vois plein de meme exemplaires d'armes dans les vitrines, il y a \nune bague magique à 6 pieces d'or\nun gros bouclier à 3 pieces d'or\nune longue épée à 4 pieces d'or\nune cape d'invisibilité pour 15 pieces d'or")
    print(save)
    magasin()
    typer("après tes achats tu décides tout de suite de partir à la recherche de la princesse\ngrace a tes compétance de détective tu arrive a reetrouver la princesse apres 3 jours de recherche mais elle est entourer de bandit du royaume de goon\nautour d'un arbre la princesse etait attaché et tu réflechis a ce que tu vas faire pour la sauver ")
    if arme_u() == True:
        typer("tu regardes dans ton inventaire et une idée de viens à l'esprit\net si tu prenais ta cape pour aller doucement chercher la princesse et revenir sans que personne ne puisse te voir\ndonc tu prends ta cape et tu vas chercher la princesse et vous arriver a revenir a la capital sans probleme")
        typer("Arrivez à la capitale, tu vas vers le roi avec la princesse et ils sont tous contents\nune fete est organisé en ton honneur\ntout est bien qui fini bien")
    else:
        typer("tu vois que des armes dans ton inventaire donc tu décides de te battre contre ces bandits mais tu n'as pas d'experience en combot donc tu fonces directement sur eux et en voulant sortir quelque chose de ton sac, tu tombes et les bandits te tue. ")


def magasin():
    global inventaire, arme
    while True:
        arme = input ("que choisis tu de prendre ?")
        if arme =="une bague magique":
            if argent() >= 6:
                for i in range(6):
                    inventaire.remove("piece d'or")
                inventaire.extend(("une bague magique"))
                typer("voila, c'est acheté!")
            else:
                typer("tu n'as pas assez d'argent")
        elif arme == "un gros bouclier":
            if argent() >= 3:
                for i in range(3):
                    inventaire.remove("piece d'or")
                inventaire.extend(("un gros bouclier"))
                typer("voila, c'est acheté!")
            else:
                typer("tu n'as pas assez d'argent")
        elif arme == "une longue épée":
            if argent() >= 4:
                for i in range(4):
                    inventaire.remove("piece d'or")
                inventaire.append("une longue épée")
                typer("voila, c'est acheté!")
            else:
                typer("tu n'as pas assez d'argent")
        elif arme == "une cape d'invisibilité":
            if argent() >= 15:
                for i in range(15):
                    inventaire.remove("piece d'or")
                inventaire.extend(("une cape d'invisibilité"))
                typer("voila, c'est acheté!")
            else:
                typer("tu n'as pas assez d'argent")
        else:
            faute()

        if input("Voulez vous continuer vos achats ? ") == "non":
            return False

def arme_u():
    for i in inventaire:
        if i == "une cape d'invisibilité":
            return True
def arme_u():
    return "une cape d'invisibilité" in inventaire


def argent():
    p = 0
    for i in inventaire:
        if i == "piece d'or":
            p += 1
    return p

def faute():
    print(restore)
    print(erase)
    print(restore)

