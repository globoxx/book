from pgzhelper import *

TITLE = 'Mon premier platformer'

WORLD_MAP = [
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,5,0,0],
    [7,8,9,0,0,0,0,0,0,0,0,6,7,8,9],
    [0,0,0,5,0,0,0,0,0,0,0,10,0,0,0],
    [0,0,13,12,14,0,0,0,0,0,0,10,0,0,0],
    [0,0,0,11,0,0,0,0,0,0,0,10,0,0,0],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,3],
]

TILE_SIZE = 70
ROWS = len(WORLD_MAP)
COLS = len(WORLD_MAP[0])

WIDTH = COLS*TILE_SIZE
HEIGHT = ROWS*TILE_SIZE

GRAVITY = 0.3

class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        self.vie = 3
        super().__init__(image, pos, **kwargs)
        self.vy = 0
        self.speed = 3
        self.arme = None

    def update(self):
        self.vy += GRAVITY

        if keyboard.a:
            self.x -= self.speed
            self.flip_x = True
            if self.arme:
                self.arme.flip_x = True
        elif keyboard.d:
            self.x += self.speed
            self.flip_x = False
            if self.arme:
                self.arme.flip_x = False

        for platform in platforms:
            platform.check_collision_with_actor(self)

        if keyboard.w and self.vy == 0:
            self.vy = -10

        self.y += self.vy
        if self.arme:
            if keyboard.s:
                if self.arme.angle != 270:
                    self.arme.angle -= 5
                elif self.arme.angle == 270:
                    clock.schedule_interval(move_armedroite, 1.0)
                    if self.arme.angle != 270:
                        self.arme.angle += 5

        if self.collides_with(player2) and self.vie > 0 and player2.vie1 > 0:
            if self.y < player2.y:
                player2.vie1 -= 1
            elif self.y > player2.y:
                self.vie -= 1

class Player2(Actor):
    def __init__(self, image, pos, **kwargs):
        self.vie1= 3
        super().__init__(image, pos, **kwargs)
        self.vy = 0
        self.speed = 3
        self.arme = False

    def update(self):
        self.vy += GRAVITY

        if keyboard.left:
            self.x -= self.speed
            self.flip_x = True
            if self.arme:
                self.arme.flip_x = True
        elif keyboard.right:
            self.x += self.speed
            self.flip_x = False
            if self.arme:
                self.arme.flip_x = False

        for platform in platforms:
            platform.check_collision_with_actor(self)

        if keyboard.up and self.vy == 0:
            self.vy = -10

        self.y += self.vy
        if self.arme:
            if keyboard.down:
                self.arme.angle += 5


class Arme(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

    def update(self):
        if player.collides_with(self):
            player.arme = self
        if player2.collides_with(self):
            player2.arme = self


def move_armedroite():
    armes[1].angle = -90
def move_armegauche():
    armes[0].angle = -90


def load_level(world_map):
    platforms = []
    armes = []
    for row in range(ROWS):
        for col in range(COLS):
            pos = (col*TILE_SIZE+TILE_SIZE/2, row*TILE_SIZE+TILE_SIZE/2)
            if world_map[row][col] == 1:
                platform = Platform('tile_0101', pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 2:
                platform = Platform('tile_0102', pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 3:
                platform = Platform('tile_0103', pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 5:
                arme = Arme('item_sword', pos)
                armes.append(arme)
            elif world_map[row][col] == 6:
                platform = Platform('tile_0034', pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 7:
                platform = Platform('tile_0048', pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 8:
                platform = Platform('tile_0049', pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 9:
                platform = Platform('tile_0050', pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 10:
                platform = Platform('tile_0055', pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 11:
                platform = Platform('tile_0072', pos, solid=True, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 12:
                platform = Platform('tile_0012', pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 13:
                platform = Platform('tile_0014', pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 14:
                platform = Platform('tile_0015', pos, width=TILE_SIZE)
                platforms.append(platform)
    return platforms, armes

player = Player('character_roundred', (100, 100))
player2 = Player2('character_roundpurple', (950, 100))
platforms, armes = load_level(WORLD_MAP)

def draw():
    screen.blit('platformer_background',(0, 0))
    screen.draw.text("vie player 1 " +str(player.vie), (10, 30))
    screen.draw.text("vie player 2 " +str(player2.vie1), (900, 30))
    player.draw()
    player2.draw()
    for platform in platforms:
        platform.draw()
    for arme in armes:
        arme.draw()
    if player.arme:
        armes[1].x = player.x
        armes[1].y = player.y
        if keyboard.a:
            armes[1].x = player.x
            armes[1].flip_x = True
        elif keyboard.d:
            armes[1].x = player.x
            armes[1].flip_x = False
    if player2.arme:
        armes[0].x = player2.x
        armes[0].y = player2.y
        if keyboard.left:
            armes[0].x = player2.x
            armes[0].flip_x = True
        elif keyboard.right:
            armes[0].x = player2.x
            armes[0].flip_x = False
    if player.vie <= 0 :
        screen.fill('red')
        screen.draw.text("Player 2 win", (400, 300))
    elif player2.vie1 <= 0 :
        screen.fill('blue')
        screen.draw.text("Player 1 win", (400, 300))


def update():
    player.update()
    player2.update()
    for arme in armes:
        arme.update()


    remove_actors(armes)
