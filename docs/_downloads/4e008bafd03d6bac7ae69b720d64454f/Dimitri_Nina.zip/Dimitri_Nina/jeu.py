import pgzrun
from pgzhelper import *
from random import *

TITLE = 'Alien Run'
WIDTH = 1920
HEIGHT = 1080

class Player(Actor) :
    def __init__(self, image, pos, width, height,**kwargs):
        super().__init__(image, pos, width=width, height=height, **kwargs)
        self.vy = 0
        self.speed = 6
        self.vie = 3
        self.game_over = False
    def update(self):
        self.y += self.vy
        self.vy += 1
        if self.y >= 730:
            self.y = 730
            self.vy = 0

        if keyboard.space and self.y == 730:  # bug saut corrigé
            self.vy = -20
            sounds.jump.play()
        for plateforme1 in plateformes1:
            if keyboard.space and self.bottom == plateforme1.top:  # bug saut corrigé
                self.vy = -20
                sounds.jump.play()
        for plateforme2 in plateformes2:
            if keyboard.space and self.bottom == plateforme2.top:  # bug saut corrigé
                self.vy = -20
                sounds.jump.play()

        if self.vy != 0 :
            self.image = 'tile_0002'
        else :
            self.image = 'tile_0003'
        if keyboard.a:
            self.x -= self.speed
        if keyboard.d:
            self.x += self.speed

        for plateforme1 in plateformes1:
            if plateforme1.bottom-15 <= self.top <= plateforme1.bottom and plateforme1.left <= self.x <= plateforme1.right :
                self.vy = 1
        for plateforme1 in plateformes1:
            if plateforme1.top <= self.bottom <= plateforme1.top+25 and plateforme1.left <= self.x <= plateforme1.right and not keyboard.space :
                self.vy = 0
                self.bottom = plateforme1.top
        for plateforme2 in plateformes2:
            if plateforme2.bottom-15 <= self.top <= plateforme2.bottom and plateforme2.left <= self.x <= plateforme2.right :
                self.vy = 1
        for plateforme2 in plateformes2:
            if plateforme2.top <= self.bottom <= plateforme2.top+25 and plateforme2.left <= self.x <= plateforme2.right and not keyboard.space :
                self.vy = 0
                self.bottom = plateforme2.top
        for ennemy in ennemies:
            if self.collides_with(ennemy) :
                self.vie -= 1
                sounds.hit.play()
                ennemy.to_remove = True
        if self.vie == 0 :
            self.game_over = True



class Plateforme1(Actor) :
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
    def update(self) :
        self.x -= 7

class Plateforme2(Actor) :
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
    def update(self) :
        self.x -= 7

class Ennemy(Actor) :
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.direction = randint(0, 360)
        self.speed = 3
    def update(self) :
        self.x -= 7
        self.direction += randint(-10, 10)
        self.move_in_direction(self.speed)

def add_plateforme1():
    plateforme1 = Plateforme1('plateforme-1', (1920, randint(600, 700)), width=144, height=288)
    plateformes1.append(plateforme1)
    clock.schedule_unique(add_plateforme1, randint(1, 2))

def add_plateforme2():
    plateforme2 = Plateforme2('plateforme-2', (1920, randint(500, 600)), width=72, height=72)
    plateformes2.append(plateforme2)
    clock.schedule_unique(add_plateforme2, randint(1, 2))

def add_ennemy():
    ennemy = Ennemy('ennemy', (1920, randint(550, 650)), width=100, height=100)
    ennemies.append(ennemy)
    clock.schedule_unique(add_ennemy, randint(1, 2))

player = Player('tile_0003', (WIDTH/2, HEIGHT/2), 80, 80)
plateformes1 = []
plateformes2 = []
ennemies = []
clock.schedule_unique(add_plateforme1, randint(1, 2))
clock.schedule_unique(add_plateforme2, randint(1, 2)+0.5)
clock.schedule_unique(add_ennemy, randint(1, 3)+0.5)

def draw():
    if not player.game_over:
        screen.blit('fond', (0, 0))
        player.draw()
        for plateforme1 in plateformes1 :
            plateforme1.draw()
        for plateforme2 in plateformes2 :
            plateforme2.draw()
        for ennemy in ennemies:
            ennemy.draw()
        screen.draw.text(f'vie: {player.vie}', (15,10), color=(0,0,0), fontsize=100)
    if player.game_over:
        screen.fill((0, 0, 0)) #écran noir mort
        screen.draw.text('Game Over', centerx=960, centery=540, color=(255,255,255), fontsize=90)
def update():
    if not player.game_over:
        player.update()
        for plateforme1 in plateformes1 :
            plateforme1.update()
        for plateforme2 in plateformes2 :
            plateforme2.update()
        for ennemy in ennemies:
            ennemy.update()
    if keyboard.p: #relance le jeu
        player.game_over = False
        player.vie = 3
    remove_actors(ennemies)

pgzrun.go()