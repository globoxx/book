# Ecrit ton programme ici ;-)
print("hell0")
"""
pong jeu


"""
from pgzhelper import *
from random import *
TITLE = "Le jeu magique du pong"
WIDTH = 1600 #sert à la longeur de l'écran( de gauche à droite)
HEIGHT = 1000 # sert à largeur de l'écran (de haut en bas)

class Player1_pong(Actor):
    def __init__(self, image, pos, **kwargs): # Init est le constructeur de la classe
        super().__init__(image, pos, **kwargs) # Cette ligne appelle le constructeur de la classe mère Actor
        self.score1 = 0 # le score du joueur 1
        self.jeu_fini = False # variable utlisé pour le game over
    def update(self):
        if keyboard.w and self.y > 0: #sert à bouger le joueur 1
            self.y -= 5
        elif keyboard.s and self.y < 1050:
            self.y += 5
class Player2_pong(Actor):
    def __init__(self, image, pos, **kwargs): # Init est le constructeur de la classe
        super().__init__(image, pos, **kwargs) # Cette ligne appelle le constructeur de la classe mère Actor
        self.score2 = 0
        self.jeu_fini = False
    def update(self):
        if keyboard.o and self.y > 0: # sert à bouger le joueur 2
            self.y -= 5
        elif keyboard.k and self.y < 1050:
            self.y += 5
class Balle_bong(Actor):
    def __init__(self, image, pos, **kwargs): # Init est le constructeur de la classe
        super().__init__(image, pos, **kwargs) # Cette ligne appelle le constructeur de la classe mère Actor
        self.sens_balle = randint(-2,2)
        if self.sens_balle == 0: # sert au sens de la balle
            self.sens_balle = 1
        self.sens2 = randint(-2,2)
        if self.sens2 == 0:
            self.sens2 =-1
        self.speed_x = randint(5,12) * self.sens_balle

        self.speed_y = randint(2,8) * self.sens2
        self.images = ["balle","balle_2","balle_3","balle_4"] # permet de faire l'animation!

    def update(self):
        self.x += self.speed_x
        self.y += self.speed_y


        if self.x < 125  and (player1.y-250) <self.y and  (player1.y + 250) > self.y : # sert à faire les collisions avec le joueur 1 et 2
                self.speed_x = -self.speed_x
        if self.x > 1475  and (player2.y-250) <self.y and  (player2.y + 250) > self.y:
            self.speed_x = -self.speed_x

            print(self.speed_x)
        if self.y < 0 or self.y > HEIGHT:
            self.speed_y = -self.speed_y
            print(self.speed_y)
        for Balle in Les_balles: # sert à l'ajout de score
            if self.x < 0:
                player2.score2 += 1
                Les_balles.remove(Balle)
                self.sens_balle = -1
                self.add_balle()
            if self.x > WIDTH:
                player1.score1 += 1
                Les_balles.remove(Balle)
                self.sens_balle = 1
                self.add_balle()
        for ultime_balle in Ultime_balle: # gère les collisions avec les objets des diffèrents joueurs
            if self.collides_with(ultime_balle):
                sounds.explosion.play() # ajout du bruit
                self.speed_x = -self.speed_x
                ultime_balle.to_remove = True # enleve la balle ultime
        for ultime_balle1 in Ultime_balle1:
            if self.collides_with(ultime_balle1):
                sounds.explosion.play() # ajout du bruit
                self.speed_x = -self.speed_x
                ultime_balle1.to_remove = True # enleve la balle ultime
        for balle_protection in Balle_protection:
            if self.collides_with(balle_protection):
                sounds.explosion.play() # ajout du bruit
                self.speed_x = -self.speed_x
                balle_protection.to_remove = True # enleve la balle de protection
        for balle_protection in Balle_protection1:
            if self.collides_with(balle_protection):
                sounds.explosion.play() # ajout du bruit
                self.speed_x = -self.speed_x
                balle_protection.to_remove = True # enleve la balle de protection

    def add_balle(self): # ajout une balle
        balle_pong = Balle_bong("balle", (WIDTH/2, HEIGHT/2))
        Les_balles.append(balle_pong)
class Ultime_ball(Actor):
    def __init__(self,image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = randint(10,20)
        self.direction = 0
    def update(self):
        for Balle_ in Les_balles:
            self.direction = self.angle_to((Balle_.x, Balle_.y))  # permet de se diriger vers la balle
            self.move_in_direction(self.speed)
class Ball_protection(Actor):
    def __init__(self,image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = randint(4,5)
        self.direction = 0
    def update(self):
        for Balle_ in Les_balles:
            self.direction = self.angle_to((Balle_.x, Balle_.y)) # permet de se diriger vers la balle
            self.move_in_direction(self.speed)
def Ultime_ball_add(): # ajout les objets du joueur 2
    balle_ultime1 = Ultime_ball("ultimeball",(1400, player2.y))
    Ultime_balle.append(balle_ultime1)
def Balle_protection_add():
    balle_protection = Ball_protection("balle_protection",(1400, player2.y))
    Balle_protection.append(balle_protection)
def Ultime_ball1_add(): # ajout les objets du joueur 1
    balle_ultime1 = Ultime_ball("ultimball1",(150, player1.y))
    Ultime_balle1.append(balle_ultime1)
def Balle_protection1_add():
    balle_protection = Ball_protection("balle_protection1",(150, player1.y))
    Balle_protection1.append(balle_protection)
player1 = Player1_pong("player1",(-150,500))
player2 = Player2_pong("player1",(1750,500))
music.play("adventure") # ajoute la musique
Ultime_balle = []
Ultime_balle1 = []
Balle_protection = []
Balle_protection1 = []


clock.schedule_interval(Balle_protection_add, 5.0) # fait apparaitre une balle de protection pour le joueur 1 tous les x secondes
clock.schedule_interval(Balle_protection1_add, 5.0) # fait apparaitre un balle de protection pour le joueur 2 tous les x secondes

balle_pong = Balle_bong("balle", (WIDTH/2, HEIGHT/2))
Les_balles = []
Les_balles.append(balle_pong)
Jeu_fin = False

def draw():
    screen.blit("image38",(0,0))
    screen.draw.text(f"le score incroyable du joueur 1 : {player1.score1}", (20,0)) # dessine le score du joueur 1
    screen.draw.text(f"le score incroyable du joueur 2 : {player2.score2}", (1300,0)) # dessine le score du joueur 2
    if player1.score1 >20 and player2.jeu_fini == False: # gère le game over
        screen.clear()
        screen.draw.text("Le jeu est fini et le joueur 1 est le vainqueur", (WIDTH/2 - 250, HEIGHT/2),fontsize=48) # écrit que le joueur 1 a gagné
        player1.jeu_fini = True
    if player2.score2 >20 and player1.jeu_fini == False:
        screen.clear()
        screen.draw.text("Le jeu est fini et le joueur 2 est le vainqueur", (WIDTH/2 - 250, HEIGHT/2), fontsize=48) # écrit que le joueur 2 a gagné
        player2.jeu_fini = True


    player1.draw()
    player2.draw()
    for Balle in Les_balles: # dessine les diffèrents objets
        Balle.draw()
        Balle.animate()
    for ultimeballe in Ultime_balle:
        ultimeballe.draw()
    for ultime_balle1 in Ultime_balle1:
        ultime_balle1.draw()
    for balle_protection in Balle_protection:
        balle_protection.draw()
    for balle_protection in Balle_protection1:
        balle_protection.draw()
def update():
    player1.update()
    player2.update()
    for Balle in Les_balles:
        Balle.update()
    for ultimeballe in Ultime_balle: # update les diffèrents objets
        ultimeballe.update()
    for ultime_balle1 in Ultime_balle1:
        ultime_balle1.update()
    for balle_protection in Balle_protection:
        balle_protection.update()
    for balle_protection in Balle_protection1:
        balle_protection.update()
    if keyboard.m:
        Ultime_ball_add()
    if keyboard.x:
        Ultime_ball1_add()
    if len(Ultime_balle1) > 1 : # gère le nombre d'ultime balle dans le jeu
       del Ultime_balle1[1]
    if len(Ultime_balle) > 1 :
       del Ultime_balle[1]
    if len(Balle_protection1) > 5 : # gère le nombre de balle de protection dans le jeu
       del Balle_protection1[1]
    if len(Balle_protection) > 5 :
       del Balle_protection[1]
    remove_actors(Ultime_balle) # enleve les diffèrents objets lors des collisions
    remove_actors(Ultime_balle1)
    remove_actors(Balle_protection)
    remove_actors(Balle_protection1)
