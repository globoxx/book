import random
import time
import os
from ascii_magic import AsciiArt
import pickle
import shutil

default_writing_speed = 0
unlocked_places = ["lobby"]
start_money_bonus = 0
lobby_done = False
plains_done = False
village_done = False

gameLoadedFromSave = False
gameIsRunning = False

class Personnage:
    def __init__(self, nom, player=False):
        self.nom = nom
        self.vie = 100
        self.inventaire = []
        self.argent = 100 + start_money_bonus
        self.level = 1
        self.player = False
        if player == True:
            self.player = True
            self.inventaire.append(Arme("poings", 20, 0, "main"))
            self.argent = 0

    def isInInventory(self, objet):
        if objet in self.inventaire:
            return True
        else:
            return False
        
    def attack(self, enemy, stage_story, weapon, enemy_shield, multiplicator_damage=1):
        chance = random.randint(0, 10)
        if chance >= (1/(self.level/5)):
            damage = (weapon.degats * self.level + weapon.degats_bonus) * multiplicator_damage

            if enemy_shield is not None:
                damage -= enemy_shield.degats_bonus

            enemy.vie -= damage

            if self.player:
                player_attack_options = ["player_attack1", "player_attack2", "player_attack3"]
                chosen_player_attack = random.choice(player_attack_options)
                player_attack = f"{stage_story.description_attack[chosen_player_attack]}"
                print(player_attack.format(damage=damage, self=self, enemy=enemy))

                if enemy_shield is not None and enemy_shield.degats_bonus != 0:
                    enemy_parry_shield_options = ["enemy_parry_shield1", "enemy_parry_shield2", "enemy_parry_shield3"]
                    chosen_enemy_parry_shield = random.choice(enemy_parry_shield_options)
                    enemy_parry_shield = f"{stage_story.description_attack[chosen_enemy_parry_shield]}"
                    print(enemy_parry_shield.format(damage=damage, self=self, enemy=enemy, enemy_shield=enemy_shield))

            else:
                enemy_attack_options = ["enemy_attack1", "enemy_attack2", "enemy_attack3"]
                chosen_enemy_attack = random.choice(enemy_attack_options)
                enemy_attack = f"{stage_story.description_attack[chosen_enemy_attack]}"
                print(enemy_attack.format(damage=damage, self=self, enemy=enemy))

                if enemy_shield is not None and enemy_shield.degats_bonus != 0:
                    player_parry_shield_options = ["player_parry_shield1", "player_parry_shield2", "player_parry_shield3"]
                    chosen_player_parry_shield = random.choice(player_parry_shield_options)
                    player_parry_shield = f"{stage_story.description_attack[chosen_player_parry_shield]}"
                    print(player_parry_shield.format(damage=damage, self=self, enemy=enemy, enemy_shield=enemy_shield))

        else:
            if self.player:
                player_attack_lost_options = ["player_attack_lost1", "player_attack_lost2", "player_attack_lost3"]
                chosen_player_attack_lost = random.choice(player_attack_lost_options)
                player_attack_lost = f"{stage_story.description_attack[chosen_player_attack_lost]}"
                print(player_attack_lost.format(self=self, enemy=enemy))
            else:
                enemy_attack_lost_options = ["enemy_attack_lost1", "enemy_attack_lost2", "enemy_attack_lost3"]
                chosen_enemy_attack_lost = random.choice(enemy_attack_lost_options)
                enemy_attack_lost = f"{stage_story.description_attack[chosen_enemy_attack_lost]}"
                print(enemy_attack_lost.format(self=self, enemy=enemy))

    def acheter(self, stage_story, objet):
        if self.argent >= objet.prix:
            self.argent -= objet.prix
            self.inventaire.append(objet)
            writing_machine(stage_story.purchase_description[objet.nom])
        else:
            writing_machine(stage_story.purchase_description[f"{objet.nom}-not_enough_money"])
    
    def fuir(self, ennemi, stage_story, enemy_weapon, enemy_shield):
        chance = random.randint(0, 10)
        if chance > 1/(self.level/5):
            return True
        else:
            ennemi.attack(self, stage_story, enemy_weapon, enemy_shield, 1/2)
            if self.vie <= 0:
                return False
            return True
    
    def consume(self, objet, consume_description):
        if isinstance(objet, Objet) in self.inventaire and objet.type == "soin":
            self.vie += objet.vie
            self.inventaire.remove(objet)
            writing_machine(consume_description[objet.nom])

    def give(self, to_who, object, trading_description):
        self.inventaire.remove(object)
        to_who.inventaire.append(object)
        writing_machine(trading_description[object.nom])
        return True

class Arme:
    def __init__(self, nom, degats, degats_bonus, type="weapon", prix=0):
        self.nom = nom
        self.degats = degats
        self.degats_bonus = degats_bonus
        self.prix = prix
        self.type = type

    def show_attribute(self):
        return f"{self.nom}, {self.degats}, {self.degats_bonus}, {self.type}"

class Objet:
    def __init__(self, nom, prix, type, vie, useable_number):
        self.nom = nom
        self.prix = prix
        self.vie = vie
        self.type = type
        self.useable = useable_number

class story:
    class menu:
        def main():
            global gameIsRunning,gameLoadedFromSave, player
            
            if not gameLoadedFromSave:
                if not gameIsRunning:
                    image = AsciiArt.from_image("startimg.png")
                    image.to_terminal(150, 2)
                    choice = ""
                    while choice not in ["commencer", "options", "charger", "crédits", "quitter"]:
                        choice = my_input("Fallen Valor: Flames of Destiny\n\n\n ⚔️ Commencer l'Aventure (commencer):\n     Lancez-vous dans une quête épique pour restaurer votre honneur.\n\n ⚔️ Continuer la Quête (charger):\n      Revenez là où votre dernier combat vous a laissé.\n\n ⚔️ Options (options):\n      Ajustez les paramètres d'écriture pour une expérience personnalisée.\n\n ⚔️ Crédits (crédits):\n     Découvrez ceux qui ont donné vie à ce monde fantastique.\n\n ⚔️ Quitter (quitter): Mettez fin à votre voyage... pour l'instant.\n\n\nP.S. Nous vous conseillons si vous commencer le jeu de régler votre vitesse d'écriture.")
                else:
                    choice = ""
                    while choice not in ["continuer", "options", "sauvegarder", "crédits", "quitter"]:
                        choice = my_input("Fallen Valor: Flames of Destiny\n\n\n ⚔️ Continuer l'Aventure (continuer)\n\n ⚔️ Sauvegarder la Quête (sauvegarder)\n\n ⚔️ Options (options)\n\n ⚔️ Crédits (crédits)\n\n ⚔️ Quitter (quitter)")

                    if choice == "continuer":
                        writing_machine("On est repartis !")

                    elif choice == "sauvegarder":
                        story.menu.sauvegarder()

                    elif choice == "options":
                        choose_writing_speed()
                        story.menu.main()
                        
                    elif choice == "crédits":
                        choix = story.menu.credits()
                        while not (choix == "quitter"):
                            choix = story.menu.credits()
                        story.menu.main()
                    elif choice == "quitter":
                        story.menu.fermer()
            else:
                choice = "commencer"

            if choice == "commencer":
                gameIsRunning = True
                next_place = askForNextPlace()
                while next_place != "fin de l'histoire":
                    if next_place == "lobby" and next_place in unlocked_places:
                        story.lobby.main()
                        if "prairie" not in unlocked_places:
                            unlocked_places.append("prairie")
                        next_place = askForNextPlace()

                    elif next_place == "prairie" and next_place in unlocked_places:
                        story.plains.main()
                        if "village" not in unlocked_places:
                            unlocked_places.append("village")
                        next_place = askForNextPlace()

                    elif next_place == "village" and next_place in unlocked_places:
                        story.village.main()

                        if "forêt profonde" not in unlocked_places:
                            unlocked_places.append("forêt profonde")
                        next_place = askForNextPlace()

                    elif next_place == "forêt profonde" and next_place in unlocked_places:
                        story.dark_forest.main()

                        if "tour solitaire" not in unlocked_places:
                            unlocked_places.append("tour solitaire")
                        next_place = askForNextPlace()
                    elif next_place == "tour solitaire" and next_place in unlocked_places:
                        story.spy_tower.main()

                        if "donjon" not in unlocked_places:
                            unlocked_places.append("donjon")
                        next_place = askForNextPlace()
                    elif next_place == "donjon" and next_place in unlocked_places:
                        story.dunjeon.main()

                        if "château" not in unlocked_places:
                            unlocked_places.append("château")
                        next_place = askForNextPlace()
                    elif next_place == "château" and next_place in unlocked_places:
                        story.castle.main()

                        if "dragon" not in unlocked_places:
                            unlocked_places.append("dragon")
                        next_place = askForNextPlace()
                    elif next_place == "dragon" and next_place in unlocked_places:
                        story.dragon.main()
                    else:
                        writing_machine("Tu n'as malheureusement pas encore accès à cet endroit. Choisi la destination qui suit celle où tu te trouves ou alors, une que tu as déjà visité.")
                        next_place = askForNextPlace()
                story.end_of_story()
            elif choice == "charger":
                story.menu.charger()
            elif choice == "options":
                choose_writing_speed()
                story.menu.main()
            elif choice == "crédits":
                choix = story.menu.credits()
                while not (choix == "quitter" or choix == "les plus beaux"):
                    choix = story.menu.credits()
                if choix == "les plus beaux":
                    if "player" not in locals():
                        player = Personnage(askForName(), player=True)
                    player.argent += 1000
                    while my_input(f"Merci nous sommes flattés ;), tu es donc récompensé de 1000 pièces.(quitter)") != "quitter":
                        pass
                story.menu.main()
            elif choice == "fermer":
                story.menu.fermer()
            
        def sauvegarder():
            global player, default_writing_speed, unlocked_places, start_money_bonus, lobby_done, plains_done, village_done
            data = {
                "player": {
                    "nom": player.nom,
                    "vie": player.vie,
                    "argent": player.argent,
                    "level": player.level
                },
                "unlocked_places": unlocked_places,
                "writing_speed": default_writing_speed,
                "start_money_bonus": start_money_bonus,
                "lobby_done": lobby_done,
                "plains_done": plains_done,
                "village_done": village_done
            }
            sauvegarde_name = f"{player.nom}" + ".pickle"
            with open(sauvegarde_name, "wb") as fichier:
                pickle.dump(data, fichier)            

        def lister_fichiers_sauvegarde():
            fichiers_sauvegarde = [fichier for fichier in os.listdir() if fichier.endswith('.pickle')]
            return fichiers_sauvegarde

        def charger():
            global player, default_writing_speed, unlocked_places, start_money_bonus, lobby_done, plains_done, village_done, gameLoadedFromSave
            fichiers_sauvegarde = story.menu.lister_fichiers_sauvegarde()
            nom_fichier_short = []
            for i in fichiers_sauvegarde:
                pos_virgule = i.find(".")
                i = i[:pos_virgule]
                nom_fichier_short.append(i)
            if fichiers_sauvegarde:
                writing_machine("Fichiers de sauvegarde disponibles :")
                for fichier in fichiers_sauvegarde:
                    writing_machine(f"  {fichier}")
                nom = my_input("Quel était votre nom lors de votre précédente partie ?")
                while nom not in nom_fichier_short or nom != "quitter":
                    if nom != "quitter":
                        sauvegarde_name = f"{nom}.pickle"
                        while sauvegarde_name not in fichiers_sauvegarde:
                            if sauvegarde_name in fichiers_sauvegarde:
                                try:
                                    with open(sauvegarde_name, "rb") as fichier:
                                        data = pickle.load(fichier)
                                        if "player" not in locals():
                                            player = Personnage("", player=True)
                                        player.nom = data["player"]["nom"]
                                        player.vie = data["player"]["vie"]
                                        player.argent = data["player"]["argent"]
                                        player.level = data["player"]["level"]
                                        unlocked_places = data["unlocked_places"]
                                        default_writing_speed = data["writing_speed"]
                                        start_money_bonus = data["start_money_bonus"]
                                        lobby_done = data["lobby_done"]
                                        plains_done = data["plains_done"]
                                        village_done = data["village_done"]
                                        print("Chargement réussi !")
                                        gameLoadedFromSave = True
                                        story.menu.main()
                                except FileNotFoundError:
                                    writing_machine("Erreur lors du chargement du fichier de sauvegarde.")
                            else:
                                writing_machine("Le fichier de sauvegarde spécifié n'existe pas.")
                    else:
                        story.menu.main() 
            else:
                writing_machine("Aucun fichier de sauvegarde trouvé.")
                story.menu.main()

        def fermer():
            exit()

        def credits():
            choice = my_input("Dans les tréfonds de l'univers de Fallen Valor: Flames of Destiny, ce script prend vie grâce au rigoureux travail d'Arthur Frésard et Nathan Combes, ayant tissé les fils de l'aventure avec habileté et détermination.\n(quitter)")
            return choice
    
    class lobby:   #début de l'histoire
        def main():
            global player, lobby_done
            if lobby_done == False:
                writing_machine("La nuit avait été longue, sans rêves ni cauchemars pour interrompre le sommeil. Tu ouvris les yeux à l'aube, étourdi par la lumière qui émanait du ciel gris. Tu te trouvais au milieu d'un champ immense, sans savoir comment ni pourquoi tu t'y trouvais.\n\nTes habits étaient ceux d'un paysan, dépourvus de tout ornement ou marque distinctive. Rien dans tes poches, aucun indice qui puisse éclairer ta mémoire amnésique. Seul ton esprit était alerte, oscillant entre l'inquiétude et la curiosité.\n\nLe champ qui s'étendait devant toi était vaste et silencieux, baigné dans la brume qui flottait encore dans l'air. Les herbes hautes ondulaient doucement sous la brise matinale, et la terre humide sous tes pieds te rappelait la fraîcheur de la nuit passée.\n\nTu n'avais pas de destination précise en tête, aucun but à atteindre. Tu t'enfonças dans le champ, ignorant le chemin qui s'étendait devant toi. Tu marchais lentement, observant les détails autour de toi. Le vol des oiseaux, le bruit des insectes, le mouvement des nuages dans le ciel.\n\nC'était une sensation étrange, d'être ici sans souvenirs ni repères. Mais tu ne ressentais ni peur ni panique. Il y avait une certaine paix dans cette amnésie, une liberté qui te permettait de voir le monde sans les entraves du passé.\n\nTu te fondais dans le paysage, devenant un élément parmi tant d'autres. Les heures passèrent, le soleil monta dans le ciel, et tu continuas d'avancer, sans but ni destination. Tu étais là, simplement, et cela te suffisait.")
                if "player" not in locals():
                    player = Personnage(askForName(), player=True)
            else:
                writing_machine("Le champ qui s'étend devant toi t'es familier. Il est grand et t’enivre de ces bonnes odeurs de printemps. Après quelques pas, tu te retrouves face à l'endroit où tu t'est réveillé : le carrefour de ton aventure...") 
            lobby_done = True
                
    class plains:
        def main():
            global sword_taken, plains_done, bonshommes_pailles
            if "sword_taken" not in locals():
                sword_taken = False
            else:
                sword_taken = True
            restart = 0
            bonshommes_pailles = 6
            if 0 < restart:
                player.vie = 100
            else:
                épée_rouillée = Arme("épée rouillée", 5, 60, "sword")
            if plains_done == False:
                choice = story.plains.intro()
            else:
                choice = story.plains.intro_2()
            while True:
                if choice == "w" and sword_taken == False:
                    choice = story.plains.sword_way()
                    state = False
                    if choice == "a":
                        story.plains.pull_sword()
                        if restart > 0:
                            player.level += 1
                        if épée_rouillée not in player.inventaire:
                            sword_taken = True
                            player.inventaire.append(épée_rouillée)
                        state = True
                    elif choice == "d":
                        story.plains.shoot_sword()
                        if 0 < restart:
                            player.level += 2
                        if épée_rouillée not in player.inventaire:
                            sword_taken = True
                            player.inventaire.append(épée_rouillée)
                        state = True
                    if state == True:
                        choice = "d"
                elif choice == "w" and plains_done == True:
                    choice = story.plains.sword_way_2()
                    if choice == "s":
                        break
                    elif choice == "d":
                        choice = "d"
                elif choice == "d":
                    if épée_rouillée in player.inventaire:
                        while bonshommes_pailles != 0:
                            scarecrow = Personnage("Bonhomme de paille")
                            scarecrow.level = 2
                            stick = Arme("bâton", 10, 0, "weapon", 20)
                            scarecrow.inventaire.append(stick)
                            issue = fight(player, scarecrow, story.plains.fight_scarecrow)
                            if issue:
                                bonshommes_pailles -= 1
                                choice = story.plains.fight_scarecrow.go_to_next_one_question()
                                if choice == "s":
                                    break
                                elif choice == "w":
                                    story.plains.fight_scarecrow.next_one() 
                            else:
                                restart += 1
                                story.plains.main()
                        choice = story.plains.fight_scarecrow.end()
                        if choice == "s":
                            story.plains.wait_before_end()
                            restart = 0
                            plains_done = True
                            break                
                        elif choice == "w":
                            story.plains.end()
                            player.level += 1
                            restart = 0
                            plains_done = True
                            break
                    elif épée_rouillée not in player.inventaire:
                        story.plains.sword_not_in_inventory()
                        choice = "w"
        def intro():
            choice = my_input(f"Alors que tes pas te menaient à travers la prairie paisible, au cœur de l'épais manteau de verdure qui caractérise cette contrée médiévale, se dresse une prairie d'une beauté envoûtante, telle une toile peinte par les doigts habiles de la nature elle-même. L'air y est empreint d'une douce fraîcheur, un souffle léger caressant les feuilles des arbres majestueux qui se dressent fièrement à l'horizon.\n\nAu centre de cette clairière, telle une relique oubliée par le temps, gît une épée rouillée, plantée vaillamment dans le sol meuble. Son tranchant émoussé témoigne des combats passés, des récits épiques qui ont marqué cette terre depuis des générations. À ses côtés, disposés en un cercle étrange, se dressent {bonshommes_pailles} bonshommes de paille, coiffés de casques usés par le temps. Leurs visages inexpressifs scrutent l'horizon, gardiens muets d'un mystère millénaire.\n\nAu-delà de ce tableau énigmatique, s'étend une forêt luxuriante, ses arbres majestueux semblant murmurer des secrets anciens à ceux qui osent les écouter. Leurs feuillages touffus filtrent la lumière du soleil, créant des jeux d'ombres et de lumières qui dansent sur le sol fertile.\n\nLe champ qui s'étend autour de cette scène semble être le théâtre d'une moisson récente. Des épis de blé mûrs se dressent fièrement, prêts à être récoltés, tandis qu'une portion de la récolte a été rassemblée en un cercle parfait, laissant une empreinte énigmatique sur la terre nourricière.\n\nTel est le spectacle qui se dévoile à toi, voyageur égaré dans le temps, témoin silencieux d'une époque révolue. Tu contemples cette scène avec émerveillement et respect, car en ces lieux, le passé et le présent se mêlent dans une danse intemporelle, évoquant les légendes et les mystères d'une époque oubliée.\n\nSouhaitez-vous plutôt cheminer en direction de l'épée oubliée (w) ou bien prendre le temps d'examiner les bonshommes de paille (d) ?")
            return choice
        
        def intro_2():
            choice = my_input(f"Alors que tes pas te menaient à travers la prairie paisible, au cœur de l'épais manteau de verdure qui caractérise cette contrée médiévale, se dresse une prairie d'une beauté envoûtante, telle une toile peinte par les doigts habiles de la nature elle-même. L'air y est empreint d'une douce fraîcheur, un souffle léger caressant les feuilles des arbres majestueux qui se dressent fièrement à l'horizon.\n\nAu milieu de cette clairière se trouve un trou, de la taille et de la profondeur d'une épée qui y était autrefois enfoncée. À son côtés, disposés en un cercle étrange, se dressent {bonshommes_pailles} bonshommes de paille, coiffés de casques usés par le temps. Leurs visages inexpressifs scrutent l'horizon, gardiens muets d'un mystère millénaire.\n\nAu-delà de ce tableau énigmatique, s'étend une forêt luxuriante, ses arbres majestueux semblant murmurer des secrets anciens à ceux qui osent les écouter. Leurs feuillages touffus filtrent la lumière du soleil, créant des jeux d'ombres et de lumières qui dansent sur le sol fertile.\n\nLe champ qui s'étend autour de cette scène semble être le théâtre d'une moisson récente. Des épis de blé mûrs se dressent fièrement, prêts à être récoltés, tandis qu'une portion de la récolte a été rassemblée en un cercle parfait, laissant une empreinte énigmatique sur la terre nourricière.\n\nTel est le spectacle qui se dévoile à toi, voyageur égaré dans le temps, témoin silencieux d'une époque révolue. Tu contemples cette scène avec émerveillement et respect, car en ces lieux, le passé et le présent se mêlent dans une danse intemporelle, évoquant les légendes et les mystères d'une époque oubliée.\n\nSouhaitez-vous plutôt cheminer en direction du trou (w) ou bien prendre la direction des bonshommes de paille (d) ?")
            return choice
        def sword_way():
            choice = my_input("Tu t'engages donc sur le chemin de l'épée, tel un chevalier en quête de gloire, suivant la voie tracée par les légendes anciennes.\nLorsque tu te tiens face à elle, deux voies se dévoilent devant toi : tu peux soit t'efforcer avec bravoure de libérer l'épée de son enracinement terrestre en la tirant de toutes tes forces (a), soit lui administrer un coup de pied vigoureux pour la déloger de sa place (d). ")
            return choice
        
        def sword_way_2():
            choice = my_input("Il n'y a qu'un petit trou.\n\nVeux-tu aller en découdre avec les bonshommes (d) ou repartir (s) ?")
            return choice

        def pull_sword():
            writing_machine("En délogeant vaillamment l'épée, tu ressens une montée d'adrénaline et une vague de force te traverse. Avec grâce, tu fais montre de tes muscles, et tu sens que tu as atteint un nouveau niveau de puissance. Dans un élan de triomphe, tu t'appropries également l'épée, désormais un prolongement de ta nouvelle puissance.")

        def shoot_sword():
            writing_machine("D'un coup de pied droit asséné avec toute ta puissance, tu fais sortir l'épée de son repos tel un cure-dent de sa boîte. Dans ce moment d'exploit, tu ressens une puissance décuplée, comme si tu avais franchi un seuil inattendu. Avec une montée non pas d'un, mais de deux niveaux, tu t'appropries également l'épée, témoin silencieux de ta nouvelle force.")
        
        def scarecrow():
            writing_machine("Tu te diriges vers les bonshommes de paille avec une curiosité teintée d'intrigue. Les silhouettes rudimentaires semblent attendre, silencieuses et immobiles, offrant une énigme à déchiffrer.")
        
        def sword_not_in_inventory():
            writing_machine("Après un moment de contemplation devant les bonshommes de paille, tu laisses glisser ta main sur leur surface, ressentant leur texture rugueuse sous tes doigts. Intrigué par ce contact éphémère, tu te retournes ensuite vers l'épée, interpellé par son appel silencieux, prêt à poursuivre ton exploration des mystères qui t'entourent.")

        class fight_scarecrow():
            description = {
                "introduction/choice": "Tu te tiens devant le bonhomme de paille, l'observant attentivement, évaluant silencieusement la situation. Une question se forme dans ton esprit : dois-tu choisir de te battre vaillamment, ou bien opter pour une retraite stratégique, restant ainsi hors d'atteinte au cas où ?",
                "choice": "Dans le tourbillon incessant du combat contre les simulacres de paille, une interrogation récurrente t'assaillira : attaquer (w), prendre la fuite (s), ou puiser dans tes réserves de potions (e) pour vaincre les défis à venir ?",
                "bad_input": "Il t'est impossible d'entreprendre une autre action ! Distrait par ta tentative d'invoquer un portail tridimensionnel, tu te fais surprendre par un coup. w ou s ou e, il faut choisir !\n",
                "flee_ok": "Dans l'ardente mêlée, une opportunité fugace se dessine. D'un mouvement vif et calculé, tu glisses entre les assauts des ennemis, échappant à leurs griffes avides. Ta silhouette se fond dans l'ombre, une ombre fugace dans le tumulte de la bataille. À chaque pas, tu te rapproches davantage de la lisière de la forêt, ta retraite assurée par la discrétion et la vitesse. En un instant, tu disparais dans les ténèbres de la canopée, laissant derrière toi les bruits du combat et la confusion de tes adversaires.",
                "flee_lost": "Dans une tentative désespérée de fuite, tes pas s'égarent dans le chaos de la bataille, mais tes adversaires vigilants anticipent ton mouvement. Alors que tu tentes de te dérober, un coup soudain s'abat sur toi, brisant ton élan et t'arrachant un cri de douleur. Ton échec dans la fuite ne fait que renforcer la détermination de tes ennemis, et tu te retrouves une fois de plus plongé dans l'âpre lutte qui fait rage autour de toi.",
                "time_to_drink_num": "6",
                "time_to_drink": "Dans un bref répit entre les assauts ennemis, tu distingues une opportunité fugace de récupérer tes forces. Avec un temps limité de six secondes avant la prochaine salve d'attaques, tu saisis avec empressement une de tes potions, espérant qu'elle te fournira la vitalité nécessaire pour survivre au carnage imminent.",
                "time_to_drink_lost": "Tu te prépares à affronter le prochain assaut, sachant qu'il te reste {time_lost} secondes avant que la violence de la bataille ne s'abatte à nouveau sur toi.\n",
                "drink_ok": "Dans un moment de tension palpable, tu saisis l'opportunité de boire la potion salvatrice. Tes mains tremblantes rencontrent le flacon, et d'un geste précis, tu l'ouvres et portes le liquide à tes lèvres assoiffées. Une fois ingéré, une sensation de vigueur et de revitalisation envahit chaque fibre de ton être, dissipant la fatigue et ravivant ton courage. Tu te sens prêt à affronter les défis à venir, armé de nouvelles forces puisées dans les profondeurs mystiques de la potion.",
                "enemy_weak": "L'adversaire, autrefois imposant et intimidant, montre maintenant des signes de faiblesse. Sa posture chancelante trahit une vigueur diminuée, ses mouvements moins assurés. Les regards de ses comparses expriment l'inquiétude alors que la confiance émane de tes rangs. C'est le moment opportun pour porter l'estocade finale, pour achever ce combat avec détermination et triomphe.",
                "player_injured": "Seul, blessé et épuisé, tu luttes contre les forces qui t'entourent. Chaque mouvement est un défi, chaque souffle est un effort. Malgré la solitude qui t'enserre, une détermination farouche brûle en toi, alimentant ton courage dans l'obscurité de la bataille. Tes yeux fixent l'horizon avec une résolution inébranlable, prêts à affronter tout ce que le destin te réserve.",
                "player_dead": "Seul, vaincu et épuisé, tu gis sur le sol de la bataille, entouré par le silence oppressant de la défaite. Les ombres de la nuit s'étendent autour de toi, témoins silencieux de ton isolement. Malgré la solitude qui t'enserre, un dernier souffle de détermination persiste en toi, une flamme vacillante dans les ténèbres de la défaite, prête à s'enflammer à nouveau lorsque viendra l'aube d'un nouveau jour.",
                "enemy_dead": "Les bonshommes de paille, jadis rigides et menaçants, gisent désormais en désordre sur le sol, leurs membres inanimés dispersés dans la poussière. Leurs formes autrefois menaçantes sont désormais tordues et déformées, témoins muets de leur défaite inéluctable. Malgré leur aspect fragile, ils ont été vaincus, leur menace réduite à néant par la force implacable de ta détermination.",
                "money_reward": "Dans un ultime acte de récupération, tu fouilles les poches de ton ennemi vaincu et tu mets la main sur l'argent qu'il transportait. Une fois en ta possession, tu observes le montant avec satisfaction. Tu compte {gain_argent}. Après un rapide calcul tu sais que tu possède actuellement {player.argent}Témoignage tangible de ta victoire sur ce champ de bataille."
            }
            description_attack = {
                "player_attack1": "D'un geste puissant, ton bras descend avec force sur la paille du mannequin, lui infligeant {damage} de dégâts. Désormais, le mannequin affiche {enemy.vie}.",
                "player_attack2": "Avec une énergie fulgurante, ton bras s'abat violemment sur la paille du bonhomme, lui occasionnant {damage} de dégâts. Le bonhomme ne conserve désormais que {enemy.vie} pour résister.",
                "player_attack3": "D'un mouvement déterminé, ton bras frappe avec puissance la paille du pantin, lui infligeant {damage} de dégâts. Désormais, le pantin ne possède plus que {enemy.vie} pour survivre.",
                "enemy_attack1": "Soudainement, le bonhomme de paille se tourne vers toi et libère une tempête violente qui te heurte, infligeant {damage} points de dégâts. Ta santé est maintenant réduite à {enemy.vie} points de vie.",
                "enemy_attack2": "Le bonhomme de paille pivote brusquement et déchaîne une rafale impitoyable qui te frappe de plein fouet, causant {damage} points de dégâts. Il ne te reste plus que {enemy.vie} points de vie.",
                "enemy_attack3": "En un instant, le bonhomme de paille se retourne et lance une bourrasque puissante qui te percute, te faisant subir {damage} points de dégâts. Tu n'as plus que {enemy.vie} points de vie restants.",
                "player_attack_lost1": "D'un geste théâtral, ton bras s'abat avec une force titanesque sur la paille du mannequin. Hélas, ton coup, bien que puissant, ne parvient pas à atteindre sa cible. Le mannequin, imperturbable, demeure intact et affiche toujours {enemy.vie}.",
                "player_attack_lost2": "Avec une énergie débordante, ton bras se lance dans une danse furieuse, visant la paille du bonhomme. Malheureusement, ton attaque, bien que spectaculaire, échoue. Le bonhomme, insensible à ta fureur, reste indemne et conserve toujours {enemy.vie} pour résister.",
                "player_attack_lost3": "D'un mouvement résolu, ton bras tente de frapper la paille du pantin. Mais ton coup, malgré sa détermination, manque sa cible. Le pantin, impassible face à ton assaut, reste intact et possède toujours {enemy.vie} pour survivre.",
                "enemy_attack_lost1": "Soudainement, le bonhomme de paille se tourne vers toi et tente de libérer une tempête violente. Mais son attaque, bien que terrifiante, échoue. Ta santé, malgré la menace, reste intacte et est toujours à {enemy.vie} points de vie.",
                "enemy_attack_lost2": "Le bonhomme de paille pivote brusquement et tente de déchaîner une rafale impitoyable. Mais son attaque, bien que redoutable, ne parvient pas à te toucher. Tu restes indemne, comme un roc face à la tempête, et il te reste toujours {enemy.vie} points de vie.",
                "enemy_attack_lost3": "En un instant, le bonhomme de paille se retourne et tente de lancer une bourrasque puissante. Mais son attaque, bien que féroce, échoue. Tu n'as subi aucun dégât et tu as toujours {enemy.vie} points de vie restants.",
                "player_parry_shield1": "Tel un maître escrimeur, le joueur pare l'attaque de l'ennemi avec un mouvement fluide de son bouclier, déviant habilement le coup imminent. Cependant, grâce à sa maîtrise, il ne subit que {damage} dégâts, son bouclier bénéficiant d'un bonus de défense de {enemy_shield.degats_bonus}.",
                "player_parry_shield2": "Le joueur anticipe avec agilité l'assaut de l'adversaire, brandissant son bouclier juste à temps pour contrer l'attaque, créant ainsi une impressionnante danse de défense et de riposte. Malgré la force de l'impact, il ne subit que {damage} dégâts, son bouclier se révélant être un rempart fiable grâce à son bonus de défense de {enemy_shield.degats_bonus}.",
                "player_parry_shield3": "Dans une démonstration de maîtrise inégalée, le joueur bloque l'attaque de l'ennemi avec une précision chirurgicale, son bouclier agissant comme une extension naturelle de son corps, repoussant toute menace à sa portée. Grâce à son bouclier et à son bonus de défense de {enemy_shield.degats_bonus}, il ne subit que {damage} dégâts, démontrant ainsi sa supériorité dans l'art de la défense.",
                "enemy_parry_shield1": "L'ennemi parvient à parer l'attaque du joueur en brandissant son bouclier avec une adresse surprenante, faisant échec à toute tentative d'assaut. Malgré la vigueur de l'attaque, le joueur inflige seulement {damage} dégâts, le bouclier de l'ennemi offrant une protection supplémentaire grâce à son bonus de défense de {enemy_shield.degats_bonus}.",
                "enemy_parry_shield2": "Dans un mouvement défensif éclair, l'ennemi utilise son bouclier pour contrer habilement l'attaque du joueur, démontrant une maîtrise impeccable des arts de la défense. La puissance de l'assaut est considérablement atténuée, ne causant que {damage} dégâts, le bouclier de l'ennemi jouant un rôle crucial avec son bonus de défense de {enemy_shield.degats_bonus}.",
                "enemy_parry_shield3": "Telle une forteresse impénétrable, l'ennemi pare l'assaut du joueur avec son bouclier, résistant stoïquement à toute tentative d'infliger un quelconque dommage. Grâce à son bouclier et à son bonus de défense de {enemy_shield.degats_bonus}, il ne subit que {damage} dégâts, démontrant ainsi sa résistance inébranlable."
            }

            def go_to_next_one_question():
                choice = my_input(f"Souhaites-tu t'avancer vers le prochain bonhomme de paille, poursuivant ainsi ton exploration à travers ces énigmatiques sentinelles de chaume (w) ou retourner vers le trou de l'épée (s) ? Il te reste {bonshommes_pailles} bonshommes.")
                return choice
            
            def next_one():
                writing_machine("Tu te diriges vers le bonhomme de paille suivant, un sourire narquois se dessinant sur tes lèvres alors que tu anticipes le geste qui lui ôtera la tête, un acte qui te procure un sentiment de satisfaction.")
            
            def end():
                choice = my_input("Tu t'éloigne du bonshomme et t'approches du petit trou béant laissé dans la terre par ta fidèle épée, une empreinte témoignant de ton acte héroïque.\nFace à ce paysage enchanteur, te prend-il l'envie de rester là, à contempler la beauté des lieux (s), ou bien préfères-tu t'enfoncer dans l'épaisseur de la forêt, à la découverte de nouveaux mystères qui t'attendent dans l'ombre des arbres (w)? ")
                return choice
        
        def wait_before_end():
            writing_machine("Tu restes là, absorbé par la contemplation de ce paysage qui s'étend devant toi. Chaque détail, chaque nuance de couleur, semble te captiver, t'invitant à te perdre dans la tranquillité de cet instant fugace...")
            time.sleep(5)
            writing_machine("Sans plus tarder, tu quittes ta rêverie et te diriges résolument vers la lisière de la forêt. Les pensées de contemplation sont balayées par la détermination guerrière qui s'empare de toi, car en effet, un guerrier ne s'attarde pas dans les songes, mais avance vers les défis qui l'attendent dans l'obscurité de la forêt.")
        
        def end():
            writing_machine("Ton esprit de guerrier est reconnu et récompensé. Avec un nouveau niveau gagné, tu t'avances résolument vers la forêt, prêt à affronter les épreuves qui se dressent sur ton chemin avec une détermination renforcée.")

    class village:
        def main():
            global village_done, player
            if "village_done" not in globals():
                writing_machine("Tu arrives au village après avoir traversé la prairie. Les maisons en bois et en pierre sont regroupées autour d'une place centrale où se trouve une fontaine. Des villageois vaquent à leurs occupations et te jettent des regards curieux.")
                writing_machine("Que souhaites-tu faire ?")
                choice = my_input("w : Aller à la taverne\ns : Parler aux villageois\nd : Se reposer à l'auberge\n> ")
                if choice == "w":
                    story.village.taverne()
                elif choice == "s":
                    story.village.villageois()
                elif choice == "d":
                    story.village.auberge()
                else:
                    writing_machine("Ce n'est pas une option valide.")
                    story.village.main()
                village_done = True
            else:
                writing_machine("Tu es de retour au village. Que souhaites-tu faire ?")
                choice = my_input("w : Aller à la taverne\ns : Parler aux villageois\nd : Se reposer à l'auberge\n> ")
                if choice == "w":
                    story.village.taverne()
                elif choice == "s":
                    story.village.villageois()
                elif choice == "d":
                    story.village.auberge()
                else:
                    writing_machine("Ce n'est pas une option valide.")
                    story.village.main()

        def taverne():
            if "barman_out" not in locals():
                writing_machine("Tu te diriges vers la taverne, un bâtiment en bois avec une enseigne représentant une chope de bière. À l'intérieur, il y a quelques clients attablés et le barman essuie des verres derrière le comptoir.")
            else:
                writing_machine("Tu te retourne.")
            choice = my_input("Que veux-tu faire ?\n1 : P arler au barman\n2 : Parler aux clients")
            if choice == "1":
                writing_machine("Le barman te salue et te demande ce que tu veux boire.")
                beer = Objet("bière", 20, "soin", 10, 2)
                whiskey = Objet("Whiskey", 40, "soin", 30, 3)
                rhum = Objet("Rhum", 16, "soin", 50, 4)
                choice = my_input(f"1.{beer.nom}    coûts :{beer.prix}\n2.{whiskey.nom}    {whiskey.prix}\n3.{rhum.nom}    {rhum.prix}\n\n", [1, 2, 3, "sortir"])
                if choice == "1":
                    player.acheter(story.village.description_buy, beer)
                    if beer in player.inventaire:
                        writing_machine("Après t'être emparé de ta bière, tu retourne sur la place du village.")
                        story.village.main()
                    else:
                        story.village.taverne()
                        barman_out = True
                elif choice == "2":
                    player.acheter(story.village.description_buy, whiskey)
                    if whiskey in player.inventaire:
                        writing_machine("Après t'être emparé de ton shot de whiskey, tu retourne sur la place du village.")
                        story.village.main()
                    else:
                        story.village.taverne()
                        barman_out = True
                elif choice == "3":
                    player.acheter(story.village.description_buy, rhum)
                    if rhum in player.inventaire:
                        writing_machine("Après t'être emparé de ton shot de rhum, tu retourne sur la place du village.")
                        story.village.main()
                    else:
                        story.village.taverne()
                        barman_out = True
                elif choice == "sortir":
                    story.village.main()
            elif choice == "2":
                story.village.dialogue_clients()
            else:
                writing_machine("Ce n'est pas une option valide.")
                story.village.taverne()
            story.village.main()
        description_buy = {
            "bière":"Tu as bien pu acheter ta bière elle se trouve maintenant dans ton inventaire.",
            "bière-not_enough_money":"Désolé petit clodo tu n'as pas assez d'argent pour te payer ce délice. Va voir à la fontaine pour un sirop.",
            "Whiskey":"Tu as bien pu acheter ton whiskey elle se trouve maintenant dans ton inventaire. Bravo tu as bon goûts.",
            "Whiskey-not_enough_money":"Désolé petit clodo tu n'as pas assez d'argent pour te payer ce délice. Va voir à la fontaine pour un sirop.",
            "Rhum":"Tu as bien pu acheter ton rhum elle se trouve maintenant dans ton inventaire. Bravo tu as bon goûts.",
            "Rhum-not_enough_money":"Désolé petit clodo tu n'as pas assez d'argent pour te payer ce délice. Va voir à la fontaine pour un sirop."
        }
        def dialogue_clients():
            global player
            writing_machine("Un homme à l'air jovial te regarde et commence à parler.")
            writing_machine("Homme jovial : « Alors, étranger, qu'est-ce qui t'amène ici ? »")
            choice = my_input("1 : Se présenter\n2 : Demander des nouvelles du village\n> ")
            if choice == "1":
                writing_machine("Tu te présentes et expliques que tu ne te rappelles pas de ton passé.")
                writing_machine(f"Homme jovial : « Intéressant... Il y a une vieille légende ici qui parle d'un chevalier sans passé qui deviendra un héros. Peut-être que cette légende parle de toi, {player.nom} ! »")
                story.village.reactions_villageois()
            elif choice == "2":
                writing_machine("Homme jovial : « Oh, rien de spécial ces derniers temps. La vie suit son cours habituel. Mais dis-moi, qui es-tu ? »")
                writing_machine("Tu te présentes et expliques que tu ne te rappelles pas de ton passé.")
                writing_machine(f"Homme jovial : « Intéressant... Il y a une vieille légende ici qui parle d'un chevalier sans passé qui deviendra un héros. Peut-être que cette légende parle de toi, {player.nom} ! »")
                story.village.reactions_villageois()
            else:
                writing_machine("Ce n'est pas une option valide.")
                story.village.dialogue_clients()

        def reactions_villageois():
            global player, good_boy
            writing_machine("Les autres clients écoutent attentivement et commencent à murmurer entre eux.")
            writing_machine("Que veux-tu faire ?")
            choice = my_input("1 : Demander si les villageois ont peur de toi\n2 : Demander si les villageois t'aiment\n> ")
            if choice == "1":
                writing_machine(f"Un vieil homme au fond se lève et s'avance : « Nous avons entendu parler de toi, {player.nom}, mais la légende nous effraie. Nous ne savons pas si nous pouvons te faire confiance. »")
                writing_machine("Il semble que les villageois soient méfiants à ton égard pour le moment.")
                good_boy = False
            elif choice == "2":
                writing_machine(f"Une femme s'avance et te sourit : « La légende dit que tu deviendras un héros. Nous avons foi en toi, {player.nom}, et espérons que tu nous protégeras. »")
                writing_machine("Il semble que certains villageois t'aiment et ont de grands espoirs pour toi.")
                good_boy = True
            else:
                writing_machine("Ce n'est pas une option valide.")
                story.village.reactions_villageois()
                
        def dialogue_clients():
            global player, good_boy
            writing_machine("Tu t'assois avec les clients et engages la conversation.")
            if "good_boy" not in globals():
                story.village.dialogue_clients()
            if good_boy:
                story.village.dialogue_hero()
            else:
                story.village.dialogue_fear()

        def dialogue_hero():
            global player
            writing_machine("Tu te présentes à nouveau et parles de tes exploits.")
            writing_machine(f"Homme jovial : « Ah, vous êtes de retour, ", {player.nom}, "! Racontez-nous encore une de vos aventures ! »")
            story.village.reactions_villageois()

        def dialogue_fear():
            global player
            writing_machine("Tu te présentes à nouveau mais les villageois semblent nerveux.")
            writing_machine(f"Femme inquiète : « Oh, c'est vous... ", {player.nom}, "... Nous espérons juste qu'il n'y aura pas de problèmes... »")
            story.village.reactions_villageois()

        def villageois():
            global player
            writing_machine("Tu t'approches d'un groupe de villageois qui discutent sur la place. Ils te regardent avec méfiance mais finissent par répondre à tes questions.")
            choice = my_input("Que veux-tu faire ?\n1 : Poser des questions sur le village\n2 : Demander des nouvelles récentes\n> ")
            if choice == "1":
                writing_machine("Les villageois te parlent des différentes attractions et histoires du village. AH le temps s'arrête !!")
            elif choice == "2":
                writing_machine("Les villageois partagent des nouvelles récentes et des rumeurs. ")
            else:
                writing_machine("Ce n'est pas une option valide.")
            story.menu.main()

        def auberge():
            global player
            writing_machine("Tu te rends à l'auberge, un bâtiment en pierre avec une enseigne représentant un lit. À l'intérieur, il y a une réception et des couloirs menant aux chambres.")
            if key_room not in player.inventaire:
                choice = my_input("Que veux-tu faire ?\n1 : Louer une chambre\n2 : Parler au réceptionniste\n")
            else:
                choice = my_input("Que veux-tu faire ?\n3 : Aller vous reposer\n2 : Parler au réceptionniste\n")
            if choice == "1" and key_room not in player.inventaire:
                writing_machine("Vous payez pour une chambre et le réceptionniste vous remet une clé.")
                player.argent -= 10
                key_room = Objet("clé de chambre 12", 0, "clé", 0, 4)
                player.inventaire.append(key_room)
                writing_machine("Vous utilisez la clé pour ouvrir votre chambre.")
                writing_machine("Vous entrez dans votre chambre et vous reposez.")
                player.vie += 100
            elif choice == "2":
                writing_machine("Le réceptionniste vous conseille d'aller à la taverne pour en savoir plus sur le village.")
            elif choice == "3":
                if key_room in player.inventaire:
                    writing_machine("Tu rentre dans la chambre. Il y'a un simple lit. Tu t'allonge et t'endors sur tes deux oreilles.")
                    story.menu.main()
            else:
                writing_machine("Ce n'est pas une option valide.")

    class dark_forest:
        def main():
            pass
        pass

    class spy_tower:
        def main():
            pass
        pass

    class dunjeon:
        def main():
            pass
        pass

    class castle:
        def main():
            pass
        pass

    class dragon:
        def main():
            pass
        pass

    class end_of_story:
        def main():
            pass
        pass

# functions
def choose_writing_speed():
    while True:
        global default_writing_speed
        value_error = False
        writing_machine("Tout ce que tu as à faire, c'est d'écrire un nombre qui se situe entre 0 et 100%, puis d'appuyer sur la touche Entrée. N'hésite pas à faire autant d'essais que tu le souhaites, il n'y a pas de hâte. Une fois que tu as terminé, note ton nombre, laisse un espace, et écris \"ok\".", default_writing_speed)
        text_part = my_input("").split(" ")
        try:
            value_in_percents = int(text_part[0])
            default_writing_speed = map_range(value_in_percents, 0, 100, 0, 0.05)
        except ValueError:
            value_error = True
            writing_machine("Rentre un chiffre petit poisson globuleux.")
        print(f"tu as définit {default_writing_speed}% comme vitesse d'écriture.")
        if len(text_part) == 2 and value_error == False:
            if text_part[1] == "ok":
                return default_writing_speed

def writing_machine(text, speed = None):
    if speed == None:
        global default_writing_speed
        speed = default_writing_speed
    sentence_index = 0  
    word_index = 0  
    text = text.split(" ")
    remaining_space = shutil.get_terminal_size().columns

    while sentence_index < len(text):
        if len(text[sentence_index]) > remaining_space:
                print()
                remaining_space = shutil.get_terminal_size().columns
        
        while word_index < len(text[sentence_index]):
            letter_to_print = text[sentence_index][word_index]

            if letter_to_print == "\n":
                remaining_space = shutil.get_terminal_size().columns

            print(letter_to_print, end="", flush=True)
            time.sleep(speed)
            
            word_index += 1
            remaining_space -= 1

        sentence_index += 1
        word_index = 0

        print(" ",end="", flush=True)
        remaining_space -= 1
    print()

def my_input(question, expected_answer = None):
    global partie_on_time
    writing_machine(question)
    print("-> ",end="",flush=True)
    user_input = input()
    while user_input == "":
        writing_machine("Entre une valeur petit vers de terre désséché !")
        print("-> ",end="",flush=True)
        user_input = input()
    if user_input == "menu":
        story.menu.main()
    os.system('cls')
    return user_input

def fight(player, enemy, story_stage, enemy_health_threshold = 20):
    player_weapon = choose_weapon(player)
    player_shield = choose_shield(player)
    enemy_weapon = enemy_choose_weapon(enemy)
    enemy_shield = enemy_choose_weapon(enemy)
    writing_machine(story_stage.description["introduction/choice"])

    while player.vie > 0 and enemy.vie > 0:
        flee_ok = None
        action = my_input(story_stage.description["choice"])
        while action not in {"w", "s", "e"}:
            action = my_input(story_stage.description["bad_input"])
            enemy.attack(player, story_stage, enemy_weapon, player_shield)
        if action == "w":
            player.attack(enemy, story_stage, player_weapon, enemy_shield)
        elif action == "s":
            flee_ok = player.fuir(enemy, story_stage, enemy_weapon, enemy_shield)
            if flee_ok:
                print(story_stage.description["flee_ok"])
                break
            else:
                print(story_stage.description["flee_lost"])
        elif action == "e":
            total_time = float(story_stage.description["time_to_drink_num"])
            print(story_stage.description["time_to_drink"])
            time_start = time.time()
            consumeable = None
            while time.time() - time_start < total_time:
                if consumeable is None:
                    consumeable = choose_consumeable(player)
            if consumeable is not None:
                writing_machine(story_stage.description["drink_ok"])
                player.consume(consumeable, story_stage.description)
                writing_machine(story_stage.description["time_to_drink_ok"])
        if flee_ok:
            break
        else:
            if enemy.vie <= enemy_health_threshold:
                print(story_stage.description["enemy_weak"])
            elif player.vie <= enemy_health_threshold:
                print(story_stage.description["player_injured"])
        
        enemy.attack(player, story_stage, enemy_weapon, player_shield)

    if player.vie <= 0:
        writing_machine(story_stage.description["player_dead"])
        return False
    elif enemy.vie <= 0:
        writing_machine(story_stage.description["enemy_dead"])
        gain_argent = enemy.argent + (enemy.argent * enemy.level) // 2
        player.argent += gain_argent
        gain = story_stage.description["money_reward"]
        writing_machine(gain.format(gain_argent=gain_argent, player=player))
        return True
    else:
        return False

def choose_weapon(player):
    writing_machine("\n\nChoisis ton arme pour ce combat jeune chevalier :\n")
    available_weapon = []
    for weapon in player.inventaire:
        if isinstance(weapon, Arme):
            available_weapon.append((weapon))

    for i, weapon in enumerate(available_weapon, 1):
        writing_machine(f"{i}. {weapon.show_attribute()}")
    
    while True:
        writing_machine("Nom de l'arme, degats de bases, degats bonus, type")
        choix = my_input("Entre le numéro de ton arme")
        try:
            index_arme = int(choix) - 1
            if 0 <= index_arme < len(available_weapon):
                return available_weapon[index_arme]
            else:
                writing_machine("Choix invalide. Entre une arme et non ton arrière train petite mouche à fumier.")
        except ValueError:
            writing_machine("Entre un vrai numéro dragonneau aveugle.")

def choose_shield(player):
    available_shield  = []
    for shield in player.inventaire:
        if isinstance(shield, Arme) and shield.type == "shield":
            available_shield.append((shield))
    
    if len(available_shield) != 0:
        writing_machine("Choisis ton bouclier jeune guerrier :")
        for i, shield in enumerate(available_shield , 1):
            writing_machine(f"{i}. {shield.show_attribute()}")
        
        while True:
            choix = my_input("Nom, degats de bases, degats bonus, type\nEntre le numéro de ton bouclier")
            try:
                index_arme = int(choix) - 1
                if 0 <= index_arme < len(available_shield):
                    return available_shield[index_arme]
                else:
                    writing_machine("Choix invalide. Entre une bouclier et non ton molusque de compagnie.")
            except ValueError:
                writing_machine("Entre un vrai numéro petit boulet.")
    else:
        return None

def choose_consumeable(player):
    writing_machine("Choisis ta soif et à ta santé !")
    consumeable = [item.nom for item in player.inventaire if isinstance(item, Objet) and item.type == "soin"]
    if len(consumeable) != 0:
        for i, item in enumerate(consumeable, 1):
            writing_machine(f"{i}. {item}")
        while True:
            choix = my_input("Entre le numéro de ta boisson")
            try:
                index_arme = int(choix) - 1
                if 0 <= index_arme < len(consumeable):
                    return consumeable[index_arme]
                else:
                    writing_machine("Choix invalide. Entre un boisson non alcoolisée tu es trop jeune petit filou.")
            except ValueError:
                writing_machine("Entre un vrai numéro limace sèche.")
    else:
        writing_machine("Désolé mais il n'y a absolument rien pour se désaltéré dans ta besace !!")

def show_inventory(player):
    items = [item.nom for item in player.inventaire]
    items.append("Sortir (s)")              #A enlever selon besoin...
    for i, item in enumerate(items, 1):
        writing_machine(f"{i}. {item}\n")

def askForName():
    name = ""
    i = 0
    while name == "":
        i +=1
        if i>5:
            name = my_input("Tu Forces ! Ecrit ton nom et puis c'est tout !")
        else:
            name = my_input("Quel est ton nom petit félon ?")
    return name
def enemy_choose_weapon(enemy):
    available_weapon = []
    for weapon in enemy.inventaire:
        if isinstance(weapon, Arme) and weapon.type != "shield":
            available_weapon.append((weapon))
    return available_weapon[0]

def enemy_choose_shield(enemy):
    available_weapon = []
    for weapon in enemy.inventaire:
        if isinstance(weapon, Arme) and weapon.type == "shield":
            available_weapon.append((weapon))
    if len(available_weapon) != 0:
        return available_weapon[0]
    else:
        return None

def askForNextPlace():
    global unlocked_places
    text_unlocked_places = ""
    for num, place in enumerate(unlocked_places, 1):
        text_unlocked_places += "\n" + f"{num}" + ". " + place
    choice = my_input(f"\n\nOù souhaites-tu te rendre pour ta prochaine aventure ?{text_unlocked_places}\n\ninscrit le numéro de la zone vers laquelle tu veux te déplacer")
    if choice == '1':
        choice = "lobby"
    elif choice == '2':
        choice = "prairie"
    elif choice == '3':
        choice = "village"
    elif choice == '4':
        choice = "forêt profonde"
    elif choice == '5':
        choice = "tour solitaire"
    elif choice == '6':
        choice = "donjon"
    elif choice == '7':
        choice = "château"
    elif choice == '8':
        choice = "dragon"
    return choice

def map_range(x, in_min, in_max, out_min, out_max):
  a = (out_min-out_max)/(in_min-in_max)
  b = (out_min*in_max - out_max*in_min)/(in_max-in_min)
  return a*x+b

story.menu.main()