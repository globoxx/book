from pgzhelper import *
from random import *

TITLE = 'space battle'
WIDTH = 800
HEIGHT = 600
paused = False
shoot = True

class Star(Actor):

    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

    def update(self):
        pass


class Ennemy(Actor):

    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = 3
        self.direction = randint(0, 360)
        self.paused = False

    def update(self):
        if not paused:
            self.move_in_direction(self.speed)
            self.direction += randint(-10, 10)
            detect_border(self)


class Spaceship(Actor):

    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = 4
        self.game_over = False
        self.score = 0
        self.direction = 0
        self.angle = 0
        self.vie = 50

    def update(self):
        if not paused:
            if keyboard.right:
                self.direction -= 3
                self.angle -= 3
            elif keyboard.left:
                self.direction += 3
                self.angle += 3
            if keyboard.up:
                self.move_in_direction(self.speed)
            elif keyboard.down:
                self.move_in_direction(-self.speed)
            for ennemy in ennemies:
                if self.collides_with(ennemy):
                    ennemy.to_remove = True
                    if self.vie == 0:
                        self.game_over = True
                    self.vie -= 10
            detect_border(self)


class LaserRed(Actor):

    def __init__(self, image, pos, direction, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.direction = direction
        self.angle = direction
        self.speed = 7

    def update(self):
        if not paused:
            self.move_in_direction(self.speed)
            for ennemy in ennemies:
                if ennemy.collides_with(self):
                    ennemy.to_remove = True
                    self.to_remove = True
                    spaceship.score += 1


def add_star():
    star = Star("star1", (randint(0, WIDTH), randint(0, HEIGHT)))
    stars.append(star)


def add_ennemy():
    if not paused:
        ennemy = Ennemy("playership3_green",
                        (randint(0, WIDTH), randint(0, HEIGHT)))
        ennemies.append(ennemy)


def detect_border(actor):
    if actor.x < 0:
        actor.x = WIDTH
    elif actor.x > WIDTH:
        actor.x = 0
    if actor.y < 0:
        actor.y = HEIGHT
    elif actor.y > HEIGHT:
        actor.y = 0


def allow_shooting():
    global shoot
    shoot = True


def on_key_down(key):
    global paused
    if key == keys.SPACE:
        paused = not paused


def on_mouse_down(pos):
    global shoot
    if shoot:
        shoot = False
        clock.schedule(allow_shooting,
                       0.5)
        direction = spaceship.angle_to(pos)
        laser = LaserRed("laserred02", (spaceship.x, spaceship.y), direction)
        lasers.append(laser)


lasers = []
ennemies = []
clock.schedule_interval(add_ennemy, 1.5)
spaceship = Spaceship('playership2_orange', (WIDTH / 2, HEIGHT * 3 / 4))
stars = [
    Star("star1", (randint(0, WIDTH), randint(0, HEIGHT))) for _ in range(15)
]


def draw():
    screen.fill('black')
    screen.draw.text(f"Score: {spaceship.score}", (0, 0))
    screen.draw.text(f"Vie: {spaceship.vie}", (0, 20))
    for star in stars:
        star.draw()
    spaceship.draw()
    for laser in lasers:
        laser.draw()
    for ennemy in ennemies:
        ennemy.draw()
    if spaceship.game_over:
        screen.fill("black")
        screen.draw.text("Game Over",
                         center=(WIDTH / 2, HEIGHT / 2),
                         color="red",
                         fontsize=60)
        screen.draw.text(f"Score: {spaceship.score}",
                         (WIDTH / 2 - 30, HEIGHT / 2 + 50))


def update():
    if not paused:
        spaceship.update()
        for laser in lasers:
            laser.update()
        for ennemy in ennemies:
            ennemy.update()
        remove_actors(ennemies)

music.play('starwars')
