from pgzhelper import *

TITLE = 'Dont Fall'

WIDTH = 1780
HEIGHT = 800

GRAVITY = 0.3

WORLD_MAP = [
    [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],
    [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],
    [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],
    [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],
    [7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,5,3,3,3,3,3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,5,0,0,0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,6,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],
    [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],
    [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],
    [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],
]

TILE_SIZE = 70 # Taille d'un bloc en pixels
ROWS = len(WORLD_MAP) # Nombre de lignes
COLS = len(WORLD_MAP[0]) # Nombre de colonnes

WORLD_HEIGHT = ROWS*TILE_SIZE
WIDTH = 1330 # Largeur de la fenêtre de jeu
HEIGHT = 900 # Hauteur

class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.vy = 0
        self.speed = 3
        self.end = False
    def update(self):
        self.vy += GRAVITY

        if keyboard.a:
            self.x -= self.speed
            self.flip_x = True
        if keyboard.d:
            self.x += self.speed
            self.flip_x = False

        for platform in platforms:
            platform.check_collision_with_actor(self)

        for echelle in echelles:
            if keyboard.space and (self.vy == 0 or self.collides_with(echelle)):
                self.vy = -12

        if self.y <320 and self.vy < 0:
            for platform in platforms:
                platform.y -= self.vy
            for echelle in echelles:
                echelle.y -= self.vy
            for bloc_fin in limite_fin:
                bloc_fin.y -= self.vy
        elif self.y >600 and self.vy > 0.3:
            for platform in platforms:
                platform.y -= self.vy
            for echelle in echelles:
                echelle.y -= self.vy
            for bloc_fin in limite_fin:
                bloc_fin.y -= self.vy
        else:
            self.y += self.vy

class Echelle (Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
    def update (self):
        if self.collides_with (player):
            player.vy=0
            if keyboard.w:
                player.y -= player.speed
            if keyboard.s:
                player.y += player.speed

class Bloc_fin (Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
    def update (self):
        if self.collides_with(player):
            player.end = True

platform = Platform('herbe', (WIDTH/2, HEIGHT/2))
echelles = []
platforms = []#On définit notre liste vide de plateformes
limite_fin = []
for row in range(ROWS): # On parcourt les lignes du tableau
    for col in range(COLS): # On parcourt les colonnes du tableau
        # Calcul de la position (x, y) du bloc en fonction de la ligne et de la colone sur laquelle on est
        pos = (col*TILE_SIZE+TILE_SIZE/2, HEIGHT-WORLD_HEIGHT+row*TILE_SIZE+TILE_SIZE/2)
        if WORLD_MAP[row][col] == 1: # Bloc classique traversable
            platform = Platform('herbe', pos, solid=True, width=TILE_SIZE)
            platforms.append(platform)
        elif WORLD_MAP[row][col] == 2: # Bloc solide mais que l'on ne peut pas escalader
            platform = Platform('terre', pos, solid=True, width=TILE_SIZE)
            platforms.append(platform)
        elif WORLD_MAP[row][col] == 3: # Bloc solide que l'on peut escalader
            echelle = Echelle('echelle1', pos, width=TILE_SIZE)
            echelles.append(echelle)
        elif WORLD_MAP[row][col] == 4:
            echelle = Echelle('echelle2', pos, width=TILE_SIZE)
            echelles.append(echelle)
        elif WORLD_MAP[row][col] == 5:
            platform = Platform('platforme_herbe', pos, width=TILE_SIZE)
            platforms.append(platform)
        elif WORLD_MAP[row][col] == 6:
            player = Player('idle', pos)
        elif WORLD_MAP[row][col] == 7:
            bloc_fin = Bloc_fin('piques', pos, width=TILE_SIZE)
            limite_fin.append(bloc_fin)

def draw():
    screen.fill("sky blue")
    for platform in platforms:
        platform.draw()
    for echelle in echelles:
        echelle.draw()
    for bloc_fin in limite_fin:
        bloc_fin.draw()
    player.draw()
    if player.end == True:
        screen.fill("black")
        screen.draw.text("Victoire !", (WIDTH/2, HEIGHT/2))

def update():
    player.update()
    for echelle in echelles:
        echelle.update()
    for bloc_fin in limite_fin:
        bloc_fin.update()

