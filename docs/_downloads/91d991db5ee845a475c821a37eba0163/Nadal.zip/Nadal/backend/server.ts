import "dotenv/config";

import express from "express";
import cors from "cors";
import userRoutes from "./routes/userRoutes";


const app = express();

const FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:5173";
app.use(cors({
	origin: FRONTEND_URL,
	credentials: true,
}));
app.use(express.json());

app.use("/api/user", userRoutes)

app.listen(2000, () => {
	console.log("Server running on http://localhost:2000");
});
