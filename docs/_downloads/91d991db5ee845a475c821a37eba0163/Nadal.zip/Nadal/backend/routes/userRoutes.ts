import { Router } from "express";
import bcrypt from "bcryptjs";
import { v4 as uuidv4 } from "uuid";
import { prisma } from "../prisma";
import authMiddleware from "../middlewares/authMiddleware";


const router = Router();

// le middle ware est executé et s'il pense que c'est bon il envera la suite avec la méthode next();
router.get("/me", authMiddleware, (req: any, res) => {
	// si le middleware réussie alors on répond :
  res.json({
    success: true,
    user: req.user,
  });
});


router.post("/login", async (req, res) => {
	const { email, password } = req.body;

	try {
		const existingUser = await prisma.user.findUnique({ where: { email } }); //cherche un user avec l'eamil envoyé.

		//si il ne trouve pas de user avec le mail envoyé il envoye un réponse avec erreur 401 et success false avec un message.
		if (!existingUser) {
			return res
				.status(401) 
				.json({ success: false, message: "Utilisateur non trouvé" });
		}

		//si il passe l'étape du dessus c'est à dire qu'il trouve un user avec le mail envoyé dans la base de donné alors il vérifie le password avec la bibliothèque bcrypte je compare le password envoyé avec celui dans la base de donné.
		const isPasswordValid = await bcrypt.compare(
			password,
			existingUser.password
		);
		//si le password n'est pas le même que dans la base alors on renvoye une reponse au front.
		if (!isPasswordValid) {
			return res
				.status(401)
				.json({ success: false, message: "Mot de passe incorrect" });
		}

		//une fois toutes les étapes de vérifications passé on créer un token d'identification avec uuidv4 et on crée une date d'expiration (la datte actuelle + 24h) puis on créer las session avec prisma avec les info du dessus.
		const token = uuidv4();
		const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24);
		await prisma.session.create({
			data: {
				token,
				userId: existingUser.id,
				expiresAt,
			},
		});
		// finnalement en envoye une réponse au front avec les infos de connections. -> envoye à login.tsx
		return res.json({
			success: true,
			token,
			user: {
				id: existingUser.id,
				email: existingUser.email,
				name: existingUser.name,
			},
		});
	} catch (err) {
		console.error(err);
		return res.status(500).json({ success: false, message: "Erreur serveur" });
	}
});

router.post("/register", async (req, res) => {
	const { email, password } = req.body;

	//on essaye de voir s'il existe déjà un utilisateur avec ce mail s'il existe on retourne une erreur en réponse
	try {
		const existingUser = await prisma.user.findUnique({ where: { email } });

		if (existingUser) {
			return res
				.status(400)
				.json({ success: false, message: "Cet email est déjà utilisé." });
		}
		//s'il passe l'étape du dessus on hash les password c'est à dire qu'on applique une fonction mathématique qui va créer une chaîne très difficile à décrypter.
		const hashedPassword = await bcrypt.hash(password, 10);
		//on créer un utilisateur avec les infos.(dans la base de donée)
		const newUser = await prisma.user.create({
			data: {
				email,
				password: hashedPassword,
			},
		});
		const token = uuidv4();
		const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24); // 24h
		await prisma.session.create({
			data: {
				token,
				userId: newUser.id,
				expiresAt,
				
			},
		});
		// on renvoye une réponse positive -> register.tsx
		res.json({
			success: true,
			token,
			user: {
				id: newUser.id,
				email: newUser.email,
				name: newUser.name,
			},
		});
	} catch (err) {
		console.error(err);
		res.status(500).json({ success: false, message: "Erreur serveur" });
	}
});

export default router;

