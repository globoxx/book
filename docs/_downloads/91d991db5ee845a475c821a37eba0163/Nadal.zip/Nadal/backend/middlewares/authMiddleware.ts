import { prisma } from "../prisma";

const authMiddleware = async (req: any, res: any, next: any) => {
  //récupére le token dans les headers dans authorisations on vérifie s'il existe et après on utilise la méthode split("")[1]: split transforme les élements séparé d'un espace en une liste ["Bearer", b2fb2fjewb2ufb2uew] et [1] prend l'éléent à la place 1 donc le token.
  const token = req.headers.authorization?.split(" ")[1]; 
  //s'il n'y a pas de token on renvoye une réponse négative
  if (!token) return res.status(401).json({ success: false, message: "Token manquant" });

  //s'il y a un token on cherche une session avec le token et où l'user est en ligne
  const session = await prisma.session.findUnique({ where: { token }, include: { user: true } });
  //s'il trouve pas de session ou si la sesion à expiré il renvoye une réponse négative
  if (!session || session.expiresAt < new Date())
    return res.status(401).json({ success: false, message: "Session invalide" });

  //on rajoute à la req.user session.user
  req.user = session.user;
  next();
};

export default authMiddleware;