import { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import "./App.scss";
import { Search, Heart, ShoppingBag, ArrowDown, Slack, LogOut } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

interface User {
  id: number;
  email: string;
  name?: string;
}

function Logo() {
	return <p style={{ fontWeight: "bold", fontSize: "2rem"}}>IN</p>;
}

function App() {
	const [user, setUser] = useState<User | null>(null); // on créer un état de l'utilisateur pour savoir s'il est connecté
	const [isClicked, setIsClicked] = useState<boolean>(false)

	const clickerHearth = () => {
		setIsClicked(!isClicked)
	}

	useEffect(() => {
		// ici on utilise useEffect pour executer du code après que le dom ait été chargé (une seul fois [])
		//On récupère le token qui avait été enregistré dans le navigateur dans login.tsx
		const token = localStorage.getItem("token");
		// s'il n'y a pas de token on arrête le hook
		if(!token) return;

		// on fait une requète au backend à / me on présice que dans le headers se trouve le token -> userRoutes
		axios.get("http://localhost:2000/api/user/me", {
			headers: {
				Authorization: `Bearer ${token}`
			}
		})
		.then((res) => {
			//on met à jour l'état d'user qui était nul à la base
			setUser(res.data.user);
		})
		.catch(() => {
			//si ça échoue alors on supprime le token du stockage du navigateur.
			localStorage.removeItem("token")
		});
	}, []);
	useEffect(() => {
		// Sélectionne toutes les cartes buyer
		gsap.utils.toArray(".buyer").forEach((buyer: any) => {
			gsap.fromTo(
				buyer,
				{
					opacity: 0,
					y: 100,
				},
				{
					opacity: 1,
					y: 0,
					duration: 1,
					ease: "power2.out",
					scrollTrigger: {
						trigger: buyer,
						start: "top 70%",
						toggleActions: "play none none reverse",
					},
				}
			);
		});
	}, []);

	return (
		<div className="App">
			<header>
				<Slack style={{ strokeWidth: "1.359" }} />
				<div className="owner">
					
					<p>Trouver un magasin</p>
					<p>Aide</p>
					<p>Rejoins-nous</p>
					{user ? (
						<div className="user-circle">
							{user.email[0].toUpperCase()}
						</div>
					) : (
						<Link to="/login" className="ident">
							<p>S'identifier</p>
						</Link>
					)}
					{user && (
						<div title="logout">
							
							<LogOut
							onClick={() => {
								localStorage.removeItem("token");
								setUser(null);
							}}/>
						</div>
						
							
					)}
				</div>
			</header>

			<nav>
				<div className="nav-bounding">
					<div className="nav-container">
						{/* 						<Banana className="imgsell" /> */}
						<Logo />
						<div className="user">
							<a href="#card-section" className="aRefContent"><h3>Nouveauté</h3></a>
							<a href="#card-section" className="aRefContent"><h3>Homme</h3></a>
							<a href="#card-section" className="aRefContent"><h3>Femme</h3></a>
							<a href="#card-section" className="aRefContent"><h3>Enfant</h3></a>
							<a href="#card-section" className="aRefContent"><h3>Sports</h3></a>
							<a href="#card-section" className="aRefContent"><h3>Sportswear</h3></a>
						</div>
						<div className="imgBuy">
							<Search className="icon-button" />
							<Heart onClick={clickerHearth} className={`heart-button ${isClicked? "" : "colored" }`} />
							
								 
							
							<ShoppingBag className="icon-button" />
						</div>
					</div>
				</div>
			</nav>

			<main>
				<section id="hero-section">
					<div className="video-container ">
						<iframe
							className="ivideo"
							width="1250"
							height="703"
							src="https://www.youtube.com/embed/9OprNFnzxTw?autoplay=1&mute=1&controls=0&loop=1&playlist=9OprNFnzxTw&rel=0"
							title="Balance - a Cycling Short Film"
							frameBorder="0"
							allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
							referrerPolicy="strict-origin-when-cross-origin"
							allowFullScreen
							style={{ pointerEvents: "none" }}
						/>
					</div>

					<div className="videotext">
						<h2>
							IBRIZ NADAL
							<br />
							BOREAS
						</h2>
						<p>Pour bouger différemment</p>
					</div>
					<div className="downer">
						<a href="#card-section">
							<ArrowDown />
						</a>
					</div>
				</section>
				<section id="card-section">
					<div className="outsidecontent">
						<div className="buyer">
							<img className="bike" src="./bike.jpg" alt="" />
							<div className="buyer-text-container">
								<p>Old Motorcycle</p>
								<p className="slog">Augmente ta vitesse</p>
								<button>Acheter</button>
							</div>
						</div>
						<div className="buyer">
							<img
								className="bike"
								src="./old-bike.jpg"
								alt=""
							/>
							<div className="buyer-text-container">
								<p>Old Bike</p>
								<p className="slog">Augmente ta vitesse</p>
								<button>Acheter</button>
							</div>
						</div>
						<div className="buyer">
							<img className="bike" src="./daylily.jpg" alt="" />
							<div className="buyer-text-container">
								<p>Daylily Flower</p>
								<p className="slog">Enjolive ta fragrance</p>
								<button>Acheter</button>
							</div>
						</div>
						<div className="buyer">
							<img className="bike" src="./dawn.jpg" alt="" />
							<div className="buyer-text-container">
								<p>Beautiful Dawn</p>
								<p className="slog">Voyage bien</p>
								<button>Acheter</button>
							</div>
						</div>
					</div>
					
				</section>
			</main>
			<footer>
				<div>
					<h3>Ressources</h3>
				</div>

				<div className="footer-content">
					<h3 className="titre-footer">Aide</h3>
					<ul>
					<li>Aide</li>
					<li>Statut de l'ordre</li>
					<li>Expédition et livraison</li>
					<li>Retours</li>
					<li>Options de paiements</li>
					<li>Contact</li>
					<li>Commentaires</li>
					</ul>
				</div>

				<div className="footer-content">
					<h3 className="titre-footer">Société</h3>
					<ul>
					<li>À propos de Nadal</li>
					<li>Actualités</li>
					<li>Carrière</li>
					<li>Investisseurs</li>
					<li>Durabilité</li>
					<li>Mission</li>
					<li>Nadal Coaching</li>
					</ul>
				</div>

				<div className="footer-content">
					<h3 className="titre-footer">Communauté</h3>
					<ul>
					<li>Étudiant(e)</li>
					<li>Enseignant(e)</li>
					<li>Service d'urgence</li>
					<li>Personnel de santé</li>
					</ul>
				</div>
				</footer>
		</div>
	);
}

export default App;
