export function checkMail(mail: string): boolean {
	return mail.includes("@");
}

export function checkPassword(pswd: string, pswd2: string): boolean {
    return pswd === pswd2 && pswd !== "";
}




