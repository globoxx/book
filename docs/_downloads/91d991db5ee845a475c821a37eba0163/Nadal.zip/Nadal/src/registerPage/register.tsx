// src/register.tsx

import { Link, useNavigate } from "react-router-dom";
import "./register.scss";
import { useState } from "react";
import axios from "axios";
import { checkMail, checkPassword } from "./verivication";

export default function Register() {
	const [mail, setMail] = useState<string>("");
	const [password, setPassword] = useState<string>("");
	const [passwordVerifiecation, setPasswordVerifiecation] =
		useState<string>("");
	const [isValid, setIsValid] = useState<boolean>(true);
	const navigate = useNavigate();

	const register = async () => {
		//simple vérification que ce qui est entré dans les champs est juste.
		if (!checkMail(mail) || !checkPassword(password, passwordVerifiecation)) {
			console.log("mail non valide");
			setIsValid(false);
			return;
		} else {
			setIsValid(true);
		}

		//si la vérification est passée on envoye une requête au backend avec les infos -> userRouter
		try {
			const response = await axios.post(
				"http://localhost:2000/api/user/register",
				{
					email: mail,
					password: password,
				}
			);
			//si la réponse du backend est positive(true) alors on navigue à la page / définit comme <App /> donc App.tsx dans main.tsx
			if (response.data.success) {
				localStorage.setItem("token", response.data.token);
				navigate("/");
			} else {
				console.log(response.data.message);
			}

			//si la réponse du backend est positive(true) alors on navigue à la page / définit comme <App /> donc App.tsx dans main.tsx
		} catch (error: any) {
			console.log(error);
		}
	};

	return (
		<div className="register-page">
			<div className="image-de-contenu">
				<img className="imagest2" src="./althle.jpeg" alt="" />
				
			</div>
			<div className="main-content">
				<div className="sub-main">
					<div className="register-content">
						<div className="register-formulaire">
							<div className="formulaire-title">
								<p>
									<span>register</span> your account
								</p>
							</div>
							<div className="formulaire-input">
								<div className="input-code" id="input-username">
									<p>Username</p>
									<input
										onChange={(e) => setMail(e.target.value)}
										className={`username ${isValid ? "" : "error"}`}
										type="email"
										placeholder="enter a mail"
										value={mail}
									/>
								</div>
								<div></div>
								<div className="input-code" id="input-password">
									<p>password</p>
									<input
										onChange={(e) => setPassword(e.target.value)}
										className={`username ${isValid ? "" : "error"}`}
										type="password"
										placeholder="enter a password"
										value={password}
									/>
									<p id="help-text">forgot password?</p>
								</div>
								<div className="input-code" id="input-password">
									<p>password</p>
									<input
										onChange={(e) => setPasswordVerifiecation(e.target.value)}
										className={`username ${isValid ? "" : "error"}`}
										type="password"
										placeholder="confirm password"
										value={passwordVerifiecation}
									/>
									<p id="help-text">forgot password?</p>
								</div>
							</div>
							<div className="formulaire-buttons">
								<button onClick={register}>register</button>
								{/* <button>Create Account</button> */}
								<p className="button-comment">
									If you have an account &nbsp;
									<Link to="/login">click here</Link>.
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}

//<Link to="/">clicker</Link>
