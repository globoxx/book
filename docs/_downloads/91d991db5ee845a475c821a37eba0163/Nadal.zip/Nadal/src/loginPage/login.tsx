// src/login.tsx

import { Link, useNavigate } from "react-router-dom";
import "./login.scss";
import { useState } from "react";
import axios from "axios";



export default function Login() {
	const [mail, setMail] = useState<string>("");
	const [password, setPassword] = useState<string>("");
	const [isValid, setIsValid] = useState<boolean>(true);
	const navigate = useNavigate();

	const login = async () => {
		try {
			const response = await axios.post("http://localhost:2000/api/user/login", {
				email: mail,
				password: password,
			}); // j'envoie ma requête de connection au serveur avec la path /login -> envoye à userRoutes
			console.log(response.data);

			// une fois qu'on recoit la réponse en json on regarde si la catégorie success = true si c'est le cas on stock dans le navigateur le token envoyé du serveur et on va à la page définit par / dans main.tsx qui équivaux à -> app.tsx 
			if (response.data.success) {
				localStorage.setItem("token", response.data.token); 
				navigate("/");
			} else {
				
				console.log("Email ou mots de passe incorecte.")
			}
		} catch (error: any) {
			setIsValid(false)
			console.log(error);
		}
	};

	return (
		<div className="login-page">
			<div className="image-de-contenu">
				<img
					className="imagest"
					src="./althle.jpeg"
					alt=""
				/>
				{/* <p className="slogant">Discipline beats talent.</p> */}
			</div>
			<div className="main-content">
				<div className="sub-main">
					<div className="login-content">
						<div className="login-formulaire">
							<div className="formulaire-title">
								<p>
									<span>Login</span> your account
								</p>
							</div>
							<div className="formulaire-input">
								<div className="input-code" id="input-username">
									<p>Username</p>
									<input
										onChange={(e) => setMail(e.target.value)}
										className={`username ${isValid ? "" : "error"}`}
										type="email"
										placeholder="enter a mail"
										value={mail}
									/>
								</div>
								<div className="input-code" id="input-password">
									<p>password</p>
									<input
										onChange={(e) => setPassword(e.target.value)}
										className={`username ${isValid ? "" : "error"}`}
										type="password"
										placeholder="enter a password"
										value={password}
									/>
									<p id="help-text">forgot password?</p>
								</div>
							</div>
							<div className="formulaire-buttons">
								<button onClick={login}>Login</button>
								{/* <button>Create Account</button> */}
								<p className="button-comment">
									If you don't have an account &nbsp;
									<Link to="/register">click here</Link>.
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}

//<Link to="/">clicker</Link>
