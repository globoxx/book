import pygame, random, time
pygame.init()

class Apple:

    def __init__(self, dimensions_grid, dimensions_apple):
        self.dimensions_grid = dimensions_grid
        self.dimensions_apple = dimensions_apple
        self.x = random.randrange(0,self.dimensions_grid,self.dimensions_apple) + 100
        self.y = random.randrange(0,self.dimensions_grid,self.dimensions_apple) + 100
        self.rect = pygame.Rect(self.x,self.y,self.dimensions_apple,self.dimensions_apple)
        self.color = 'red'
        self.is_eating = False

    def change_position(self):
        self.rect.x = random.randrange(0,self.dimensions_grid,self.dimensions_apple) + 100
        self.rect.y = random.randrange(0,self.dimensions_grid,self.dimensions_apple) + 100

class Snake:

    def __init__(self, dimensions_grid, dimensions_snake_cell):
        self.dimensions_grid = dimensions_grid
        self.dimensions_snake_cell = dimensions_snake_cell
        self.headx = dimensions_grid//2 + 100
        self.heady = dimensions_grid//2 + 100
        self.head_rect = pygame.Rect(self.headx,self.heady,self.dimensions_snake_cell,self.dimensions_snake_cell)
        self.head_color = '#0b57d0'
        self.body_color = '#c3d9fb'
        self.body = [self.head_rect.topleft,
                     (self.headx + self.dimensions_snake_cell, self.heady),
                     (self.headx + (2*self.dimensions_snake_cell), self.heady)]
        self.last_move = 'left'
        self.last_position = ()

    def move_left(self):

        if self.last_move != 'right':
            self.head_rect.x -= self.dimensions_snake_cell
            self.body.insert(0, self.head_rect.topleft)
            self.last_position = self.body[-1]
            self.body.pop(-1)
            self.last_move = 'left'

    def move_right(self):
        if self.last_move != 'left':
            self.head_rect.x += self.dimensions_snake_cell
            self.body.insert(0, self.head_rect.topleft)
            self.last_position = self.body[-1]
            self.body.pop(-1)
            self.last_move = 'right'

    def move_up(self):
        if self.last_move != 'down':
            self.head_rect.y -= self.dimensions_snake_cell
            self.body.insert(0, self.head_rect.topleft)
            self.last_position = self.body[-1]
            self.body.pop(-1)
            self.last_move = 'up'

    def move_down(self):
        if self.last_move != 'up':
            self.head_rect.y += self.dimensions_snake_cell
            self.body.insert(0, self.head_rect.topleft)
            self.last_position = self.body[-1]
            self.body.pop(-1)
            self.last_move = 'down'


class Game:

    def __init__(self):
        screen_size = (1000,1000)
        pygame.display.set_caption("snake game")
        self.screen = pygame.display.set_mode((screen_size))
        self.running = True

        #taille de la grille
        self.grid_size = screen_size[0]-200
        self.cell_size = self.grid_size//10

        #mettre la pomme dans la classe game
        self.apple = Apple(self.grid_size,self.cell_size)
        #mettre le serpent dans la classe game
        self.snake = Snake(self.grid_size,self.cell_size)
        #verifie si la pomme est dans le serpent au demarage
        self.check_apple_in_snake()

        self.score = 0
        

        self.score_font = pygame.font.Font(None, 60)
        self.menu_font = pygame.font.Font(None,70)

        self.has_lost = False
        self.in_game = False

        self.mode = "medium"
        self.level = {
            "easy" : 0.002,
            "medium" : 0.005,
            "hard" : 0.01
        }
        self.levels_list = list(self.level.keys())

    def draw(self,screen):
        screen.fill((87, 138, 52))
        if self.in_game:
            self.draw_apple(self.screen)
            self.draw_snake(self.screen)
            pygame.draw.rect(screen,"black",(100,100,self.grid_size,self.grid_size),5)
            for x in range(0, self.grid_size, self.cell_size):
                for y in range(0, self.grid_size, self.cell_size):
                    rect = pygame.Rect(x+100, y+100, self.cell_size, self.cell_size)
                    pygame.draw.rect(screen, 'black', rect, 2)

    def draw_apple(self, screen):
        pygame.draw.rect(screen,self.apple.color,self.apple.rect)

    def draw_snake(self, screen):
        #dessine la tête du serpent
        pygame.draw.rect(screen,self.snake.head_color,
                         (self.snake.body[0][0],self.snake.body[0][1],
                           self.snake.dimensions_snake_cell, self.snake.dimensions_snake_cell))
        #dessine le corps du serpent sauf la tête
        for cell in self.snake.body[1:]:
            pygame.draw.rect(screen,self.snake.body_color,
                             (cell[0],cell[1], self.snake.dimensions_snake_cell,self.snake.dimensions_snake_cell))

    def check_apple_in_snake(self):
        # cette méthode fait en sorte que la pomme n'apparaisse pas dans le serpent
        while self.apple.rect.topleft in self.snake.body:
            self.apple.change_position()

    def check_apple_eating(self):
        if self.snake.head_rect.topleft == self.apple.rect.topleft:
            self.snake.body.append(self.snake.last_position)
            self.check_apple_in_snake()
            self.score += 1
            print(self.score)

            if self.score > int(self.best_score):
                print('record !!')
                self.change_best_score(self.score, self.mode)
                self.read_best_score()

    def has_lose(self):
        """
        le joueur perd si :
            1) le serpent sors de la grille
            2) la tête du serpent touche son corps
        """
        # cas 1
        if self.snake.head_rect.x < 100 or self.snake.head_rect.x >= self.grid_size + 100:
            self.has_lost = True
        elif self.snake.head_rect.y < 100 or self.snake.head_rect.y >= self.grid_size + 100:
            self.has_lost = True
        # cas 2
        elif self.snake.body.count(self.snake.head_rect.topleft) == 2:
            self.has_lost = True



    def move(self):
        if self.snake.last_move == 'left':
            self.snake.move_left()
        elif self.snake.last_move == 'right':
            self.snake.move_right()
        elif self.snake.last_move == 'up':
            self.snake.move_up()
        elif self.snake.last_move == 'down':
            self.snake.move_down()

    def read_best_score(self):
        with open('snake_final.txt', 'r+') as file:
            self.best_score = file.readlines()[self.levels_list.index(self.mode)][-3:].strip()
            print(self.best_score)
            file.close()

    def change_best_score(self, value, mode):
        with open('snake_final.txt', 'r+') as file:
            lines = file.readlines()
        with open('snake_final.txt', 'w+') as file:
            index = self.levels_list.index(self.mode)
            print(lines)
            lines[index] = f"best_score_{mode} : {value}\n"
            file.writelines(lines)
            file.close()

    def display_score(self,text, pos:tuple=(0,0)):
        text_score = self.score_font.render(str(text), True, 'black')
        self.screen.blit(text_score,pos)

    def display_menu(self, text, pos:tuple=(0,0)):
        text_menu = self.menu_font.render(str(text), True, 'black')
        self.screen.blit(text_menu,pos)

    
    def display_buttons(self):
        self.green_button = pygame.image.load('green button.png')
        self.green_button = pygame.transform.scale(self.green_button, (230,70))
        self.green_button_rect = self.green_button.get_rect()
        self.green_button_rect.topleft = (100,900)
        self.screen.blit(self.green_button, self.green_button_rect.topleft)
        self.display_menu("Facile", (146,910))

        self.yellow_button = pygame.image.load('yellow button.png')
        self.yellow_button = pygame.transform.scale(self.yellow_button, (230,70))
        self.yellow_button_rect = self.yellow_button.get_rect()
        self.yellow_button_rect.topleft = (385,900)
        self.screen.blit(self.yellow_button, self.yellow_button_rect.topleft)
        self.display_menu("Moyen", (425,910))

        self.red_button = pygame.image.load('red button.png')
        self.red_button = pygame.transform.scale(self.red_button, (230,70))
        self.red_button_rect = self.red_button.get_rect()
        self.red_button_rect.topleft = (670,900)
        self.screen.blit(self.red_button, self.red_button_rect.topleft)
        self.display_menu("Dificile", (706,910))

    def get_event(self):
        """Cette méthode sert à recupérer les evenement comme fermer la fenetre ou detecter si on veut changer la direction du serpent
        """
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT and self.snake.last_move != 'right' and self.in_game:
                    self.snake.last_move = "left"
                elif event.key == pygame.K_RIGHT and self.snake.last_move != 'left' and self.in_game:
                    self.snake.last_move = "right"
                elif event.key == pygame.K_UP and self.snake.last_move != 'down' and self.in_game:
                    self.snake.last_move = "up"
                elif event.key == pygame.K_DOWN and self.snake.last_move != 'up' and self.in_game:
                    self.snake.last_move = "down"
                elif event.key == pygame.K_RETURN:
                    self.in_game = True
                    self.read_best_score()

            if event.type == pygame.MOUSEBUTTONDOWN:
                (x,y) = event.pos 
                if self.green_button_rect.collidepoint(x,y):
                    print("easy")
                    self.mode = "easy"
                elif self.yellow_button_rect.collidepoint(x,y):
                    print("medium")
                    self.mode = "medium"
                elif self.red_button_rect.collidepoint(x,y):
                    print("hard")
                    self.mode = "hard"


    def game_loop(self):
        """ Cette méthode est la boucle du jeu
        elle permet de faire tourner le jeu
        """

        self.t = time.time()

        while self.running:

            self.draw(self.screen)

            self.get_event()
            if self.in_game:
                if time.time() - self.t >= 0.2 -self.score*self.level[self.mode]:
                    self.move()
                    self.t = time.time()

                self.check_apple_eating()
                self.has_lose()
                if self.has_lost:
                    print("lose")
                    self.running = False
                    #écran game over
                    game_over_image = pygame.image.load('game_over.png')
                    game_over_image = pygame.transform.scale(game_over_image, (1000,1000))
                    self.screen.blit(game_over_image,(0,0))
                    pygame.display.flip()
                    time.sleep(3)
                self.display_score(f"Score : {self.score}", (150,30))
                self.display_score(f"Meilleur score : {self.best_score}", (500,30))
            else:
                self.display_menu("Bienvenue au jeu du snake codé par Jed", (20,30))
                snake_image = pygame.image.load('snake.jpg')
                self.screen.blit(snake_image, (250, 100))
                self.display_menu("Appuyez sur enter pour jouer", (150,750))
                if self.mode == "easy":self.display_menu("en difficulté facile",(280,825))
                elif self.mode == "medium":self.display_menu("en difficulté moyenne",(250,825))
                elif self.mode == "hard":self.display_menu("en difficulté difficile",(255,825))
                self.display_buttons()
                
            pygame.display.flip()



game = Game()
game.game_loop()

print("vous avez perdu")
