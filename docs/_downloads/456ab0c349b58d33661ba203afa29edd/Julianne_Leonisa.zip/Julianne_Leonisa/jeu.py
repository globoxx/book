import pgzrun
from pgzhelper import *

from random import randint

TITLE = 'Hit the fly'

WIDTH = 800
HEIGHT = 600

# ajouter score, vie, coin, reset le perso quand il meurt, scren game over apparait quand le player meurt et you win quand on gagne, appupyer et le jeu revient au debut
# mouche attirer par le joueur
class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = 5
        self.vie = 3#vie
        self.game_over = False
        self.score = 0#nombre de fly toucher
        self.coin = 0#nombre de pièce
    def update(self):
        if keyboard.a:
            self.x -= self.speed
            self.flip_x = True
        if keyboard.d:
            self.x += self.speed
            self.flip_x = False

        if keyboard.w:
            self.y -= self.speed
        if keyboard.s:
            self.y += self.speed
        for money in moneys:#céation pièce
            if self.collides_with(money):
                print('WOW')
                money.to_remove = True
                player.coin += 1

    def reset(self):#quand on meurt le personnage rest dans ke jeu
        self.score= 0
        self.coin= 0
        self.vie = 3
        self.game_over = False

class Money(Actor) :
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ['bronze_1' ,'bronze_2', 'bronze_3']

class Ennemy(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ['fly1', 'fly2']
        self.direction = randint(0, 360)
        self.speed = 1

    def update(self):
        self.direction += randint(-10, 10)
        self.direction = self.angle_to(player)#les mouches sont attirés par le joueur
        self.move_in_direction(self.speed)
        if self.collides_with(player):
            player.vie -= 1
            if  player.vie == 0:
                player.game_over = True
                print("GAME OVER")
            self.to_remove = True

class Missile(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = 7

    def update(self):
        self.move_in_direction(self.speed)
        for ennemy in ennemies:
            if self.collides_with(ennemy):
                print('BOOOOM')
                ennemy.to_remove = True
                self.to_remove = True
                player.score += 1#si on touche le fly avec le missile, le score augmente de 1

def add_ennemy():
    ennemy = Ennemy('fly1', (randint(0, WIDTH), randint(0, HEIGHT)))
    ennemies.append(ennemy)
def add_money():
    money = Money('bronze_1', (randint(0, WIDTH), randint(0, HEIGHT)),width=50)
    moneys.append(money)

def on_mouse_down(pos):
    missile = Missile('missile', (player.x, player.y))
    missile.direction = player.angle_to(pos)
    missile.angle = missile.direction
    missiles.append(missile)


player = Player('alien_walk1', (WIDTH / 2, HEIGHT / 2))
ennemies = [Ennemy('fly1', (randint(0, WIDTH), randint(0, HEIGHT)))]
missiles = []
moneys = []
clock.schedule_interval(add_ennemy, 1.0)
clock.schedule_interval(add_money, 3.0)


def draw():
    screen.blit('cochon-2', (0, 0))
    player.draw()
    for ennemy in ennemies:
        ennemy.draw()
    for missile in missiles:
        missile.draw()
    for money in moneys:
        money.draw()
    if player.game_over:#quand joueur meurt game over apparait
        screen.fill((0, 0, 0, 255))
        screen.draw.text('Game Over', centerx=400, centery=270, color=(255,255,255), fontsize=60)
    screen.draw.text(f'vie: {player.vie}', (15, 10), color=(255, 255,255 ), fontsize=30)
    screen.draw.text(f'Score: {player.score}', (15, 50), color=(255, 255, 255), fontsize=30)
    screen.draw.text(f'Coin: {player.coin}', (15, 90), color=(255, 255, 255), fontsize=30)
    
    if player.coin == 10:
        screen.fill((208, 97, 238))
        screen.draw.text('YOU WIN', centerx=400, centery=270, color=(255, 255, 255), fontsize=60)

def update():
    if not player.game_over:
        player.update()
        for money in moneys:
            money.animate()
        for ennemy in ennemies:
            ennemy.update()
            ennemy.animate()
        for missile in missiles:
            missile.update()

    remove_actors(ennemies)
    remove_actors(missiles)
    remove_actors(moneys)
    if keyboard.p:#quand on appuie sur p le jeux se reset
        player.reset()

pgzrun.go()