import pgzrun
from pgzhelper import *

TITLE = 'Runner'

WIDTH = 800
HEIGHT = 600

pgzrun.go()