import pgzrun
import pgzero
from pgzero.keyboard import keyboard


from pgzhelper import *

TITLE = 'Runner'

WIDTH = 800
HEIGHT = 600

def draw():
    screen.blit('sevelin',(0,0))
    player.draw()
    player2.draw()
    obstacle.draw()

    screen.draw.text(f'Score:{player.score}', (15, 10), color=(0, 0, 0), fontsize=30)

    #Afficher les vies des joueurs en fonctions de leurs .life
    if player2.life > 1000:
        screen.draw.text('Vie Isaac: 200', (200, 10), color=(0, 0, 0), fontsize=30)
    elif player2.life == 1000:
        screen.draw.text('Vie Isaac: 100', (200, 10), color=(0, 0, 0), fontsize=30)
    elif player2.life > 0:
        screen.draw.text('Vie Isaac: 50', (200, 10), color=(0, 0, 0), fontsize=30)
    else:
        screen.draw.text('Isaac est mort !', (200, 10), color=(0, 0, 0), fontsize=30)


    if player.life > 1000:
        screen.draw.text('Vie Juliette: 200', (500, 10), color=(0, 0, 0), fontsize=30)
    elif player.life == 1000:
        screen.draw.text('Vie Juliette: 100', (500, 10), color=(0, 0, 0), fontsize=30)
    elif player.life > 0:
        screen.draw.text('Vie Juliette: 50', (500, 10), color=(0, 0, 0), fontsize=30)
    else:
        screen.draw.text('Juliette est morte !', (500, 10), color=(0, 0, 0), fontsize=30)



    #attendre que les deux meurent avant de finir le jeu
    if player.game_over and player2.game_over:
        screen.fill((0, 0, 0))
        screen.draw.text('Game Over', centerx=400, centery=270, color=(255,255,255), fontsize=60)
    


def update():
    if not player.game_over:
        if player.y == 500:
            player.animate(20)
        player.update()
    #monter le joueur lors du game_over et de l'image du fantome
    elif player.game_over:
        player.y -= 10
        if player.y < -10:
            player.y = -1000

    if not player2.game_over:
        if player2.y == 500:
            player2.animate(20)
        player2.update()
    elif player2.game_over:
        player2.y -= 10
        if player2.y < -10:
            player2.y = -1000
    
    obstacle.update()

class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = [ f'juliette__run00{i+1}'for i in range(10)]
        self.vy = 0
        self.game_over = False
        self.score = 0
        self.life = 1000
        
    def update(self):
        #augmenter les vies si le score passe à 10
        if self.score == 10:
            self.life = 1400
        self.y += self.vy
        self.vy += 1
        if self.y > 500:
            self.y = 500 
            self.vy = 0
            if keyboard.space:
                self.vy = -25
                sounds.jump.play()


            if self.collides_with(obstacle):
                self.life -= 100 #enlever des vies lors d'une collision
                if self.life == 0:
                    self.game_over = True
                    self.image = 'fantome.png' #changer l'image du personnage

class Player2(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = [ f'isaac__run00{i+1}'for i in range(9)]
        self.vy = 0
        self.game_over = False
        self.score = 0
        self.life = 1000

    def update(self):
        if self.score == 10:
            self.life = 1400
        self.y += self.vy
        self.vy += 1
        if self.y > 500:
            self.y = 500
            self.vy = 0
            if keyboard.e:
                self.vy = -25
                sounds.jump.play() #bruit de saut


            if self.collides_with(obstacle):
                self.life -= 100
                if self.life == 0:
                    self.game_over = True
                    self.image = 'fantome.png'

class Obstacle(Actor):
        def __init__(self, image, pos, **kwargs):
            super().__init__(image, pos, **kwargs)

        def update(self):
            self.x -= 10 + player.score // 2 #augmentation de la vitesse des obstacles en fonction du score de Player
            if self.x <-50:
                self.x = 850
                player.score += 1
                player2.score += 1

obstacle = Obstacle('luan', (850,430))
player = Player('juliette__run001', (170,500),width= 150)
player2 = Player2('isaac__run001', (140,500),width= 150)
music.play('son_jeu') #musique de fond


pgzrun.go()