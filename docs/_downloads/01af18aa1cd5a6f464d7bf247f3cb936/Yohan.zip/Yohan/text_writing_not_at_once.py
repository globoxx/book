import sys
import time
sys.stdout.write("\033[?25h")  #show cursor
sys.stdout.flush()
def writing(text, delay_after):
    for i in text:
        sys.stdout.write(i)
        sys.stdout.flush()
        time.sleep(0.05)
    time.sleep(delay_after)
writing("Hello World!\n", 2)
writing("How are you?\n", 2)
writing("I'm fine, thank you!\n", 2)