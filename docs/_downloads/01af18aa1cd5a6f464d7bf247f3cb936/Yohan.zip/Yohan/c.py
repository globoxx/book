import curses
import time

def main(stdscr):
    # Effacer l'écran initialement
    stdscr.clear()

    # Affiche une ligne
    stdscr.addstr(0, 0, "Cette ligne sera effacée...")
    stdscr.refresh()  # Met à jour l'affichage
    time.sleep(1)

    # Effacer la ligne
    stdscr.addstr(0, 0, " " * 25)  # Réécrire sur la même ligne avec des espaces
    stdscr.refresh()  # Met à jour l'affichage
    time.sleep(1)

    # Afficher une nouvelle ligne
    stdscr.addstr(0, 0, "Nouvelle ligne affichée.")
    stdscr.refresh()  # Met à jour l'affichage
    time.sleep(1)

    stdscr.getch()  # Attendre une touche avant de quitter

# Lancer le programme curses
curses.wrapper(main)