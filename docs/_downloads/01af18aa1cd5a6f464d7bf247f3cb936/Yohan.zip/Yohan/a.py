import random
liste = ",.-§$¨^'<>;:_≤¥≈©√∫~µ«…–≥Ÿ™◊˙˚»÷—åß∂ƒ@ªº∆¬¢æ¶Åﬁﬂ‡‚·˜¯ˆ˘Æ•ŒÁËÈÎÍÙıØ∏’∑€®†Ω°¡øπ§‘±“#Ç[]|{}≠¿´ﬁ∞”‹⁄[]\"
print(len(liste))
print(liste[1])
print(liste[random.randint(0, 99)])()