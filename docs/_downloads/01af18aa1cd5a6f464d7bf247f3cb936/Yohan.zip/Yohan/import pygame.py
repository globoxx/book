import pygame
import time

# Initialize pygame mixer
pygame.mixer.init()

# Load and play music
pygame.mixer.music.load("C:\\Users\\yohac\\Downloads\\OneDrive_2025-03-22\\histoire interactive_info\\ytmp3free.cc_starset-satellite-official-audio-youtubemp3free.org.mp3")  # Replace with your file path
pygame.mixer.music.play(-1)  # -1 makes it loop indefinitely

# Count numbers while music is playing
for i in range(1, 11):  # Count from 1 to 10
    print(f"Counting: {i}")
    time.sleep(1)  # Wait 1 second between counts

# Stop music after counting
pygame.mixer.music.stop()
print("Music stopped.")