import threading
import time
import random
import sys
from colorama import *
import pygame

# Initialize pygame mixer
pygame.mixer.init()

# Function to monitor music playback
def wait_for_music_to_end():
    while pygame.mixer.music.get_busy():
        time.sleep(0.1)  # Check every 100ms if the music is still playing
    print(Fore.GREEN + "Music finished.")

# Opening function
def opening():
    pygame.mixer.music.load("C:\\Users\\yohac\\Downloads\\OneDrive_2025-03-22\\histoire interactive_info\\ytmp3free.cc_starset-satellite-official-audio-youtubemp3free.org.mp3")
    pygame.mixer.music.play(0)
    sys.stdout.write("\033[?25l")
    for i in range(5):
        sys.stdout.write(Style.BRIGHT + Fore.CYAN + "\t\tIt's only your echo")
        sys.stdout.flush()
        time.sleep(random.choice([0.1, 0.2, 0.3, 0.4, 0.5]))
        sys.stdout.write("\r")
        sys.stdout.write(Style.NORMAL + Fore.CYAN + "\t\tIt's only your echo")
        sys.stdout.flush()
        time.sleep(random.choice([0.1, 0.2, 0.3, 0.4, 0.5]))
        sys.stdout.write("\r")
    sys.stdout.write("\033[?25h")
    sys.stdout.write("\t\t\t\t\r                                                                                           \n")

# Example of another action
def perform_other_actions():
    for i in range(1, 6):
        print(Fore.YELLOW + f"Performing action {i}...")
        time.sleep(1)  # Simulate some work

# Main program
opening()

# Start the music monitoring in a separate thread
music_thread = threading.Thread(target=wait_for_music_to_end)
music_thread.start()

# Perform other actions while the music is playing
perform_other_actions()

# Wait for the music thread to finish before exiting
music_thread.join()
print(Fore.CYAN + "Program finished.")