import sys
import time

# Afficher un message
sys.stdout.write("Affichage de la ligne")
sys.stdout.flush()  # Forcer l'affichage immédiat
time.sleep(1)  # Attendre 1 seconde
sys.stdout.write("\r")
sys.stdout.write("New line")