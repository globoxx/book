import random
import time

# Liste de caractères aléatoires que tu peux utiliser
ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()"


# Fonction pour générer un texte avec des caractères aléatoires
def randomize_text(original_text):
    randomized_text = []
    for _ in range(10):
        temp_text = ''.join(random.choice(ALPHABET) for _ in original_text)
        time.sleep(0.5)
        print(temp_text, "\r")
    print(original_text)

text = "Voici du texte aléatoire!"

randomize_text(text)