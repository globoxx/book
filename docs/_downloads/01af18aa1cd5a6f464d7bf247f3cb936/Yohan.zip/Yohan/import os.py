import os

def clear_terminal():
    os.system('cls' if os.name == 'nt' else 'clear')
print("Du texte que je vais effacer...")
input("Appuie sur Entrée pour tout effacer...")
clear_terminal()
print("L'ancien texte a disparu.")