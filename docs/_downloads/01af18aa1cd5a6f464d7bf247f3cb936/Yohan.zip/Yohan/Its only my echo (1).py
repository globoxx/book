import time
import random
import sys
from colorama import *
import pygame
import os
inventory = []
random_characters = [".", "*", "-", ",", ".", "§", "$", "¨", "^", "'", "<", ">", ";", ":", "_", "≤", "¥", "≈", "©", "√", "∫", "~", "µ", "«", "…", "–", "≥", "Ÿ", "™", "◊", "˙", "˚", "»", "÷", "—", "å", "ß", "∂", "ƒ", "@", "ª", "º", "∆", "¬", "¢", "æ", "¶", "Å", "ﬁ", "ﬂ", "‡", "‚", "·", "˜", "¯", "ˆ", "˘", "Æ", "•", "Œ", "Á", "Ë", "È", "Î", "Í", "Ù", "ı", "Ø", "∏", "’", "∑", "€", "®", "†", "Ω", "°", "¡", "ø", "π", "§", "‘", "±", "“", "#", "Ç", "[", "]", "|", "{", "}", "≠", "¿", "´", "ﬁ", "∞", "”", "‹", "⁄", "[", "]", "\\", ""]
window_done = False
door_done = False
room_done = False
wall_done = False
dev = input("Wanna go in dev mode ? (y/n) : ")
music = input("Wanna play music ? (y/n) : ")
if dev == "y":
    developpement = True
else:
    developpement = False
if music == "y":
    play = True
else:
    play = False
pygame.mixer.init()
pygame.mixer.music.load("ytmp3free.cc_starset-echo-official-music-video-youtubemp3free.org.mp3")
x = 0
#---------------------------------------------------------
# functions definitions
#----------------------------
def go_sleep():
    global window_done
    global door_done
    global room_done
    global room_done
    if wall_done == True and room_done == True and window_done == True and door_done == True:
        write(Fore.CYAN + "\nHe decided to go back to sleep, he was too tired to continue.", 1)
        write(Fore.CYAN + "\nHe closed his eyes and tried to forget everything that happened.", 1)
        write(Fore.CYAN + "\nHe knew that he would have to face it again, but for now, he just wanted to sleep.", 1)
        write(Fore.CYAN + "\nHe hoped that when he woke up, everything would be back to normal.", 1)
        write(Fore.MAGENTA + "\nBut deep down, he knew that nothing would ever be the same again.", 1)
        write(Fore.MAGENTA + "\nHe was an echo now, and echoes never truly fade away.", 1)
        sys.exit()
    else:
        write(Fore.CYAN + "\nHe just went back to sleep and woke up in his bed, in his own dimension. It was just a dream.",1)
        write(Fore.CYAN + "\nBut during the night, something happend, something that only himself can explain, something untouchable, something attractive but something that can't be reached.",1)
        write(Fore.CYAN + "\nA dream, not exactly : a nightmare. His nightmare was this : he woke up in another dimension and got through painful things.",1)
        write(Fore.CYAN + "\nAfraid, he woke up suddenly.", 1)
        write(Fore.MAGENTA + "\nAnd as every story has an end, this is not where ours ends : he was projected through another dimension.",1)
        write(Fore.MAGENTA + "\nHis nightmare becoming true, this part of reality becoming an echo, fracturing, collapsing into itself.",1)
        window_done = False
        door_done = False
        room_done = False
        time.sleep(3)
        loading()
        here_it_begins()
#----------------------------
def clear_terminal():
    os.system('cls')
#----------------------------
def opening():
    loading()
    if play == True:
        pygame.mixer.music.play(-1)
    else:
        pass
    clear_terminal()
    for i in range(5):
        sys.stdout.write("\033[?25l")
        sys.stdout.flush()
        sys.stdout.write(Style.BRIGHT + Fore.CYAN + "\t\tIt's only your echo")
        sys.stdout.flush()
        time.sleep(random.choice([0.1, 0.2, 0.3, 0.4, 0.5]))
        sys.stdout.write("\r")
        sys.stdout.write(Style.NORMAL + Fore.CYAN + "\t\tIt's only your echo")
        sys.stdout.flush()
        time.sleep(random.choice([0.1, 0.2, 0.3, 0.4, 0.5]))
        sys.stdout.write("\r")
    sys.stdout.write("\033[?25h")
    sys.stdout.write("\n")
    loading()
    here_it_begins()
#----------------------------
def tilting(tilt_delay, loops):
    for i in range(loops):
        sys.stdout.write("\033[?25h")
        sys.stdout.flush()
        time.sleep(tilt_delay)
        sys.stdout.write("\033[?25l")
        sys.stdout.flush()
        time.sleep(tilt_delay)
    sys.stdout.write("\033[?25h")
    sys.stdout.flush()
#----------------------------
def laggy_text(char_lenght, loops):
    sys.stdout.write("\033[?25l")  #hides cursor
    sys.stdout.flush()
    for loops in range(loops):
        for i in range(char_lenght):
            char = random.choice(random_characters)
            sys.stdout.write(Fore.RED + char)
            sys.stdout.flush()
            time.sleep(0.001)
        sys.stdout.write("\r")
    for i in range(char_lenght):
            char = random.choice(random_characters)
            sys.stdout.write(Fore.RED + char)
            sys.stdout.flush()
            time.sleep(0.001)
    sys.stdout.write("\033[?25h")  #shows cursor
    sys.stdout.flush()
#----------------------------
def hide_cursor():
    sys.stdout.write("\033[?25l")  #hides cursor
    sys.stdout.flush()
#----------------------------
def show_cursor():
    sys.stdout.write("\033[?25h")  #shows cursor
    sys.stdout.flush()
#----------------------------
def write(text, delay_after):
    if developpement == False:
        sys.stdout.write("\033[?25h")
        for nmbr_of_chars in text:
            sys.stdout.write(nmbr_of_chars)
            sys.stdout.flush()
            time.sleep(0.05)
        the_delay_with_tilt = delay_after / 2
        tilting(the_delay_with_tilt, 2)
    else:
        print(text)
#----------------------------
def loading():
    global x
    x = 0
    clear_terminal()
    sys.stdout.write("\033[?25l")  #hides cursor
    sys.stdout.flush()
    sys.stdout.write("\n")
    for i in range(random.randint(2, 4)):
        x = x + random.randint(16,23)
        print(Fore.RED + "Loading...", x, "%", end="\r")
        time.sleep(random.choice([0.5, 0.75, 1, 1.25, 1.5]))
    sys.stdout.write("               \r")
    laggy_text(11, 75)
    sys.stdout.write("               \r")
    x = 0
    sys.stdout.write("\033[?25l")  #hides cursor
    sys.stdout.flush()
    for i in range(random.randint(2, 4)):
        x = x + random.randint(16,23)
        print(Fore.RED + "Loading...", x, "%", end="\r")
        time.sleep(random.choice([0.5, 0.75, 1, 1.25, 1.5]))
    sys.stdout.write("               \r")
    laggy_text(11, 35)
    sys.stdout.write("               \r")
    sys.stdout.write("\033[?25l")  #hides cursor
    sys.stdout.flush()
    print(Fore.RED + "Loading...", 100, "%", end="\r")
    time.sleep(1)
    sys.stdout.write("\033[?25h")  #shows cursor
    sys.stdout.flush()
    clear_terminal()
#----------------------------
def here_it_begins():
    write(Fore.CYAN + Style.BRIGHT + "When he woke up he had the strange feeling that something was wrong.", 1)
    write(Fore.MAGENTA + "\nThe thing he didn't know, little he was, is that he were actually not in his world anymore.", 1)
    write(Fore.LIGHTYELLOW_EX + "\nAnd why wasn't he in his world ?", 1)
    write(Fore.CYAN + "\nBecause he is what we call an echo.", 1)
    write(Fore.CYAN + "\nA shadow stitched between worlds, the Echoes drift through dimensions like ghosts through walls.", 1)
    write(Fore.CYAN + "\nReality warps around their presence; every step leaves a fracture. They don’t travel — they haunt, carrying the weight of countless versions of truth, none of them whole.", 1)
    write(Fore.CYAN + "\nThey are the whispers of what could have been, the shadows of what should have been, and the echoes of what will never be.", 1)
    write(Fore.CYAN + "\nThey are the remnants of a world that never was, the shadows of a reality that never existed.", 1)
    write(Fore.CYAN + "\nThey are you, they are me, they are all of us, they know all of us, they are the void, they are the matter, they are the truth, they are the echo that answers when nothing is left to call yourself.", 1)
    write(Fore.MAGENTA + "\nCalm down babe, we are trying to get him asleep, not giving him nightmares.", 1)
    write(Fore.MAGENTA +  "\nSo, as I was saying : He looked around and saw that he was in a room that he didn't recognize. He got up and looked around.", 1)
    write(Fore.MAGENTA + " \nHe saw a door right in front of him and a window on his right.", 1)
    choice_begin()
#----------------------------
def another_dimension_door():
    clear_terminal()
    global door_done
    if "key" in inventory and door_done == False:
        door_done = True
        write(Fore.CYAN + Style.BRIGHT + "He opened the door and walked through it.", 1)
        write(Fore.CYAN + "\nThe moment he stepped through the door seemed to be an eternity, reduced in a second.", 1)
        write(Fore.CYAN + "\nOne moment, he was there — breathing, blinking, real. The next, the world folded in on itself like burnt paper, edges curling into ash. No divine light, no booming voice. Just absence — sudden, absolute.", 1)
        write(Fore.MAGENTA + "\nHe opened his eyes to a sky that shouldn’t exist — ink-black, veined with cracks of pale red light that moved like they were alive.", 1)
        write(Fore.MAGENTA + "\nThe ground beneath him felt wrong, soft yet brittle, like walking on dried skin.", 1)
        write(Fore.MAGENTA + "\nTowers in the distance swayed as if breathing, and shadows moved without anything to cast them.", 1)
        write(Fore.MAGENTA + "\nIt wasn’t a place.", 1)
        write(Fore.CYAN + "\nIt was a wound.", 1)
        write(Fore.CYAN + "\nAnd he was inside it. He didn’t know how long he stood there — minutes, hours, years. Time here didn't pass : it stared.", 1)
        write(Fore.CYAN + "\nThe air was heavy with something ancient and watching, and though he was alone, he was never unseen.", 1)
        write(Fore.CYAN + "\nEvery breath felt borrowed. Every step, judged.", 1)
        write(Fore.CYAN + "\nHe walked, drawn forward by instinct, or maybe something else — a pull, low and patient, tugging at the core of him like a hook in the soul.", 1)
        write(Fore.MAGENTA + "\nThen the sky screamed.", 1)
        write(Fore.MAGENTA + "\nNo sound ; a memory. His own — twisted, distorted, played back in fragments: laughter he barely remembered, faces lost to time, regrets whispered in voices that weren’t quite his.", 1)
        write(Fore.MAGENTA + "\nThe world around him cracked again. The red veins above split wide like open eyes.", 1)
        write(Fore.CYAN + "\nAnd the pull became a yank.", 1)
        write(Fore.CYAN + "\nThe ground shattered beneath him, not with force — with rejection. This place had seen him, and it didn’t want him anymore. Or worse — it had taken what it needed.", 1)
        write(Fore.CYAN + "\nThe fall wasn’t physical. It was a collapse inward, like falling through the hollow of his own chest.", 1)
        write(Fore.MAGENTA + "\nWhen he landed, it was somewhere else. Somewhere colder. Dim light, flickering.", 1)
        write(Fore.MAGENTA + "\nA place that remembered him, even though he’d never been there before.", 1)
        write(Fore.MAGENTA + "\nAnd something was waiting.", 1)
        write(Fore.CYAN + "This place had no name. Or perhaps it had too many. It wasn’t a realm, or a dream, or a hell — it was a fractured reflection, an echo of a world that was never meant to survive.", 1)
        write(Fore.CYAN + "\nAnd it had felt him.", 1)
        write(Fore.MAGENTA + "\nSomething in his bones, in his blood, in what he thought was memory — didn’t belong. This place recognized him for what he was: a fracture, a body out of tune with its own reality.", 1)
        write(Fore.MAGENTA + "\nHe wasn’t the first to come here. But the others… they had never left.", 1)
        write(Fore.MAGENTA + "\nFaces would sometimes appear in the cracks of the sky. Too blurry to be real, too sharp to ignore.", 1)
        write(Fore.CYAN + "\nThey whispered things he didn’t yet understand — but would, all too soon.", 1)
        write(Fore.CYAN + "\nHe didn’t fight. He didn’t flee. He endured.", 1)
        write(Fore.CYAN + "\nUntil the place decided.", 1)
        write(Fore.CYAN + "\nUntil he was… too human. Too stable. Too broken.", 1)
        write(Fore.MAGENTA + "\nThen, the ground opened one last time.", 1)
        write(Fore.MAGENTA + "\nNot violently. More like an exhale.", 1)
        write(Fore.MAGENTA + "\nLike a sigh.", 1)
        write(Fore.CYAN + "\nEverything faded. The sky, the ground, the distant towers. Even the silence.", 1)
        write(Fore.CYAN + "\nThen: fabric.", 1)
        write(Fore.MAGENTA + "\nA familiar texture beneath his fingers. A dark room, but a real one. The scent of sheets. The distant sound of a car outside.", 1)
        write(Fore.MAGENTA + "\nHis bed. His home.", 1)
        write(Fore.CYAN + "\nBut he didn’t sit up. He didn’t even blink. He just lay there, motionless, barely breathing.", 1)
        write(Fore.MAGENTA + "\nBecause it wasn’t a dream.", 1)
        write(Fore.MAGENTA + "\nBecause he remembered everything.", 1)
        write(Fore.MAGENTA + "\nBecause somewhere, that place still existed — and now he knew he could go back.", 1)
        write(Fore.MAGENTA + "\nOr worse: that it could come back for him.", 1)
        write(Fore.MAGENTA + "\nHe didn't want to continue, he was still in his bed, afraid of himself.", 1)
        write(Fore.MAGENTA + "\nHe wanted to go back to sleep, but he had no choice.", 1)
        write(Fore.CYAN + "\nSomething was calling him, and he was afraid of this something.", 1)
        write(Fore.CYAN + "\nHe was afraid of that reality, that is his, by being a reality among the others.", 1)
        write(Fore.CYAN + "\nThe adrenaline was too strong, the excitement of this adventure couldn't hold him back from discovering a harsh truth, the ultimate one.", 1)
        choice_begin()
    elif door_done == False and room_done == False:
        write(Fore.CYAN + "\nHe walked to the door, but it was locked.", 1)
        write(Fore.GREEN + "\nYou should look for a key or something like that.", 1)
        choice_begin()
    else:
        write(Fore.CYAN + "\nHe wanted to go to the door again, but it was not here anymore.", 1)
        write(Fore.MAGENTA + "\nHe somehow still felt the presence of what is behind, and got scared, so he advised himself and told himself not to get close to it.", 1)
        choice_begin()
#----------------------------
def another_dimension_window():
    clear_terminal()
    global window_done
    if window_done == False:
        window_done = True
        write(Fore.CYAN + Style.BRIGHT + "He lay awake, eyes fixed on the ceiling, waiting for something.", 1)
        write(Fore.CYAN + "\nHe didn’t know what — but whatever had pulled him before, it wasn’t done.", 1)
        write(Fore.CYAN + "\nHe could feel it in his bones, in the way the silence pressed against his chest like a hand.", 1)
        write(Fore.MAGENTA + "\nThat’s when he noticed the window.", 1)
        write(Fore.MAGENTA + "\nIt was open.", 1)
        write(Fore.MAGENTA + "\nHe never left it open.", 1)
        write(Fore.MAGENTA + "\nHe never even opened it.", 1)
        write(Fore.CYAN + "\nThe curtain swayed, soft and slow, even though there was no wind.", 1)
        write(Fore.CYAN + "\nAnd outside, instead of the usual alley behind his building, there was… nothing.", 1)
        write(Fore.MAGENTA + "\nNo brick walls. No fire escapes. Just a void.", 1)
        write(Fore.MAGENTA + "\nThick, dark, endless — but not empty.", 1)
        write(Fore.MAGENTA + "\nIt moved.", 1)
        write(Fore.CYAN + "\nShapes in the dark. Some slow. Some sudden. None human.", 1)
        write(Fore.CYAN + "\nHe stepped closer. He didn’t want to.", 1)
        write(Fore.CYAN + "\nBut his body moved, heavy with the kind of dread that comes not from fear, but from recognition.", 1)
        write(Fore.CYAN + "\nHe took another step, but the floor felt soft — wrong, like carpet soaked in something warm.", 1)
        write(Fore.CYAN + "\nHis breath caught. Not from fear, but instinct. Something was about to shift.", 1)
        write(Fore.MAGENTA + "\nThe window shimmered.", 1)
        write(Fore.MAGENTA + "\nNot glass. Not anymore.", 1)
        write(Fore.MAGENTA + "\nIt rippled like water, dark and trembling, and something inside it leaned forward.", 1)
        write(Fore.CYAN + "\nNot a reflection. Not him. Something close. Something trying to be him.", 1)
        write(Fore.CYAN + "\nIts face blurred at the edges, like a bad memory, or a dream he’d half-forgotten.", 1)
        write(Fore.MAGENTA + "\nAnd it was mouthing words.", 1)
        write(Fore.MAGENTA + "\nOver and over, lips moving slow — deliberate — soundless.", 1)
        write(Fore.CYAN + "\nHe leaned in, trying to understand.", 1)
        write(Fore.CYAN + "\nThe thing stopped. Tilted it's head. Smiled wide enough to crack.", 1)
        write(Fore.MAGENTA + "\nThen the surface of the window bulged, like something behind it had pressed its face too close.", 1)
        write(Fore.MAGENTA + "\nAnd he realized — it wasn’t trying to speak.", 1)
        write(Fore.MAGENTA + "\nIt was trying to breathe.", 1)
        write(Fore.CYAN + "\nThat was when the first crack appeared — not in the glass, but in the air beside him.", 1)
        write(Fore.CYAN + "\nThin. Jagged. Glowing faintly red.", 1)
        write(Fore.CYAN + "\nThe crack widened, jagged and bright, as though the air itself was being torn apart.", 1)
        write(Fore.CYAN + "\nA faint humming sound filled the room — not from the crack, but from *inside* it.", 1)
        write(Fore.MAGENTA + "\nIt wasn’t a sound that belonged to the world he knew.", 1)
        write(Fore.MAGENTA + "\nThe air felt thick, like it was filled with static, as if the fabric of space itself had become unstable.", 1)
        write(Fore.MAGENTA + "\nHe couldn’t look away. His feet were frozen, his breath caught in his throat.", 1)
        write(Fore.CYAN + "\nThe crack pulsed now, like a heartbeat — slow, rhythmic, inevitable.", 1)
        write(Fore.MAGENTA + "\nAnd then, just as his mind screamed for him to move, a shape began to emerge from the rift.", 1)
        write(Fore.CYAN + "\nIt was long and indistinct, more a blur than a form, stretching unnaturally, pulling itself through the gap.", 1)
        write(Fore.CYAN + "\nA twisted limb, or was it a tendril? It moved with a liquid grace, but the wrong kind — like something ”alive” but dead.", 1)
        write(Fore.CYAN + "\nThe figure began to take shape, dark and monstrous, its features not fully formed, but still there — something that was both him and not him.", 1)
        write(Fore.MAGENTA + "\nThe thing reached out, and the air around it seemed to fold, the walls distorting as if the room was bending to let it pass.", 1)
        write(Fore.MAGENTA + "\nIt spoke, but the words were not words — they were like a thought, an invasion of his mind.", 1)
        write(Fore.MAGENTA + "\n”Come with me.”", 1)
        write(Fore.CYAN + "\nThe voice was a whisper, but it carried weight — the weight of a thousand lives, of every regret, every secret.", 1)
        write(Fore.MAGENTA + "\nHe didn’t have to move for it to know him. For it to recognize him.", 1)
        write(Fore.MAGENTA + "\nAnd just like that, the crack began to close, dragging him toward it, as if it was no longer a choice.", 1)
    else :
        write(Fore.CYAN + "\nHe wanted to go to the window again, but it was not here anymore.", 1)
        write(Fore.MAGENTA + "\nHe somehow still felt the presence of what is behind, and got scared, so he advised himself and told himself not to get close to it.", 1)
    choice_begin()
#----------------------------
def look_in_room():
    clear_terminal()
    global room_done
    global wall_done
    room_done = True
    if "key" in inventory:
        write(Fore.CYAN + "\nHe looked around the room and found nothing.", 1)
        write(Fore.MAGENTA + "\nHe already took the key earlier, but something got his attention, something he didn't notice.", 1)
        write(Fore.CYAN + "\nHe looked at the wall and saw a strange symbol.", 1)
        write(Fore.CYAN + "\nHe touched it and it glowed.", 1)
        write(Fore.MAGENTA + "\nHe felt a strange energy coming from it.", 1)
        write(Fore.CYAN + "\nHe felt like being watched, but being the one watching.", 1)
        write(Fore.MAGENTA + "\nSuddently, the symbol changed, it warped, it pulsed. It repulsed the echo. He fell on the floor. It left it stunned for a while, then he just stood up.", 1)
        wall_done = True
        choice_begin()
    else :
        room_done == True
        write(Fore.CYAN + "\nHe looked around the room and found a key on the floor.", 1)
        write(Fore.CYAN + "\nHe picked it up and put it in his pocket.", 1)
        inventory.append("key")
        choice_begin()
#----------------------------
def choice_begin():
    global window_done
    global door_done
    global room_done
    if window_done == False and door_done == False and room_done == False:
        write(Fore.LIGHTYELLOW_EX + "\nWhat did he do then ?", 1)
        write(Fore.GREEN + "\n\t1. Go to the door", 1)
        write(Fore.GREEN + "\n\t2. Go to the window", 1)
        write(Fore.GREEN + "\n\t3. Look around the room", 1)
        write(Fore.GREEN + "\n\t4. Go back to sleep", 1)
    elif window_done == True and door_done == False and room_done == False:
        write(Fore.LIGHTYELLOW_EX + "\nWhat did he decided to do ?", 1)
        write(Fore.GREEN + "\n\t1. Go to the door", 1)
        write(Fore.GREEN + "\n\t3. Look around the room", 1)
        write(Fore.GREEN + "\n\t4. Go back to sleep", 1)
    elif window_done == False and door_done == True and room_done == False:
        write(Fore.LIGHTYELLOW_EX + "\nWHat has he done ?", 1)
        write(Fore.GREEN + "\n\t2. Go to the window", 1)
        write(Fore.GREEN + "\n\t3. Look around the room", 1)
        write(Fore.GREEN + "\n\t4. Go back to sleep", 1)
    elif window_done == False and door_done == False and room_done == True:
        write(Fore.LIGHTYELLOW_EX + "\nWhich way has he turned ?", 1)
        write(Fore.GREEN + "\n\t1. Go to the door", 1)
        write(Fore.GREEN + "\n\t2. Go to the window", 1)
        write(Fore.GREEN + "\n\t4. Go back to sleep", 1)
    elif window_done == False and door_done == True and room_done == True:
        write(Fore.LIGHTYELLOW_EX + "\nWhere did he go ?", 1)
        write(Fore.GREEN + "\n\t2. Go to the window", 1)
        write(Fore.GREEN + "\n\t4. Go back to sleep", 1)
    elif window_done == True and door_done == False and room_done == True:
        write(Fore.LIGHTYELLOW_EX + "\nWhich path did he take ?", 1)
        write(Fore.GREEN + "\n\t1. Go to the door", 1)
        write(Fore.GREEN + "\n\t4. Go back to sleep", 1)
    elif window_done == True and door_done == True and room_done == False:
        write(Fore.LIGHTYELLOW_EX + "\nWhat did he do ?", 1)
        write(Fore.GREEN + "\n\t3. Look around the room", 1)
        write(Fore.GREEN + "\n\t4. Go back to sleep", 1)
    elif window_done == True and door_done == True and room_done == True:
        write(Fore.LIGHTYELLOW_EX + "\nDid he just crawl under the bed or did he do something unexpected ?", 1)
        write(Fore.GREEN + "\n\t4. Go back to sleep", 1)
    choice = input(Fore.GREEN + "\n\tEnter your choice: ")
    if choice == "1" and door_done == False:
        another_dimension_door()
    elif choice == "1" and door_done == True:
        write(Fore.RED + "\nHe wanted to go to the door again, but it was not here anymore.", 1)
        write(Fore.MAGENTA + "\nHe somehow still felt the presence of what is behind, and got scared, so he advised himself and told himself not to get close to it.", 1)
        choice_begin()
    elif choice == "2" and window_done == False:
        another_dimension_window()
    elif choice == "2" and window_done == True:
        write(Fore.RED + "\nHe wanted to go to the window again, but it was closed", 1)
        write(Fore.MAGENTA + "\nHe remebered of what was behind, that voice, that breath. Closed, it was better like this.", 1)
        choice_begin()
    elif choice == "3" and wall_done == False:
        look_in_room()
    elif choice == "3" and wall_done == True:
        write(Fore.RED + "\nHe wanted to look at this symbol again. Vanished. Gone. Like an echo. He somehow still saw the shape of it on the wall. That eye. That smile.", 1)
        write(Fore.MAGENTA + "\nIt was not there. Not there ? Not there.", 1)
        choice_begin()
    elif choice == "4":
        go_sleep()
    else:
        write(Fore.RED + "\nInvalid choice. Try again.", 1)
        choice_begin()
#---------------------------------------------------------
# functions calls
opening()