import pgzero
import pgzrun
from pgzhelper import *

TITLE = 'Titre du jeu'
WIDTH = 800
HEIGHT = 600

pgzrun.go()