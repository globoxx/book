import pygame
import sys
import math
import os
from typing import List
import ast
import socket
from multiplayer import server
import json
import atexit
import heapq

def draw_fps(screen, clock):
    fps = int(clock.get_fps())
    fps_text = fps_font.render(f"FPS: {fps}", True, (0, 0, 0))
    screen.blit(fps_text, (10, 580))

class InputBox:
    def __init__(self, x, y, w, h, color_active, color_inactive, text='', title='', input_type="text"):
        self.rect = pygame.Rect(x, y, w, h)
        self.color = color_inactive
        self.text = text
        self.txt_surface = font.render(text, True, (0, 0, 0))
        self.active = False
        self.color_active = color_active
        self.color_inactive = color_inactive
        self.title = title
        self.title_surface = font.render(title, True, (0, 0, 0)) if title else None
        self.input_type = input_type  # "text" or "number"
        self.error_message = ""

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.active = not self.active
            else:
                self.active = False
            self.color = self.color_active if self.active else self.color_inactive
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                else:
                    if self.input_type == "number":
                        if event.unicode.isdigit():
                            self.text += event.unicode
                    else:
                        self.text += event.unicode
                self.txt_surface = font.render(self.text, True, (0, 0, 0))

    def update(self):
        width = max(200, self.txt_surface.get_width()+10)
        self.rect.w = width

    def draw(self, screen):
        if self.title_surface:
            title_rect = self.title_surface.get_rect(midbottom=(self.rect.centerx, self.rect.top - 5))
            screen.blit(self.title_surface, title_rect)
        screen.blit(self.txt_surface, (self.rect.x+5, self.rect.y+5))
        pygame.draw.rect(screen, self.color, self.rect, 2)
        if self.error_message:
            error_surface = font.render(self.error_message, True, (255, 0, 0))
            error_rect = error_surface.get_rect(midtop=(self.rect.centerx, self.rect.bottom + 5))
            screen.blit(error_surface, error_rect)

class Car:
    def __init__(self, name, pos_x=0, pos_y=0, scale_image = 0.2, player=None):
        self.car_x = pos_x
        self.car_y = pos_y
        self.speed_x = 0
        self.speed_y = 0
        self.c_angle = 0
        self.heading_theta = 0
        self.length = 3.2
        self.acc = 6
        self.steering_angle = 0
        self.bre = -8
        self.res_motor = -2
        self.str_angle = 3
        self.str_angle_back = 6
        self.direction = 1
        self.player_name = name
        self.start_time = None
        self.laps_time = []
        self.is_passing_finish = False
        self.has_finished = False
        self.r_pressed_last_frame = False
        if player is None:
            self.cam_x = 0
            self.cam_y = 0
            self.player = self
            self.player_bool = True
        else:
            self.player = player
            self.player_bool = False
            self.prev_x = self.car_x
            self.prev_y = self.car_y
            self.target_x = self.car_x
            self.target_y = self.car_y
            self.interp_timer = 0.0
            self.interp_duration = 0.16

        self.wheel_left_image = pygame.image.load(os.path.join("img", "wheel_left-re.png"))
        self.wheel_right_image = pygame.image.load(os.path.join("img", "wheel_right-re.png"))
        self.car_image = pygame.image.load(os.path.join("img", "car_f1-wowheel-re.png"))

        self.wheel_left_image = self.wheel_left_image.convert_alpha()
        self.wheel_right_image = self.wheel_right_image.convert_alpha()
        self.car_image = self.car_image.convert_alpha()

        car_width, car_height = self.car_image.get_size()
        whlef_width, whlef_height = self.wheel_left_image.get_size()
        whrig_width, whrig_height = self.wheel_right_image.get_size()

        self.car_image = pygame.transform.scale(self.car_image, (int(car_width*scale_image), int(car_height*scale_image)))
        self.wheel_left_image = pygame.transform.scale(self.wheel_left_image, (int(whlef_width*scale_image), int(whlef_height*scale_image)))
        self.wheel_right_image = pygame.transform.scale(self.wheel_right_image, (int(whrig_width*scale_image), int(whrig_height*scale_image)))

        self.accel_channel = pygame.mixer.Channel(1)
        self.frein_channel = pygame.mixer.Channel(2)
        self.engine_channel = pygame.mixer.Channel(3)
        self.accel_sound = pygame.mixer.Sound(ACCEL_SOUND)
        self.frein_sound = pygame.mixer.Sound(FREIN_SOUND)
        self.engine_sound = pygame.mixer.Sound(ENGINE_SOUND)
        self.accel_playing = False
        self.frein_playing = False
        self.engine_playing = False

    def get_data(self):
        return {
            "position": [self.car_x, self.car_y],
            "speed_vec": [self.speed_x, self.speed_y],
            "car_angle": self.c_angle,
            "steering_angle": self.steering_angle,
            "chrono": self.start_time,
            "laps": self.laps_time,
            "has_finished": self.has_finished
        }
    
    def update_data(self, data : dict):
        if self.player_bool == False:
            self.prev_x = self.car_x
            self.prev_y = self.car_y
            self.target_x = data["position"][0]
            self.target_y = data["position"][1]
            self.c_angle = data["car_angle"]
            self.interp_timer = 0.0
            self.speed_x = data["speed_vec"][0]
            self.speed_y = data["speed_vec"][1]
            self.steering_angle = data["steering_angle"]
            self.start_time = data["chrono"]
            self.laps_time = data["laps"]
            self.has_finished = data["has_finished"]
        
    def get_speed_norm(self):
        return math.sqrt(self.speed_x**2 + self.speed_y**2)
    
    def toggle_gear(self):
        if self.get_speed_norm() < 0.5:
            self.direction = self.direction * -1
    
    def get_gear(self):
        return "D" if self.direction == 1 else "R"
    
    def update(self, keys=None, dt=None):
        if self.player_bool == True:
            speed = self.get_speed_norm()
            if speed**2 < 40**2 and speed != 0:
                max_steering = math.radians(abs(-65/40*speed + 65))
            else:
                max_steering = math.radians(10)
            
            turning = False
            if keys[pygame.K_d] and not keys[pygame.K_a]:
                self.steering_angle += self.str_angle * dt 
                if self.steering_angle > max_steering:
                    self.steering_angle = max_steering
                turning = True
            elif keys[pygame.K_a] and not keys[pygame.K_d]:
                self.steering_angle -= self.str_angle * dt
                if self.steering_angle < -max_steering:
                    self.steering_angle = -max_steering
                turning = True
            if not turning:
                if self.steering_angle > 0:
                    self.steering_angle -= self.str_angle_back * dt
                    if self.steering_angle < 0:
                        self.steering_angle = 0
                elif self.steering_angle < 0:
                    self.steering_angle += self.str_angle_back * dt
                    if self.steering_angle > 0:
                        self.steering_angle = 0

            overspeeding = False
            accelerating = False
            braking = False
            if keys[pygame.K_w]:
                speed += self.acc * dt
                overspeeding = True
                accelerating = True
            if keys[pygame.K_s]:
                speed += self.bre * dt
                if speed < 0:
                    speed = 0
                overspeeding = True
                braking = True

            if accelerating:
                if not self.accel_playing:
                    self.accel_channel.play(self.accel_sound, loops=-1)
                    self.accel_playing = True
                if self.frein_playing:
                    self.frein_channel.stop()
                    self.frein_playing = False
                if self.engine_playing:
                    self.engine_channel.stop()
                    self.engine_playing = False
            elif braking:
                if not self.frein_playing:
                    self.frein_channel.play(self.frein_sound, loops=-1)
                    self.frein_playing = True
                if self.accel_playing:
                    self.accel_channel.stop()
                    self.accel_playing = False
                if self.engine_playing:
                    self.engine_channel.stop()
                    self.engine_playing = False
            else:
                if not self.engine_playing:
                    self.engine_channel.play(self.engine_sound, loops=-1)
                    self.engine_playing = True
                if self.accel_playing:
                    self.accel_channel.stop()
                    self.accel_playing = False
                if self.frein_playing:
                    self.frein_channel.stop()
                    self.frein_playing = False

            beta = 0
            if (speed)**2 > 0:
                turning_radius = self.length / math.tan(self.steering_angle) if abs(self.steering_angle) > 0.001 else float('inf')
                angular_velocity = speed / turning_radius
                if self.direction == -1:
                    self.heading_theta -= angular_velocity * dt
                else:
                    self.heading_theta += angular_velocity * dt
                self.heading_theta = (self.heading_theta + math.pi) % (2*math.pi) -math.pi
                beta = math.atan(0.25 * math.tan(self.steering_angle))
                
            if keys[pygame.K_r]:
                if not self.r_pressed_last_frame:
                    self.toggle_gear()
                self.r_pressed_last_frame = True
            else:
                self.r_pressed_last_frame = False

            self.speed_x = math.cos(self.heading_theta) * speed * self.direction
            self.speed_y = math.sin(self.heading_theta) * speed * self.direction

            if not overspeeding and speed != 0:
                resistance_x = self.res_motor * (self.speed_x / speed)
                resistance_y = self.res_motor * (self.speed_y / speed)
                self.speed_x += resistance_x * dt
                self.speed_y += resistance_y * dt

            new_x = self.car_x + self.speed_x
            new_y = self.car_y + self.speed_y

            track_width, track_height = track_image.get_size()
            half_car_width = self.car_image.get_width() / 2
            half_car_height = self.car_image.get_height() / 2
            if half_car_width <= new_x <= track_width - half_car_width:
                self.car_x = new_x
            else:
                self.car_x = max(half_car_width, min(new_x, track_width - half_car_width))
                self.speed_x = 0

            if half_car_height <= new_y <= track_height - half_car_height:
                self.car_y = new_y
            else:
                self.car_y = max(half_car_height, min(new_y, track_height - half_car_height))
                self.speed_y = 0

            self.cam_x = self.car_x - SCREEN_WIDTH // 2
            self.cam_y = self.car_y - SCREEN_HEIGHT // 2
            self.c_angle = self.heading_theta + beta
        else:
            self.interp_timer = min(self.interp_timer + dt, self.interp_duration)
            t = self.interp_timer / self.interp_duration
            self.car_x = self.prev_x + (self.target_x - self.prev_x) * t
            self.car_y = self.prev_y + (self.target_y - self.prev_y) * t

    def draw(self, screen):
        car_rect_center = (self.car_x - self.player.cam_x, self.car_y - self.player.cam_y)
        if self.player_bool:
            car_rect_center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        car_angle = -math.degrees(self.c_angle)
        wheels_angle = -math.degrees(self.steering_angle + self.c_angle)
        rotated_car = pygame.transform.rotate(self.car_image, car_angle)

        car_rect = rotated_car.get_rect(center=car_rect_center)
        screen.blit(rotated_car, car_rect)

        rotated_wheel_left = pygame.transform.rotate(self.wheel_left_image, wheels_angle)
        rotated_wheel_right = pygame.transform.rotate(self.wheel_right_image, wheels_angle)
        wheel_offset = 26
        wheel_base = 48
        wheel_pos_right = (self.car_x + math.cos(self.c_angle)*(wheel_base/2) - math.cos(math.pi/2-self.c_angle)*(wheel_offset/2), self.car_y + math.sin(self.c_angle)*(wheel_base/2) + math.sin(math.pi/2-self.c_angle)*(wheel_offset/2))
        wheel_pos_left = (self.car_x + math.cos(self.c_angle)*(wheel_base/2) + math.cos(math.pi/2-self.c_angle)*(wheel_offset/2), self.car_y + math.sin(self.c_angle)*(wheel_base/2) - math.sin(math.pi/2-self.c_angle)*(wheel_offset/2))
        wheel_screen_left = (wheel_pos_left[0] - self.player.cam_x, wheel_pos_left[1] - self.player.cam_y)
        wheel_screen_right = (wheel_pos_right[0] - self.player.cam_x, wheel_pos_right[1] - self.player.cam_y)
        screen.blit(rotated_wheel_left, rotated_wheel_left.get_rect(center=wheel_screen_left))
        screen.blit(rotated_wheel_right, rotated_wheel_right.get_rect(center=wheel_screen_right))

        if self.player_bool:
            speed_text = font.render(f"{round(self.get_speed_norm())} Km/h", True, (223, 223, 225))
            gear_text = font.render(f"{self.get_gear()}", True, (223, 223, 225))        
            speed_text_pos = (SCREEN_WIDTH - speed_text.get_width() - 10, 10)
            gear_text_pos = (SCREEN_WIDTH - gear_text.get_width() - 10, 10 + speed_text.get_height() + 5)
            shadow_speed_text = font.render(f"{round(self.get_speed_norm())} Km/h", True, (50, 50, 50))
            shadow_speed_text_pos = (speed_text_pos[0] + 2, speed_text_pos[1] + 2)
            screen.blit(shadow_speed_text, shadow_speed_text_pos)
            shadow_gear_text = font.render(f"{self.get_gear()}", True, (50, 50, 50))
            shadow_gear_text_pos = (gear_text_pos[0] + 2, gear_text_pos[1] + 2)
            screen.blit(shadow_gear_text, shadow_gear_text_pos)
            screen.blit(speed_text, speed_text_pos)
            screen.blit(gear_text, gear_text_pos)
        
class Game:
    def __init__(self):
        self.state = MENU
        self.local_game_launched = False
        self.player = None
        self.created_server = False
        self.connected_to_server = False
        self.start_button_rect = None
        self.multi_game_launched = False
        self.first_initialised = False
        self.tour_race = 2
        self.network_update_counter = 0
        self.sent_tour_to_server = False
        self.input_locked = False
        self.error_saving = ""
        self.error = ""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            self.server_ip = s.getsockname()[0]
            s.close()
        except:
            self.server_ip = "localhost"
        self.adj_graph_sent = False
        pygame.event.clear()
        self.show_loading_screen("Chargement des ressources du circuit...")
        self.input_ip_box = InputBox(SCREEN_WIDTH // 2 - 150, 200, 300, 50, (0, 120, 255), (180, 180, 180), "", "Entrez l'ip du serveur de jeu:")
        self.input_name_box = InputBox(SCREEN_WIDTH // 2 - 150, 250, 300, 50, (0, 120, 255), (180, 180, 180), "", "Entrez votre nom de coureur:")
        self.input_tour_box = InputBox(SCREEN_WIDTH // 2 - 150, 350, 300, 50, (0, 120, 255), (180, 180, 180), "", "Entrez le nombre de tours:", input_type="number")
        
        pygame.event.clear()
        pygame.display.flip()
        pygame.event.pump()

        try:
            with open(os.path.join("img", "track1_points.txt"), "r", encoding="utf-8") as file:
                self.track_points_dict = ast.literal_eval(file.read())
        except:
            self.show_loading_screen("Extraction des points du circuit...")
            pygame.display.flip()
            pygame.event.pump()
            colors_to_extract = {
                "border": (195, 195, 195),
                "finish": (127, 127, 127),
                "spawn": (250, 255, 181),
                "checkpoint": (31, 35, 26)
            }
            width, height = track_image.get_size()
            color_points = {name: [] for name in colors_to_extract}
            count = 0

            for x in range(width):
                for y in range(height):
                    color = track_image.get_at((x, y))[:3]
                    for name, ref_color in colors_to_extract.items():
                        if color == ref_color:
                            color_points[name].append((x, y))
                    count += 1
                if count % 10 == 0:
                    self.show_loading_screen(f"Extraction... {int(100*x/width)}%")
                    pygame.event.pump()
                    pygame.display.flip()

            with open(os.path.join("img", "track1_points.txt"), "w", encoding="utf-8") as f:
                f.write(str(color_points))
            self.track_points_dict = color_points

        self.arrival_point = (2574, 2434)
        self.checkpoints = self.track_points_dict["checkpoint"]
        self.graph = self.build_checkpoint_graph(self.checkpoints, self.arrival_point, k=4)
        self.dijkstra_distances = self.dijkstra(self.graph, self.arrival_point)

        pygame.event.clear()
        pygame.key.set_repeat(200, 70)

        self.title_racepy = font.render("Racepy", True, (0, 0, 0))
        self.title_multijoueur = font.render("Multijoueur", True, (0, 0, 0))
        self.title_rejoindre = font.render("Rejoindre un serveur", True, (0, 0, 0))
        self.title_serveur_cree = font.render("Serveur créé", True, (0, 0, 0))
        self.title_lobby = font.render("Serveur rejoins !", True, (0, 0, 0))
        self.title_solo = font.render("Course contre la montre", True, (0, 0, 0))
        self.title_resultat = font.render("Résultat", True, (0, 0, 0))
        self.btn_jouer = font.render("Jouer", True, (0, 200, 0))
        self.btn_multi = font.render("Multijoueur", True, (0, 200, 0))
        self.btn_creer = font.render("Créer un serveur", True, (0, 200, 0))
        self.btn_rejoindre = font.render("Rejoindre un serveur", True, (0, 200, 0))
        self.btn_commencer = font.render("Commencer", True, (0, 200, 0))
        self.btn_lancer = font.render("Lancer la partie", True, (0, 200, 0))
        self.btn_save_score = font.render("Sauvegarder mon score", True, (0, 200, 0))

    def build_checkpoint_graph(self, checkpoints, arrival, k=4):
        points = list(checkpoints) + [arrival]
        graph = {pt: [] for pt in points}
        for i, pt in enumerate(points):
            dists = []
            for j, other in enumerate(points):
                if i != j:
                    dist = math.sqrt((pt[0] - other[0])**2 + (pt[1] - other[1])**2)
                    dists.append((dist, other))
            for dist, neighbor in sorted(dists)[:k]:
                graph[pt].append((neighbor, dist))
        return graph

    def dijkstra(self, graph, start):
        distances = {pt: float('inf') for pt in graph}
        distances[start] = 0
        rest = [(0, start)]
        while rest:
            dist, current = heapq.heappop(rest)
            # We use heapq to efficiently implement a priority queue for Dijkstra's algorithm.
            # It allows us to always retrieve the node with the smallest distance in O(log(n)) time,
            # which is much faster than sorting the entire list of nodes at every step (O(nlog(n))) with list.sorted().
            # We have approximately 40 checkpoints but in case of a bigger map or more maps it begins useful.
            if dist > distances[current]:
                continue
            for neighbor, weight in graph[current]:
                new_dist = dist + weight
                if new_dist < distances[neighbor]:
                    distances[neighbor] = new_dist
                    heapq.heappush(rest, (new_dist, neighbor))
        return distances

    def distance_to_arrival(self, x, y):
        nearest, _ = self.find_nearest_checkpoint(x, y)
        dist_to_checkpoint = math.sqrt((nearest[0] - x)**2 + (nearest[1] - y)**2)
        dist_checkpoint_to_arrival = self.dijkstra_distances.get(nearest, float('inf'))
        return dist_to_checkpoint + dist_checkpoint_to_arrival

    def save_score(self, classement):
        try:
            filename = "scores.txt"
            if os.path.exists(filename):
                with open(filename, "r", encoding="utf-8") as f:
                    scores = eval(f.read())
            else:
                scores = {}
            for entry in classement:
                if len(entry) == 3:
                    _, total_time, car = entry
                else:
                    total_time, car = entry
                if total_time == float('inf'):
                    continue
                if car.player_bool:
                    name = car.player_name
                    if name not in scores or total_time < scores[name]:
                        scores[name] = total_time
            with open(filename, "w", encoding="utf-8") as f:
                f.write(str(scores))
        except Exception as e:
            print(f"Erreur sauvegarde score : {e}")
    
    def load_best_time(self, name):
        filename = "scores.txt"
        if not os.path.exists(filename):
            return f"{name} : -- s"
        try:
            with open(filename, "r", encoding="utf-8") as f:
                scores = eval(f.read())
            if name in scores:
                return f"{name} : {scores[name]:.2f} s"
            else:
                return f"{name} : -- s"
        except Exception as e:
            return f"{name} : erreur"
    
    def load_best_time_global(self):
        filename = "scores.txt"
        if not os.path.exists(filename):
            return "Meilleur temps : -- s"
        try:
            with open(filename, "r", encoding="utf-8") as f:
                scores = eval(f.read())
            if not scores:
                return "Meilleur temps : -- s"
            best_name = min(scores, key=lambda k: scores[k])
            best_time = scores[best_name]
            return f"Meilleur temps : {best_time:.2f} s ({best_name})"
        except Exception as e:
            return "Meilleur temps : erreur"
    
    def show_loading_screen(self, message="Chargement..."):
        screen.fill(WHITE)
        txt = font.render(message, True, (0, 0, 0))
        screen.blit(txt, txt.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)))
        draw_fps(screen, clock)
        pygame.display.flip()

    def draw_menu(self, error_mesage):
        screen.fill(WHITE)
        to_blit = []
        title = self.title_racepy
        local_text = "Jouer"
        net_text = "Multijoueur"
        mouse_pos = pygame.mouse.get_pos()
        local_rect = self.btn_jouer.get_rect(center=(SCREEN_WIDTH // 2, 300))
        net_rect = self.btn_multi.get_rect(center=(SCREEN_WIDTH // 2, 400))
        if local_rect.collidepoint(mouse_pos):
            local_btn = font.render(local_text, True, (0, 255, 0))
        else:
            local_btn = self.btn_jouer
        if net_rect.collidepoint(mouse_pos):
            net_btn = font.render(net_text, True, (0, 255, 0))
        else:
            net_btn = self.btn_multi
        to_blit.append((title, title.get_rect(center=(SCREEN_WIDTH // 2, 150))))
        to_blit.append((local_btn, local_rect))
        to_blit.append((net_btn, net_rect))
        if error_mesage != "":
            error_text = font.render(error_mesage, True, (0, 0, 0))
            to_blit.append((error_text, error_text.get_rect(center=(SCREEN_WIDTH // 2, 100))))
        else:
            best_txt = font.render(self.load_best_time_global(), True, (0, 0, 0))
            to_blit.append((best_txt, best_txt.get_rect(center=(SCREEN_WIDTH // 2, 100))))
        for surf, rect in to_blit:
            screen.blit(surf, rect)
        draw_fps(screen, clock)
        return local_rect, net_rect

    def draw_menu_multijoueur_choice(self):
        screen.fill(WHITE)
        to_blit = []
        title = self.title_multijoueur
        to_blit.append((title, title.get_rect(center=(SCREEN_WIDTH // 2, 100))))
        self.input_name_box.update()
        self.input_name_box.draw(screen)
        create_rect = self.btn_creer.get_rect(center=(SCREEN_WIDTH // 2, 350))
        join_rect = self.btn_rejoindre.get_rect(center=(SCREEN_WIDTH // 2, 450))
        mouse_pos = pygame.mouse.get_pos()
        if create_rect.collidepoint(mouse_pos):
            create_btn = font.render("Créer un serveur", True, (0, 255, 0))
        else:
            create_btn = self.btn_creer
        if join_rect.collidepoint(mouse_pos):
            join_btn = font.render("Rejoindre un serveur", True, (0, 255, 0))
        else:
            join_btn = self.btn_rejoindre
        to_blit.append((create_btn, create_rect))
        to_blit.append((join_btn, join_rect))
        for surf, rect in to_blit:
            screen.blit(surf, rect)
        draw_fps(screen, clock)
        return create_rect, join_rect

    def draw_menu_multijoueur(self):
        screen.fill(WHITE)
        to_blit = []
        title = self.title_rejoindre
        to_blit.append((title, title.get_rect(center=(SCREEN_WIDTH // 2, 100))))
        self.input_ip_box.update()
        self.input_ip_box.draw(screen)
        join_rect = self.btn_rejoindre.get_rect(center=(SCREEN_WIDTH // 2, 300))
        mouse_pos = pygame.mouse.get_pos()
        if join_rect.collidepoint(mouse_pos):
            join_btn = font.render("Rejoindre", True, (0, 255, 0))
        else:
            join_btn = self.btn_rejoindre
        to_blit.append((join_btn, join_rect))
        for surf, rect in to_blit:
            screen.blit(surf, rect)
        draw_fps(screen, clock)
        return join_rect

    def draw_menu_multijoueur_create(self):
        screen.fill(WHITE)
        to_blit = []
        title = self.title_serveur_cree
        to_blit.append((title, title.get_rect(center=(SCREEN_WIDTH // 2, 100))))
        self.input_tour_box.update()
        self.input_tour_box.draw(screen)
        data = {
            "req": "pull",
            "target": "game"
        }
        self.sock.send((json.dumps(data) + "\n").encode())
        response = self.sock_file.readline()
        game_data = json.loads(response)["game"]
        if game_data["player_count"]-1 > 0:
            info = font.render(f"Joueurs connectés : {(game_data['player_count']-1)}", True, (0, 0, 0))
        else:
            info = font.render("En attente de joueurs...", True, (0, 0, 0))
        to_blit.append((info, info.get_rect(center=(SCREEN_WIDTH // 2, 250))))
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
        except Exception as e:
            ip = f"Erreur : {e}"
        ip_text = font.render(f"Adresse IP: {ip}:4096", True, (0, 0, 0))
        to_blit.append((ip_text, ip_text.get_rect(center=(SCREEN_WIDTH // 2, 450))))
        start_game_rect = self.btn_lancer.get_rect(center=(SCREEN_WIDTH // 2, 170))
        mouse_pos = pygame.mouse.get_pos()
        if start_game_rect.collidepoint(mouse_pos):
            start_game_text = font.render("Lancer la partie", True, (0, 255, 0))
        else:
            start_game_text = self.btn_lancer
        to_blit.append((start_game_text, start_game_rect))
        for surf, rect in to_blit:
            screen.blit(surf, rect)
        draw_fps(screen, clock)
        return start_game_rect

    def draw_lobby(self):
        screen.fill(WHITE)
        to_blit = []
        title = self.title_lobby
        to_blit.append((title, title.get_rect(center=(SCREEN_WIDTH // 2, 100))))
        sub_title = font.render("En attente du début de la partie...", True, (0, 0, 0))
        to_blit.append((sub_title, sub_title.get_rect(center=(SCREEN_WIDTH // 2, 140))))
        data = {
            "req": "pull",
            "target": "players"
        }
        self.sock.send((json.dumps(data) + "\n").encode())
        response = self.sock_file.readline()
        players_data = json.loads(response)["players"]
        y = 180
        for ip, player in players_data.items():
            name = player.get("player_name", f"Joueur {ip}")
            txt = font.render(name, True, (0, 0, 0))
            to_blit.append((txt, txt.get_rect(center=(SCREEN_WIDTH // 2, y))))
            y += 40
        for surf, rect in to_blit:
            screen.blit(surf, rect)
        draw_fps(screen, clock)

    def draw_menu_play_solo(self):
        screen.fill(WHITE)
        to_blit = []
        title = self.title_solo
        to_blit.append((title, title.get_rect(center=(SCREEN_WIDTH // 2 , 100))))
        self.input_name_box.update()
        self.input_name_box.draw(screen)
        self.input_tour_box.update()
        self.input_tour_box.draw(screen)
        launch_rect = self.btn_commencer.get_rect(center=(SCREEN_WIDTH // 2, 500))
        mouse_pos = pygame.mouse.get_pos()
        if launch_rect.collidepoint(mouse_pos):
            launch_btn = font.render("Commencer", True, (0, 255, 0))
        else:
            launch_btn = self.btn_commencer
        to_blit.append((launch_btn, launch_rect))
        for surf, rect in to_blit:
            screen.blit(surf, rect)
        draw_fps(screen, clock)
        return launch_rect

    def draw_classement(self, classement : list, error_message):
        screen.fill(WHITE)
        to_blit = []
        title = self.title_resultat
        to_blit.append((title, title.get_rect(center=(SCREEN_WIDTH // 2, 100))))
        top = classement[:5]
        player_in_top = False
        for _, _, car in top:
            if car.player_bool:
                player_in_top = True
                player_name = car.player_name
        player_entry = None
        if player_in_top == False:
            for idx, total_time, car in classement:
                if car.player_bool:
                    player_entry = (idx, total_time, car)
                    player_name = car.player_name
                    break
        for idx, total_time, car in top:
            if total_time == float('inf'):
                time_str = "En course"
            else:
                time_str = f"{total_time:.2f} s"
            txt = font.render(f"{idx}. {car.player_name} - {time_str}", True, (0, 0, 0))
            to_blit.append((txt, (SCREEN_WIDTH // 2 - txt.get_width() // 2, 150 + idx * 40)))
        if player_entry:
            idx, total_time, car = player_entry
            if total_time == float('inf'):
                time_str = "En course"
            else:
                time_str = f"{total_time:.2f} s"
            txt = font.render(f"{idx}. {car.player_name} - {time_str}", True, (0, 0, 255))
            to_blit.append((txt, (SCREEN_WIDTH // 2 - txt.get_width() // 2, 150 + 6 * 40)))
        save_rect = self.btn_save_score.get_rect(center=(SCREEN_WIDTH // 2, 200 + 6*40))
        mouse_pos = pygame.mouse.get_pos()
        if save_rect.collidepoint(mouse_pos):
            save_btn = font.render("Sauvegarder mon score", True, (0, 255, 0))
        else:
            save_btn = self.btn_save_score
        to_blit.append((save_btn, save_rect))
        if error_message != "":
            error_text = font.render(error_message, True, (0, 0, 0))
            to_blit.append((error_text, error_text.get_rect(center=(SCREEN_WIDTH // 2, 250 + 6*40))))
        else:
            best_own_text = font.render(self.load_best_time(player_name), True, (0, 0, 0))
            to_blit.append((best_own_text, best_own_text.get_rect(center=(SCREEN_WIDTH // 2, 250 + 6*40))))
        for surf, rect in to_blit:
            screen.blit(surf, rect)
        draw_fps(screen, clock)
        return save_rect

    def find_nearest_checkpoint(self, x, y):
        checkpoints = self.track_points_dict["checkpoint"]
        nearest = float('inf')
        for pos in checkpoints:
            distance = math.sqrt((pos[0]-x)**2 + (pos[1]-y)**2)
            if distance < nearest:
                nearest = distance
                near_pos = (pos[0], pos[1])
        nearest = float("inf")
        for pos in checkpoints:
            distance = math.sqrt((pos[0]-near_pos[0])**2 + (pos[1]-near_pos[1])**2)
            if distance < nearest:
                nearest = distance
                near_next_check = (pos[0], pos[1])
        angle = math.atan2(near_pos[0]-near_next_check[0], near_pos[1]-near_next_check[1])
        return near_pos, angle

    def find_start_angle(self, x, y):
        line = self.track_points_dict["finish"]
        nearest = float('inf')
        for pos in line:
            distance = math.sqrt((pos[0]-x)**2 + (pos[1]-y)**2)
            if distance < nearest:
                nearest = distance
                near_pos = (pos[0], pos[1])
        dx = x - near_pos[0]
        dy = y - near_pos[1]
        return (math.atan2(dy, dx) + math.pi)
    
    def manage_race(self, cars : List[Car], dt, tour=2): # Method în purpose to play with others on the same device
        try:
            tour = int(tour)
        except Exception:
            tour = 2

        if self.local_game_launched == False:
            for i, car in enumerate(cars):
                if i < len(self.track_points_dict["spawn"]):
                    car.car_x, car.car_y = self.track_points_dict["spawn"][i]
                    car.speed_x = 0
                    car.speed_y = 0
                    if car.player_bool == True:
                        car.heading_theta = self.find_start_angle(car.car_x, car.car_y)
                    else:
                        car.c_angle = self.find_start_angle(car.car_x, car.car_y)
            countdown_font = pygame.font.SysFont(None, 120)
            for t in range(3, 0, -1):
                screen.fill(WHITE)
                txt = countdown_font.render(str(t), True, (255,0,0))
                screen.blit(txt, txt.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2)))
                pygame.display.flip()
                pygame.time.wait(1000)
            screen.fill(WHITE)
            txt = countdown_font.render("GO!", True, (0,200,0))
            screen.blit(txt, txt.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2)))
            pygame.display.flip()
            pygame.time.wait(700)
            self.local_game_launched = True
            self.finished_timer = 0
            self.finished_time = []

        player_car = next((car for car in cars if car.player_bool), cars[0])
        cam_x, cam_y = player_car.cam_x, player_car.cam_y
        screen.fill(WHITE)
        screen.blit(track_image, (-cam_x, -cam_y))
        for car in cars:
            keys = pygame.key.get_pressed() if not self.input_locked else [0] * 512
            car.update(keys, dt)
            ix, iy = int(car.car_x), int(car.car_y)
            if (ix, iy) in self.track_points_dict["border"]:
                pos, angle = self.find_nearest_checkpoint(car.car_x, car.car_y)
                car.car_x, car.car_y = pos[0], pos[1]
                car.c_angle = angle
                car.speed_x = 0
                car.speed_y = 0
                car.is_passing_finish = False
            if (ix, iy) in self.track_points_dict["finish"]:
                if not car.is_passing_finish:
                    if car.start_time is None:
                        car.start_time = pygame.time.get_ticks()
                    else:
                        if not car.has_finished:
                            car.laps_time.append((pygame.time.get_ticks() - car.start_time) / 1000)
                            if len(car.laps_time) >= tour:
                                car.has_finished = True
                                if len(self.finished_time) == 0:
                                    self.finished_time.append(pygame.time.get_ticks()/1000)
                            else:
                                car.start_time = pygame.time.get_ticks()
                car.is_passing_finish = True
            else:
                car.is_passing_finish = False

        for car in cars:
            car.draw(screen)
        draw_fps(screen, clock)
        all_finished = all(car.has_finished for car in cars)
        if len(self.finished_time) != 0:
            self.finished_timer = pygame.time.get_ticks() - self.finished_time[0]
        if all_finished or self.finished_timer > 30:
            classement = []
            for pos, car in enumerate(sorted(cars, key=lambda c: sum(c.laps_time) if c.has_finished else float('inf')), 1):
                total_time = sum(car.laps_time) if car.has_finished else float('inf')
                classement.append((pos, total_time, car))
            self.draw_classement(classement, self.error)
            return True, classement
        else:
            classement = []
            for car in cars:
                tours = len(car.laps_time)
                # Si le joueur a fini, on prend le temps total, sinon on prend le temps courant
                if car.has_finished:
                    total_time = sum(car.laps_time)
                    distance = float('inf')
                else:
                    # Chrono actuel = temps depuis le début du tour en cours
                    if car.start_time is not None:
                        current_lap_time = max(0, (pygame.time.get_ticks() - car.start_time) / 1000)
                    else:
                        current_lap_time = 0
                    total_time = sum(car.laps_time) + current_lap_time
                    distance = self.distance_to_arrival(car.car_x, car.car_y)
                # On trie d'abord par nombre de tours (décroissant), puis par temps (croissant), puis par distance (croissant)
                classement.append((-tours, total_time, distance, car))
            classement.sort(key=lambda x: (x[0], x[1], x[2]))
            top_n = 3
            player_in_top = False
            for pos, (_, _, _, car) in enumerate(classement[:top_n], 1):
                if not car.has_finished and car.start_time is not None:
                    current_lap_time = max(0, (pygame.time.get_ticks() - car.start_time) / 1000)
                    txt = font.render(f"{pos}. {car.player_name} (Tours: {len(car.laps_time)}/{tour})  Tour en cours: {current_lap_time:.2f}s", True, (223, 223, 225))
                    screen.blit(txt, (10, 10 + 30 * (pos-1)))
                elif car.has_finished:
                    txt = font.render(f"{pos}. {car.player_name} (Terminé)", True, (180, 180, 180))
                    screen.blit(txt, (10, 10 + 30 * (pos-1)))
                if car.player_bool:
                    player_in_top = True

            if player_in_top == False:
                for pos, (_, _, _, car) in enumerate(classement, 1):
                    if car.player_bool:
                        if not car.has_finished and car.start_time is not None:
                            current_lap_time = max(0, (pygame.time.get_ticks() - car.start_time) / 1000)
                            txt = font.render(f"{pos}. {car.player_name} (Tours: {len(car.laps_time)}/{tour})  Tour en cours: {current_lap_time:.2f}s", True, (0, 0, 255))
                            screen.blit(txt, (10, 10 + 30 * (top_n)))
                        elif car.has_finished:
                            txt = font.render(f"{pos}. {car.player_name} (Terminé)", True, (0, 0, 255))
                            screen.blit(txt, (10, 10 + 30 * (top_n)))
                        break

            return False, [(x[1], x[3]) for x in classement]

    def run_local_game(self, car : Car):
        keys = pygame.key.get_pressed()
        dt = clock.get_time() / 1000
        car.update(keys, dt)
        speed_text = font.render(f"{round(car.get_speed_norm())} Km/h", True, (0, 0, 0))
        gear_text = font.render(f"{car.get_gear()}", True, (0, 0, 0))        
        speed_text_pos = (SCREEN_WIDTH - speed_text.get_width() - 10, 10)
        gear_text_pos = (SCREEN_WIDTH - gear_text.get_width() - 10, 10 + speed_text.get_height() + 5)
        shadow_speed_text = font.render(f"{round(car.get_speed_norm())} Km/h", True, (50, 50, 50))
        shadow_speed_text_pos = (speed_text_pos[0] + 2, speed_text_pos[1] + 2)
        screen.blit(shadow_speed_text, shadow_speed_text_pos)
        shadow_gear_text = font.render(f"{car.get_gear()}", True, (50, 50, 50))
        shadow_gear_text_pos = (gear_text_pos[0] + 2, gear_text_pos[1] + 2)
        screen.blit(shadow_gear_text, shadow_gear_text_pos)
        screen.blit(speed_text, speed_text_pos)
        screen.blit(gear_text, gear_text_pos)
 
    def try_join_server(self):
        ip = self.input_ip_box.text.strip()
        name = self.input_name_box.text.strip()
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(3)
            self.sock.connect((ip, 4096))
            self.sock_file = self.sock.makefile("r")
            data = {
                "req": "join",
                "player_attr": {"player_name": name}
            }
            self.sock.send((json.dumps(data) + "\n").encode())
            self.input_ip_box.error_message = "Connecté !"
            self.connected_to_server = True
            self.state = NETWORKGAME
        except Exception as e:
            self.input_ip_box.error_message = f"Erreur: {e}"
            if hasattr(self, 'sock'):
                self.sock.close()
                del self.sock
    
    def try_create_server(self):
        try:
            server.server_initialize()
            self.input_name_box.error_message = "Serveur lancé !"
            self.created_server = True
        except Exception as e:
            self.input_name_box.error_message = f"Erreur serveur: {e}"
            print(self.input_name_box.error_message)
    
    def try_connect_own_server(self):
        ip = self.server_ip
        name = self.input_name_box.text.strip()
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(3)
            self.sock.connect((ip, 4096))
            self.sock_file = self.sock.makefile("r")
            data = {
                "req": "join",
                "player_attr": {"player_name": name}
            }
            self.sock.send((json.dumps(data) + "\n").encode())
            self.input_ip_box.error_message = "Connecté !"
            self.connected_to_server = True
            if not self.adj_graph_sent:
                self.send_graph_to_server()
        except Exception as e:
            self.input_ip_box.error_message = f"Erreur: {e}"
            if hasattr(self, 'sock'):
                self.sock.close()
                del self.sock

    def send_pull(self, target):
        try:
            data = {"req": "pull", "target": target}
            self.sock.send((json.dumps(data) + "\n").encode())
            response = self.sock_file.readline()
            if not response:
                raise ConnectionError("Serveur déconnecté")
            return json.loads(response)
        except Exception as e:
            self.error = f"Erreur : {e}"
            self.state = MENU
            self.connected_to_server = False
            return None

    def send_push(self, player_attr):
        try:
            data = {"req": "push", "player_attr": player_attr}
            self.sock.send((json.dumps(data) + "\n").encode())
        except Exception as e:
            self.error = f"Erreur : {e}"
            self.state = MENU
            self.connected_to_server = False

    def send_graph_to_server(self):
        try:
            graph_str_keys = {str(k): [(str(n), d) for n, d in v] for k, v in self.graph.items()}
            data = {
                "req": "set_graph",
                "graph": graph_str_keys,
                "checkpoints": [list(pt) for pt in self.track_points_dict["checkpoint"]],
                "arrival": list(self.arrival_point)
            }
            self.sock.send((json.dumps(data) + "\n").encode())
            self.adj_graph_sent = True
        except Exception as e:
            self.error = f"Erreur : {e}"
            self.state = MENU

    def manage_race_online(self, dt, tour = 2):
        try:
            try:
                tour = int(tour)
            except Exception:
                tour = 2
            if self.first_initialised == False:
                self.cars = []
                self.player = Car(self.input_name_box.text)
                self.cars.append(self.player)
                data = {
                    "req": "pop_spawn"
                }
                self.sock.send((json.dumps(data) + "\n").encode())
                response = self.sock_file.readline()
                spawn_point = json.loads(response)["spawn"]
                self.player.car_x = spawn_point[0]
                self.player.car_y = spawn_point[1]
                self.player.heading_theta = self.find_start_angle(self.player.car_x, self.player.car_y)
                self.player.update([0]*512, dt)
                data = {
                    "position": [self.player.car_x, self.player.car_y],
                    "speed_vec": [self.player.speed_x, self.player.speed_y],
                    "car_angle": self.player.c_angle,
                    "steering_angle": self.player.steering_angle,
                    "chrono": self.player.start_time,
                    "laps": self.player.laps_time,
                    "has_finished": self.player.has_finished
                }
                self.send_push(data)
                while True:
                    game_data = self.send_pull("game")
                    if game_data is None:
                        return False, []
                    if game_data["game"].get("all_player_ready", False):
                        break
                    pygame.time.wait(200)
                players_data = self.send_pull("players")
                for ip, player in players_data["players"].items():
                    if self.player.player_name != player.get("player_name"):
                        name = player.get("player_name", f"Joueur {ip}")
                        pos = player.get("position", [0, 0])
                        car = Car(name, pos[0], pos[1], player=self.player)
                        car.c_angle = player.get("car_angle", 0)
                        self.cars.append(car)
                self.cars_dict = {}
                for car in self.cars:
                    self.cars_dict[car.player_name] = car
                countdown_font = pygame.font.SysFont(None, 120)
                self.input_locked = True
                for t in range(3, 0, -1):
                    screen.fill(WHITE)
                    screen.blit(track_image, (-self.player.cam_x, -self.player.cam_y))
                    for car in self.cars:
                        car.draw(screen)
                    txt = countdown_font.render(str(t), True, (255,0,0))
                    screen.blit(txt, txt.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2)))
                    pygame.display.flip()
                    pygame.time.wait(1000)
                screen.fill(WHITE)
                screen.blit(track_image, (-self.player.cam_x, -self.player.cam_y))
                for car in self.cars:
                    car.draw(screen)
                txt = countdown_font.render("GO!", True, (0,200,0))
                screen.blit(txt, txt.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2)))
                pygame.display.flip()
                pygame.time.wait(700)
                self.input_locked = False
                self.finished_timer = 0
                self.finished_time = []
                self.first_initialised = True

            self.network_update_counter += 1
            if self.network_update_counter % 7 == 0:
                players_data = self.send_pull("players")
                for ip, players in players_data["players"].items():
                    if self.player.player_name != players.get("player_name"):
                        self.cars_dict[players.get("player_name", f"Joueur {ip}")].update_data(players)
            screen.fill(WHITE)
            screen.blit(track_image, (-self.player.cam_x, -self.player.cam_y))
            for car in self.cars:
                keys = pygame.key.get_pressed() if not self.input_locked else [0] * 512
                car.update(keys, dt)
                ix, iy = int(car.car_x), int(car.car_y)
                if car.player_bool:
                    if (ix, iy) in self.track_points_dict["border"]:
                        pos, angle = self.find_nearest_checkpoint(car.car_x, car.car_y)
                        car.car_x, car.car_y = pos[0], pos[1]
                        car.c_angle = angle
                        car.speed_x = 0
                        car.speed_y = 0
                        car.is_passing_finish = False
                    if (ix, iy) in self.track_points_dict["finish"]:
                        if not car.is_passing_finish:
                            if car.start_time is None:
                                car.start_time = pygame.time.get_ticks()
                            else:
                                if not car.has_finished:
                                    car.laps_time.append((pygame.time.get_ticks() - car.start_time) / 1000)
                                    if len(car.laps_time) >= tour:
                                        car.has_finished = True
                                        if len(self.finished_time) == 0:
                                            self.finished_time.append(pygame.time.get_ticks()/1000)
                                    else:
                                        car.start_time = pygame.time.get_ticks()
                        car.is_passing_finish = True
                    else:
                        car.is_passing_finish = False
            for car in self.cars:
                car.draw(screen)
            draw_fps(screen, clock)
            if self.network_update_counter % 7 == 0:
                data = {
                    "position": [self.player.car_x, self.player.car_y],
                    "speed_vec": [self.player.speed_x, self.player.speed_y],
                    "car_angle": self.player.c_angle,
                    "steering_angle": self.player.steering_angle,
                    "chrono": self.player.start_time,
                    "laps": self.player.laps_time,
                    "has_finished": self.player.has_finished,
                    "total_time": (
                        sum(self.player.laps_time)
                        if self.player.has_finished
                        else sum(self.player.laps_time) + (pygame.time.get_ticks() - self.player.start_time) / 1000
                        if self.player.start_time is not None
                        else sum(self.player.laps_time)
                    )
                }
                self.send_push(data)
            classement_data = self.send_pull("game")
            classement = []
            for pos, total_time, name in classement_data["game"]["classement"]:
                car = self.cars_dict.get(name)
                if car is not None:
                    classement.append((pos, total_time, car))
            if len(self.finished_time) != 0:
                self.finished_timer = pygame.time.get_ticks() - self.finished_time[0]
            if classement_data["game"].get("game_finished"):
                classement.sort(key=lambda x: x[0])
                self.draw_classement(classement, self.error)
                return True, classement
            else:
                classement.sort(key=lambda x: x[0])
                top_n = 3
                player_in_top = False
                for pos, total_time, car in classement[:top_n]:
                    if not car.has_finished and car.start_time is not None:
                        current_lap_time = max(0, (pygame.time.get_ticks() - car.start_time) / 1000)
                        txt = font.render(f"{pos}. {car.player_name} (Tours: {len(car.laps_time)}/{tour})  Tour en cours: {current_lap_time:.2f}s", True, (223, 223, 225))
                        screen.blit(txt, (10, 10 + 30 * (pos-1)))
                    elif car.has_finished:
                        txt = font.render(f"{pos}. {car.player_name} (Terminé)", True, (180, 180, 180))
                        screen.blit(txt, (10, 10 + 30 * (pos-1)))
                    if car.player_bool:
                        player_in_top = True

                if player_in_top == False:
                    for pos, total_time, car in classement:
                        if car.player_bool:
                            if not car.has_finished and car.start_time is not None:
                                current_lap_time = max(0, (pygame.time.get_ticks() - car.start_time) / 1000)
                                txt = font.render(f"{pos}. {car.player_name} (Tours: {len(car.laps_time)}/{tour})  Tour en cours: {current_lap_time:.2f}s", True, (0, 0, 255))
                                screen.blit(txt, (10, 10 + 30 * (top_n)))
                            elif car.has_finished:
                                txt = font.render(f"{pos}. {car.player_name} (Terminé)", True, (0, 0, 255))
                                screen.blit(txt, (10, 10 + 30 * (top_n)))
                            break

                return False, classement
        except Exception as e:
            self.error = f"Erreur : {e}"
            self.state = MENU
            self.connected_to_server = False
            return False, []

    def run(self):
        running = True
        while running:
            self.dt = clock.tick(FPS) / 1000
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        if self.state not in [LOCALGAME, NETWORKGAME]:
                            if self.created_server:
                                server.server_shutdown()
                            self.state = MENU
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if self.state == MENU:
                        if self.local_btn_rect and self.local_btn_rect.collidepoint(mouse_pos):
                            self.state = LOCALMENU
                        elif self.net_btn_rect and self.net_btn_rect.collidepoint(mouse_pos):
                            self.state = NETWORK_CHOICE
                        self.local_game_launched = False
                    elif self.state == LOCALMENU:
                        if self.launch_button_rect and self.launch_button_rect.collidepoint(mouse_pos):
                            if not self.input_tour_box.text.isdigit() or self.input_tour_box.text == "":
                                self.input_tour_box.error_message = "Veuillez entrer un nombre de tours valide."
                                self.input_name_box.error_message = "Entrer un nom !" if self.input_name_box.text == "" else self.input_name_box.error_message == ""
                            else:
                                self.input_tour_box.error_message = ""
                                self.state = LOCALGAME
                    elif self.state == NETWORK_CHOICE:
                        if self.input_name_box.text != "":
                            if self.create_btn_rect and self.create_btn_rect.collidepoint(mouse_pos):
                                self.state = NETWORK_CREATE
                            elif self.join_btn_rect and self.join_btn_rect.collidepoint(mouse_pos):
                                self.state = NETWORK_JOIN
                        else:
                            self.input_name_box.error_message = "Entrer un nom !" if self.input_name_box.text == "" else self.input_name_box.error_message == ""
                    elif self.state == NETWORK_JOIN:
                        if self.input_ip_box.text != "":
                            if self.join_btn_rect and self.join_btn_rect.collidepoint(mouse_pos):
                                self.try_join_server()
                                if not self.input_ip_box.error_message.startswith("Erreur"):
                                    self.state = NETWORKGAME
                        else:
                            self.input_ip_box.error_message = "Entrer une ip !" if self.input_ip_box.text == "" else self.input_ip_box.error_message == ""
                    elif self.state == NETWORK_CREATE:
                        if self.start_button_rect and self.start_button_rect.collidepoint(mouse_pos):
                            if self.input_tour_box.text == "":
                                self.input_tour_box.error_message = "Entrer un nombre de tour !" if self.input_tour_box.text == "" else self.input_tour_box.error_message == ""
                            else:
                                self.input_tour_box.error_message = ""
                                data = {
                                    "req": "set_game_launched",
                                    "value": "True"
                                }
                                self.sock.send((json.dumps(data) + "\n").encode())
                                self.state = NETWORKGAME
                    elif self.state == CLASSEMENT:
                        if self.save_score_rect and self.save_score_rect.collidepoint(mouse_pos):
                            try:
                                self.save_score(self.classement)
                                if self.created_server:
                                    server.server_shutdown()
                                self.input_name_box.text = ""
                                self.input_name_box.txt_surface = font.render("", True, (0, 0, 0))
                                self.input_name_box.error_message = ""
                                self.input_ip_box.text = ""
                                self.input_ip_box.txt_surface = font.render("", True, (0, 0, 0))
                                self.input_ip_box.error_message = ""
                                self.input_tour_box.text = ""
                                self.input_tour_box.txt_surface = font.render("", True, (0, 0, 0))
                                self.input_tour_box.error_message = ""
                                self.player = None
                                self.classement = []
                                self.created_server = False
                                self.connected_to_server = False
                                self.first_initialised = False
                                self.multi_game_launched = False
                                self.sent_tour_to_server = False
                                self.error = ""
                                self.error_saving = ""
                                self.state = MENU
                            except Exception as e:
                                self.error_saving = f"Erreur : {e}"
                                self.state = MENU
                                self.input_name_box.text = ""
                                self.input_name_box.txt_surface = font.render("", True, (0, 0, 0))
                                self.input_name_box.error_message = ""
                                self.input_ip_box.text = ""
                                self.input_ip_box.txt_surface = font.render("", True, (0, 0, 0))
                                self.input_ip_box.error_message = ""
                                self.input_tour_box.text = ""
                                self.input_tour_box.txt_surface = font.render("", True, (0, 0, 0))
                                self.input_tour_box.error_message = ""
                                self.player = None
                                self.classement = []
                                self.created_server = False
                                self.connected_to_server = False
                                self.first_initialised = False
                                self.multi_game_launched = False
                                self.sent_tour_to_server = False
                                self.error_saving = ""


                if self.state == NETWORK_JOIN:
                    self.input_ip_box.handle_event(event)
                elif self.state == LOCALMENU:
                    self.input_name_box.handle_event(event)
                    self.input_tour_box.handle_event(event)
                elif self.state == NETWORK_CHOICE:
                    self.input_name_box.handle_event(event)
                elif self.state == NETWORK_CREATE:
                    self.input_tour_box.handle_event(event)

            if self.state == MENU:
                self.local_btn_rect, self.net_btn_rect = self.draw_menu(self.error)
            elif self.state == LOCALMENU:
                self.launch_button_rect = self.draw_menu_play_solo()
            elif self.state == NETWORK_CHOICE:
                self.create_btn_rect, self.join_btn_rect = self.draw_menu_multijoueur_choice()
            elif self.state == NETWORK_CREATE:
                if self.created_server == False:
                    self.try_create_server()
                if not self.input_ip_box.error_message.startswith("Erreur"):
                    if self.connected_to_server == False:
                        self.try_connect_own_server()
                        data = {
                        "req": "set_spawn",
                        "value": self.track_points_dict["spawn"]
                        }
                        self.sock.send((json.dumps(data) + "\n").encode())
                    if not self.input_ip_box.error_message.startswith("Erreur"):
                        self.start_button_rect = self.draw_menu_multijoueur_create()
                    else:
                        self.state = NETWORK_CHOICE
                else:
                    self.state = NETWORK_CHOICE
            elif self.state == NETWORK_JOIN:
                self.join_btn_rect = self.draw_menu_multijoueur()
            elif self.state == LOCALGAME:
                if self.player is None:
                    self.player = Car(self.input_name_box.text)
                self.game_state, classement = self.manage_race([self.player], self.dt, self.input_tour_box.text)
                if self.game_state:
                    self.classement = classement
                    self.state = CLASSEMENT
            elif self.state == NETWORKGAME:
                if self.connected_to_server == True and self.created_server == True:
                    if self.sent_tour_to_server == False:
                        data = {
                            "req": "set_tour",
                            "value": self.input_tour_box.text
                        }
                        self.sock.send((json.dumps(data) + "\n").encode())
                if self.multi_game_launched == False:
                    data = {
                        "req": "pull",
                        "target": "game"
                    }
                    self.sock.send((json.dumps(data) + "\n").encode())
                    response = self.sock_file.readline()
                    game_data = json.loads(response)["game"]
                    self.multi_game_launched = game_data.get("game_launched", False)
                    self.tour_race = game_data.get("tour_race", 2)
                if self.connected_to_server == True and self.created_server == False and self.multi_game_launched == False:
                    self.draw_lobby()                    
                else:
                    self.game_state, classement = self.manage_race_online(self.dt, self.tour_race)
                    if self.game_state:
                        self.classement = classement
                        self.state = CLASSEMENT
            elif self.state == CLASSEMENT:
                self.save_score_rect = self.draw_classement(self.classement, self.error_saving)
                self.player.accel_channel.stop()
                self.player.frein_channel.stop()
                self.player.engine_channel.stop()
            if self.state in [MENU, LOCALMENU, NETWORK_CHOICE, NETWORK_CREATE, NETWORK_JOIN, CLASSEMENT]:
                if not pygame.mixer.music.get_busy():
                    pygame.mixer.music.load(MENU_MUSIC)
                    pygame.mixer.music.play(-1)
            else:
                pygame.mixer.music.stop()
            pygame.display.flip()

if __name__ == "__main__":
    pygame.init()
    pygame.mixer.init()
    pygame.key.set_repeat()

    SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
    FPS = 70

    WHITE = (255, 255, 255)

    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.DOUBLEBUF)
    pygame.display.set_caption("Racepy")
    icon = pygame.image.load(os.path.join("img", "logo.png")).convert_alpha()
    pygame.display.set_icon(icon)
    clock = pygame.time.Clock()

    track_image = pygame.image.load(os.path.join("img", "track1.png")).convert()
    track_rect = track_image.get_rect()
    font = pygame.font.SysFont(None, 48)

    MENU = "menu"
    LOCALMENU = "localmenu"
    LOCALGAME = "localgame"
    NETWORKGAME = "networkgame"
    NETWORK_CHOICE = "network_choice"
    NETWORK_CREATE = "network_create"
    NETWORK_JOIN = "network_join"
    CLASSEMENT = "classement"

    MENU_MUSIC = os.path.join("sounds", "menu_music.mp3")
    ACCEL_SOUND = os.path.join("sounds", "acceleration.wav")
    FREIN_SOUND = os.path.join("sounds", "freinage.wav")
    ENGINE_SOUND = os.path.join("sounds", "engine.wav")

    fps_font = pygame.font.SysFont(None, 24)
    atexit.register(server.server_shutdown)
    game = Game()
    game.run()
    server.server_shutdown()
    pygame.quit()
    sys.exit()
