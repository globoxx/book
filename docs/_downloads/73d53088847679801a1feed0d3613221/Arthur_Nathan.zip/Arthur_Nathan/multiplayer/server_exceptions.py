class UnregisteredAccessError(Exception):
    def __init__(self) -> None:
        super().__init__("Unregistered pull request attempt")

class InvalidServerRequest(Exception):
    def __init__(self) -> None:
        super().__init__("Invalid server request")

class IncompleteServerRequest(Exception):
    def __init__(self, missing : str) -> None:
        super().__init__(f"Missing {missing} in server request")

class InvalidTargetSelection(Exception):
    def __init__(self) -> None:
        super().__init__("Invalid target selection")