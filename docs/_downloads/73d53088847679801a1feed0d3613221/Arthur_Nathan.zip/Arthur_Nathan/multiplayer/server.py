import socket
import threading
import json
import math
import heapq
import time

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from keyboard import play
from server_exceptions import *

HOST = "0.0.0.0"
PORT = 4096

# internal game data
_server_game_data_lock = threading.Lock() # mutex to prevent racing conditions
_classement_lock = threading.Lock()
_server_game_data = {
    "game":{
        "player_count": 0,
        "game_launched": False,
        "spawn_availaible": [],
        "tour_race": 2,
        "all_player_ready": False,
        "classement": [],
        "game_finished": False
    },
    "players": {},
    "graphe_att": {
        "graphe": {},
        "checkpoints": [],
        "arrival": [],
        "dijkstra_distances": {}
    }
}
_server_ready_players = set()

# running
_server_should_run = False

def server_initialize():
    global _server_should_run, _started_time
    _server_should_run = True
    _started_time = 0
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.bind((HOST, PORT))
    s.listen()
    threading.Thread(args=(s,), name="srv_listen", target=_server_run, daemon=True).start()
    _thread_classement = threading.Thread(target=_classement_thread_loop, daemon=True).start()

def server_shutdown():
    global _server_should_run
    _server_should_run = False

def _server_run(sock : socket.socket):
    while _server_should_run:
        conn, addr = sock.accept()
        threading.Thread(target=_handle_client, args=(conn, addr)).start()
    sock.close()
            

def _handle_client(conn : socket.socket, addr):
    global _started_time
    ip = addr[0]
    try:
        file = conn.makefile('r')
        while True:
            line = file.readline()
            if not line:
                break
            json_data : dict = json.loads(line)
            request = json_data.get("req")
            #print(json_data)
            if request == "join":
                with _server_game_data_lock:
                    player_attr = json_data.get("player_attr")
                    if player_attr is None:
                        raise IncompleteServerRequest("player_attr")
                    _server_game_data["players"][ip] = {
                        "position": [0, 0],
                        "speed_vec": [0, 0],
                        "car_angle": 0,
                        "steering_angle": 0,
                        "chrono": 0,
                        "laps": [],
                        "has_finished": False,
                        "total_time": 0
                    }
                    _server_game_data["players"][ip].update(player_attr)
                    _server_game_data["game"]["player_count"] += 1
            elif request == "quit":
                with _server_game_data_lock:
                    _server_game_data["players"].pop(ip, None)
                    _server_game_data["game"]["player_count"] -= 1
                    _server_ready_players.discard(ip)
                break
            elif not _is_known(ip):
                raise UnregisteredAccessError
            elif request == "push":
                with _server_game_data_lock:
                    _server_game_data["players"][ip].update(json_data.get("player_attr"))
                _server_ready_players.add(ip)
                if len(_server_ready_players) == _server_game_data["game"]["player_count"]:
                    _server_game_data["game"]["all_player_ready"] = True
                    _started_time = int(time.time())    
            elif request == "set_game_launched":
                with _server_game_data_lock:
                    value = json_data.get("value")
                    _server_game_data["game"]["game_launched"] = bool(value)
            elif request == "set_spawn":
                with _server_game_data_lock:
                    value = json_data.get("value")
                    _server_game_data["game"]["spawn"] = list(value)
            elif request == "set_tour":
                with _server_game_data_lock:
                    value = json_data.get("value")
                    _server_game_data["game"]["tour_race"] = int(value)     
            elif request == "pop_spawn":
                with _server_game_data_lock:
                    spawn_list = _server_game_data["game"].get("spawn", [])
                    if spawn_list:
                        spawn_point = spawn_list.pop(0)
                        conn.send((json.dumps({"spawn": spawn_point}) + "\n").encode())
                    else:
                        conn.send((json.dumps({"spawn": None}) + "\n").encode())
            elif request == "pull":
                target_object : str = str(json_data.get("target"))
                if target_object in _server_game_data:
                    with _server_game_data_lock:
                        payload = {target_object: _server_game_data[target_object]}
                        conn.send((json.dumps(payload)+"\n").encode())
                else:
                    raise InvalidTargetSelection
            elif request == "set_graph":
                with _server_game_data_lock:
                    graph = json_data.get("graph")
                    checkpoints = json_data.get("checkpoints")
                    arrival = json_data.get("arrival")
                    _set_graph(graph, checkpoints, arrival)
            else:
                raise InvalidServerRequest
    except Exception as e:
        print(f"Error handling client {addr}: {e}")
    finally:
        conn.close()

def _set_graph(graph, checkpoints, arrival):
    graph_tuples = {}
    for k, v in graph.items():
        k_tuple = tuple(map(int, k.strip("()").split(",")))
        v_tuples = []
        for n, d in v:
            n_tuple = tuple(map(int, n.strip("()").split(",")))
            v_tuples.append((n_tuple, d))
        graph_tuples[k_tuple] = v_tuples
    _server_game_data["graphe_att"]["graph"] = graph_tuples
    _server_game_data["graphe_att"]["checkpoints"] = [tuple(pt) for pt in checkpoints]
    _server_game_data["graphe_att"]["arrival"] = tuple(arrival)
    _server_game_data["graphe_att"]["dijkstra_distances"] = _dijkstra(graph_tuples, tuple(arrival))

def _dijkstra(graph, start):
    distances = {tuple(pt): float('inf') for pt in graph}
    distances[tuple(start)] = 0
    rest = [(0, tuple(start))]
    while rest:
        dist, current = heapq.heappop(rest)
        if dist > distances[current]:
            continue
        for neighbor, weight in graph[current]:
            neighbor = tuple(neighbor)
            new_dist = dist + weight
            if new_dist < distances[neighbor]:
                distances[neighbor] = new_dist
                heapq.heappush(rest, (new_dist, neighbor))
    return distances

def _find_nearest_checkpoint(x, y, checkpoints):
    nearest = float('inf')
    near_pos = None
    for pos in checkpoints:
        distance = math.sqrt((pos[0]-x)**2 + (pos[1]-y)**2)
        if distance < nearest:
            nearest = distance
            near_pos = (pos[0], pos[1])
    return near_pos

def _is_known(player):
    return player in _server_game_data["players"]

def server_push(data):
    with _server_game_data_lock:
        _server_game_data.update(data)

def server_pull():
    with _server_game_data_lock:
        return _server_game_data

def _classement_thread_loop():
    while True:
        _update_classement_global()
        time.sleep(0.1)

def _update_classement_global():
    global _started_time
    with _server_game_data_lock:
        classement = []
        graph = _server_game_data["graphe_att"].get("graph")
        checkpoints = _server_game_data["graphe_att"].get("checkpoints")
        dijkstra_distances = _server_game_data["graphe_att"].get("dijkstra_distances")
        all_finished = True

        for ip, player in _server_game_data["players"].items():
            laps = player.get("laps", [])
            has_finished = player.get("has_finished", False)
            total_time = player.get("total_time", 0)

            if has_finished == False:
                all_finished = False

            if has_finished:
                distance = float('inf')
            else:
                pos = player.get("position", [0, 0])
                if graph and checkpoints and dijkstra_distances:
                    nearest = _find_nearest_checkpoint(pos[0], pos[1], checkpoints)
                    dist_checkpoint_to_arrival = dijkstra_distances.get(nearest, float('inf'))
                    distance = math.sqrt((pos[0]-nearest[0])**2 + (pos[1]-nearest[1])**2) + dist_checkpoint_to_arrival
                else:
                    distance = float('inf')

            classement.append((
                -len(laps),
                total_time,
                distance,
                player.get("player_name", f"Joueur {ip}"),
                has_finished
            ))

        classement.sort(key=lambda x: (x[0], x[1], x[2]))
        result = [(idx+1, total_time, name) for idx, (_, total_time, _, name, _) in enumerate(classement)]
        _server_game_data["game"]["classement"] = result
        _server_game_data["game"]["game_finished"] = all_finished