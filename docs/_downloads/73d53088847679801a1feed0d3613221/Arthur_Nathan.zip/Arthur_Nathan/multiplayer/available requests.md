# 🕹️ Game Server API Documentation

## 📡 Available Requests

| Request Type       | Description                                                                 |
|--------------------|-----------------------------------------------------------------------------|
| `push`             | Met à jour les données du joueur (position, vitesse, chrono, etc.)          |
| `pull`             | Récupère les données du serveur (jeu, joueurs, graphe, etc.)                |
| `join`             | Enregistre le joueur par IP avec des données par défaut                     |
| `quit`             | Supprime le joueur et ses données du serveur                                |
| `set_game_launched`| Définit si la partie a été lancée ou non (`true` ou `false`)                |
| `set_spawn`        | Définit la liste des points de spawn disponibles                            |
| `pop_spawn`        | Retire et retourne un point de spawn de la liste (ou `null` si vide)        |
| `set_tour`         | Définit le nombre de tours à effectuer dans la course                       |
| `set_graph`        | Envoie au serveur le graphe du circuit, les checkpoints et l’arrivée        |

---

## 🧾 Request Format

All requests must follow the structure:

```json
{
  "req": "<request_type>",
  "<argument_key>": <value>,
  ...
}
```

---

## 🔁 `push` – Push Data to Server

### ✅ Required Fields

| Field            | Description                  | Format   |
| ---------------- | ---------------------------- | -------- |
| `position`       | Player's current position    | `[x, y]` |
| `speed_vec`      | Velocity vector              | `[x, y]` |
| `car_angle`      | Orientation angle of the car | `float`  |
| `steering_angle` | Steering input               | `float`  |
| `chrono`         | Player's race time           | `float`  |
| `laps`           | Player's laps time           | `list`   |
| `has_finished`   | Player's bool finished race  | `bool`   |
| `tatal_time`     | Player's total race time     | `float`  |
### 🔙 Returns

* None

---

## 🔁 `pull` – Pull Data from Server

### ✅ Required Fields

| Field    | Description                                                    | Format   |
| -------- | -------------------------------------------------------------- | -------- |
| `target` | Name of the object to retrieve (e.g., `"game"` or `"players"`) | `string` |

### 🔙 Returns

```json
{
  "<target>": {
    <raw-object-content>
  }
}
```

Example:

```json
{
  "game": {
    "player_count": 2
  }
}
```

---

## 🧍 `join` – Join the Game

### ✅ Required Fields

| Field         | Description                     | Format                  |
| ------------- | ------------------------------- | ----------------------- |
| `player_attr` | Object containing player's name | `{ "<name>": "local" }` |

### 🔙 Returns

* None

---

## ❌ `quit` – Quit the Game

### ✅ Required Fields

* None

### 🔙 Returns

* None

---

## 🚀 `set_game_launched` – Set Game Launch Status

### ✅ Required Fields

| Field  | Description                          | Format  |
|--------|--------------------------------------|---------|
| `value`| Boolean to indicate game start state | `bool`  |

### 🔙 Returns

* None

---

## 🗺️ `set_spawn` – Set Spawn Points

### ✅ Required Fields

| Field  | Description                         | Format     |
|--------|-------------------------------------|------------|
| `value`| List of spawn positions to register | `[ [x, y], ... ]` |

### 🔙 Returns

* None

---

## 🎯 `pop_spawn` – Pop a Spawn Point

### ✅ Required Fields

* None

### 🔙 Returns

```json
{
  "spawn": [x, y] | null
}
```

---

## 🔁 `set_tour` – Set Number of Laps

### ✅ Required Fields

| Field  | Description                | Format |
|--------|----------------------------|--------|
| `value`| Number of laps for the race| `int`  |

### 🔙 Returns

* None

---

## 📊 `set_graph` – Set Graph and Checkpoints

### ✅ Required Fields

| Field        | Description                     | Format                        |
|--------------|---------------------------------|-------------------------------|
| `graph`      | Adjacency list for the graph    | `{ "(x,y)": [[(x,y), dist], ...] }` |
| `checkpoints`| List of checkpoint coordinates  | `[ [x, y], ... ]`             |
| `arrival`    | Coordinate of the finish point  | `[x, y]`                      |

### 🔙 Returns

* None

---