# Racepy - a multiplayer python racing game
Based on pygame

associated searches:
    - https://www.datacamp.com/fr/tutorial/dijkstra-algorithm-in-python for the dijkstra algorithm
    - https://docs.python.org/3/howto/sorting.html for the specific use
    - https://www.pygame.org/docs/ in general
    - the images and sounds are all from free use licences

For creating an exe or an cmd:
    pyinstaller --onefile --windowed --icon=img/logo.ico main.py