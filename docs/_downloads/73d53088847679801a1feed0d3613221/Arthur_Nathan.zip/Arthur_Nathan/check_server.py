import socket
import os

def is_server_running(host="localhost", port=4096):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1)
    try:
        s.connect((host, port))
        s.close()
        return True
    except (ConnectionRefusedError, socket.timeout, OSError):
        return False
def load_best_time( name):
    filename = "scores.txt"
    if not os.path.exists(filename):
        return f"{name} : -- s"
    try:
        with open(filename, "r", encoding="utf-8") as f:
            scores = eval(f.read())
        if name in scores:
            return f"{name} : {scores[name]:.2f} s"
        else:
            return f"{name} : -- s"
    except Exception as e:
        return f"{name} : erreur"

if __name__ == "__main__":
    print(load_best_time("a"))