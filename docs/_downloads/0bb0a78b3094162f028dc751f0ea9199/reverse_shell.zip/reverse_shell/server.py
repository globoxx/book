import socket


def dialog(socket_details, previous_output, directory):  # fonction structurant la console du serveur et envoie des
    # donnees au client
    file = bytes()
    while True:
        if previous_output:
            print(f"{previous_output}")
        prompt = input(f"{directory}>")
        while not str().join([clean for clean in prompt if clean != " "]):
            prompt = input(f"{directory}>")
        if prompt[:6] == "upload":
            try:
                file = open(prompt[7:], "rb").read()
            except (FileNotFoundError, OSError):
                previous_output = "The system cannot find the file specified."
                continue
            except PermissionError:
                previous_output = f"Permission denied: '{prompt[7:]}'"
                continue
        break
    socket_details.sendall(f"{str(len(prompt.encode()))}-{str(len(file))}_".encode() + prompt.encode() + file)
    if prompt == "exit":
        return
    if prompt[:8] == "download":
        return prompt[9:]
    return False


def get_output(socket_details, mds, isf=False):  # fonction receptionnant les donnees envoyees du client en
    # respectant la longueure de celles-ci communiquees en tete
    if isf is None:
        return
    data_length_util = str()
    data_length = str()
    while data_length_util != ".":  # receptionne les longueres de donnes
        data_length += socket_details.recv(1).decode()
        try:
            data_length_util = data_length[-1]
        except IndexError:
            data_length_util = str()
    od = data_length.index("-")
    df = data_length.index("_")
    output_length = int(data_length[:od])
    directory_length = int(data_length[od + 1:df])
    file_length = int(data_length[df + 1:-1])
    data = bytes()
    while len(data) < output_length + directory_length + file_length:  # recupere les donnees
        data += socket_details.recv(mds)
    output = data[:output_length].decode()
    if isf and output == "File downloaded":
        open(isf, "wb").write(data[output_length + directory_length:])
    return output, data[output_length:output_length + directory_length].decode()


HOST_IP = "127.0.0.1"
HOST_PORT = 8723
MAX_DATA_SIZE = 1024
s = socket.socket()
s.bind((HOST_IP, HOST_PORT))
s.listen()
print(f"Waiting for connection on {HOST_IP} port {HOST_PORT}")
connection_socket, guest_util = s.accept()
print(f"Connection established with {guest_util[0]} port {guest_util[1]}")
try:
    result_and_directory = get_output(connection_socket, MAX_DATA_SIZE)
    while True:
        result_and_directory = get_output(connection_socket, MAX_DATA_SIZE,
                                          dialog(connection_socket, result_and_directory[0], result_and_directory[1]))
        if not result_and_directory:
            break
except ConnectionResetError:
    print("Connection lost")
finally:
    connection_socket.close()
    exit()
