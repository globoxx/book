"# safemarks" 
This program is made to help student for the boring task of writing down on paper/excel their school marks.

Marche à suivre pour visualiser et utiliser le projet:

1. Installer Redis
2. Lancer le serveur Redis localement avec la commande `redis-server`
3. Installer les dépendances python (ex: flask, redis, ...)
4. Lancer le serveur Flask avec la commande `python safemarks.py`
5. Ouvrir un navigateur et aller à l'adresse du serveur local
